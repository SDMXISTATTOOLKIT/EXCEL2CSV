﻿//-----------------------------------------------------------------------
// <copyright file="CodeDescExp.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using Excel2Csv.Properties;

    /// <summary>
    /// Represents the type of the Code-Description expression it refers
    /// to as shown in the dialog combo box.
    /// </summary>
    public enum CodeDescExpType
    {
        /// <summary>Custom Code-Description expression</summary>
        Custom,

        /// <summary>Predefined and default Code-Description expression</summary>
        Default,

        /// <summary>Other predefined Code-Description expression</summary>
        Optional,

        /// <summary>Dummy expression type used to let the user enter a custom expression</summary>
        InputRequest
    }

    /// <summary>
    /// Class containing information needed to extract code and description out of a cell 
    /// </summary>
    public class CodeDescExp
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CodeDescExp" /> class.
        /// </summary>
        /// <param name="type">Type of the expression. <see cref="CodeDescExpType"/></param>
        /// <param name="label">Label of the expression, not necessarily related to the expression itself</param>
        /// <param name="pattern">Regular expression related to the object</param>
        /// <param name="codeRange">Range of indices indicating the code part inside the expression</param>
        /// <param name="descRange">Range of indices indicating the description part inside the expression</param>
        public CodeDescExp(CodeDescExpType type, string label, string pattern, Range codeRange, Range descRange)
        {
            if (string.IsNullOrEmpty(pattern))
            {
                pattern = string.Empty;
            }

            this.CodeType = type;
            this.Expression = label;
            this.CodeRange = codeRange;
            this.DescriptionRange = descRange;
        }

        /// <summary>
        /// Gets or sets the range of indices indicating the code part inside the expression.
        /// </summary>
        public Range CodeRange { get; set; }

        /// <summary>
        /// Gets or sets the range of indices indicating the description part inside the expression.
        /// </summary>
        public Range DescriptionRange { get; set; }

        /// <summary>Gets or sets the type of the expression. <see cref="CodeDescExpType"/></summary>
        public CodeDescExpType CodeType { get; set; }

        /// <summary>
        /// Gets or sets the regular expression used to extract the code and the description parts.
        /// </summary>
        public string Expression { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether extra spaces around the code and description
        /// parts should be considered to perform the expression matching test.
        /// </summary>
        public bool Trim { get; set; }

        /// <summary>
        /// Returns a string representation for the current instance.
        /// </summary>
        /// <returns>The string representation for the current instance.</returns>
        public override string ToString()
        {
            return (this.CodeType != CodeDescExpType.InputRequest) ? string.Concat(this.CodeType, Resources.Whitespace, Resources.Hyphen, Resources.Whitespace, "\"", this.Expression.ToString(), "\"") : this.Expression;
        }
    }
}
