﻿//-----------------------------------------------------------------------
// <copyright file="ColumnUpDown.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using System.Windows.Forms;

    /// <summary>
    /// Extends the NumericUpDown widget so that it shows and scrolls the column labels
    /// of a spreadsheet instead of plain numbers.
    /// </summary>
    public class ColumnUpDown : NumericUpDown
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ColumnUpDown" /> class.
        /// </summary>
        public ColumnUpDown() : base()
        {
            this.Minimum = 1;
            if (this.Value < this.Minimum)
            {
                this.Value = this.Minimum;
                this.Text = TableColumnLabeling.ColumnForNumber((int)this.Minimum);
            }
        }

        /// <summary>
        /// Overrides the base UpdateEditText() method so that it converts the internal number
        /// to its column label representation and shows it in the widget.
        /// </summary>
        protected override void UpdateEditText()
        {
            this.Text = TableColumnLabeling.ColumnForNumber((int)this.Value);
        }

        /// <summary>
        /// Overrides the base ValidateEditText() method so that it checks whether
        /// the user entered value is a valid column label.
        /// </summary>
        protected override void ValidateEditText()
        {
            try
            {
                this.Value = TableColumnLabeling.NumberForColumn(this.Text);
            }
            catch
            {
            }

            this.UserEdit = false;
            ////UpdateEditText();
        }

        /// <summary>
        /// Overrides the base OnTextBoxKeyPress() method so that it allows only letters
        /// as user input.
        /// </summary>
        /// <param name="source">The source of the event.</param>
        /// <param name="e">A KeyPressEventArgs that contains the event data.</param>
        protected override void OnTextBoxKeyPress(object source, KeyPressEventArgs e)
        {
            if ((Control.ModifierKeys & ~Keys.Shift) != Keys.None)
            {
                return;
            }

            try
            {
                // workaround to allow backspace
                if (e.KeyChar != '\b')
                {
                    TableColumnLabeling.NumberForChar(e.KeyChar);
                }

                e.Handled = false;
            }
            catch
            {
                e.Handled = true;
            }
        }
    }
}
