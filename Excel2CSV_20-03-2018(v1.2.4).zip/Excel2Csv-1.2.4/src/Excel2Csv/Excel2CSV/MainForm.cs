﻿//-----------------------------------------------------------------------
// <copyright file="MainForm.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using System;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Windows.Forms;

    /// <summary>
    /// Class implementing the main form.
    /// </summary>
    public partial class MainForm : Form
    {
        /// <summary>The current status label to be shown in the status bar.</summary>
        private string currentStatusLabel;

        /// <summary>Keeps track of how many data modeling window have been created.</summary>
        private int dataWinCounter;

        /// <summary>Keeps track of how many dimension modeling window have been created.</summary>
        private int dimWinCounter;

        /// <summary>
        /// Initializes a new instance of the <see cref="MainForm"/> class.
        /// </summary>
        public MainForm()
        {
            this.InitializeComponent();
            this.StatusLabel = string.Empty;
            this.currentStatusLabel = this.StatusLabel;
            this.dataWinCounter = this.dimWinCounter = 0;
        }

        /// <summary>
        /// Gets or sets the label to be shown in the status bar.
        /// </summary>
        public string StatusLabel
        {
            get
            {
                return this.toolStripStatusLabel.Text;
            }

            protected set
            {
                this.toolStripStatusLabel.Text = value;
            }
        }

        /// <summary>
        /// This function just encapsulates the WinAPI call LockWindowUpdate().
        /// In C: <code>BOOL LockWindowUpdate(In_ HWND hWndLock);</code>
        /// </summary>
        /// <param name="windowHandle">
        /// The window in which drawing will be disabled. If this parameter is the not-marshaled
        /// zero pointer (<code>IntPtr.Zero</code>, same as the NULL macro), drawing in the
        /// locked window is enabled.
        /// </param>
        /// <returns>
        /// If the function succeeds, the return value is nonzero. If the function fails, the return
        /// value is zero, indicating that an error occurred or another window was already locked.
        /// </returns>
        [DllImport("user32.dll", EntryPoint = "LockWindowUpdate", SetLastError = true, ExactSpelling = true,
            CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern long LockWindowUpdate(IntPtr windowHandle);

        /// <summary>Shows the about dialog.</summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void AboutItem_Click(object sender, EventArgs e)
        {
            var aboutBox = new AboutBox();
            if (aboutBox.ShowDialog() == DialogResult.OK)
            {
                if (!object.ReferenceEquals(aboutBox, null))
                {
                    aboutBox.Dispose();
                    aboutBox = null;
                }
            }
        }

        /// <summary>Callback executed on the user request to quit.</summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void ExitItem_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        /// <summary>Creates a new data mapping MDI window.</summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void CreateDataCsvWindow(object sender, EventArgs e)
        {
            var state = object.ReferenceEquals(this.ActiveMdiChild, null) ? FormWindowState.Maximized : this.ActiveMdiChild.WindowState;
            DataWindow dataWin = new DataWindow("Data extraction modeling settings");
            dataWin.MdiParent = this;
            ((Form)dataWin).Text = string.Format("{0} #{1}", ((Form)dataWin).Text, ++this.dataWinCounter);
            if (this.MdiChildren.Count() <= 1)
            {
                dataWin.Show();
            }

            try
            {
                LockWindowUpdate(this.Handle);

                // workaround to force child maximization
                dataWin.WindowState = FormWindowState.Normal;
                dataWin.WindowState = state;

                if (!dataWin.Visible)
                {
                    dataWin.Show();
                }
            }
            finally
            {
                LockWindowUpdate(IntPtr.Zero);
            }

            dataWin.SizeChanged += new EventHandler(this.ActiveMdiChild_SizeChanged);
        }

        /// <summary>Creates a new dimension mapping MDI window.</summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void CreateDimensionCsvWindow(object sender, EventArgs e)
        {
            var state = object.ReferenceEquals(this.ActiveMdiChild, null) ? FormWindowState.Maximized : this.ActiveMdiChild.WindowState;
            DimensionWindow dimWin = new DimensionWindow("Dimension extraction modeling settings");
            dimWin.MdiParent = this;
            ((Form)dimWin).Text = string.Format("{0} #{1}", ((Form)dimWin).Text, ++this.dimWinCounter);
            if (this.MdiChildren.Count() <= 1)
            {
                dimWin.Show();
            }

            try
            {
                LockWindowUpdate(this.Handle);

                // workaround to force child maximization
                dimWin.WindowState = FormWindowState.Normal;
                dimWin.WindowState = state;

                if (!dimWin.Visible)
                {
                    dimWin.Show();
                }
            }
            finally
            {
                LockWindowUpdate(IntPtr.Zero);
            }

            dimWin.SizeChanged += new EventHandler(this.ActiveMdiChild_SizeChanged);
        }

        /// <summary>Callback activated each time an MDI window is activated.</summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void Main_MdiChildActivate(object sender, EventArgs e)
        {
            this.currentStatusLabel = this.StatusLabel = !object.ReferenceEquals(this.ActiveMdiChild, null) ? ((MdiChild)this.ActiveMdiChild).MdiMessage : string.Empty;

            if (object.ReferenceEquals(this.ActiveMdiChild, null))
            {
                if (this.tabForms.Visible ^ (this.tabForms.TabCount > 1))
                {
                    this.tabForms.Visible = !this.tabForms.Visible;
                }
            }
            else
            {
                if (object.ReferenceEquals(this.ActiveMdiChild.Tag, null))
                {
                    TabPage tp = new TabPage(this.ActiveMdiChild.Text);
                    tp.Tag = this.ActiveMdiChild;
                    tp.Parent = this.tabForms;
                    this.tabForms.SelectedTab = tp;

                    this.ActiveMdiChild.Tag = tp;
                    this.ActiveMdiChild.FormClosed += new FormClosedEventHandler(this.ActiveMdiChild_FormClosed);
                }
                else
                {
                    this.tabForms.SelectedTab = this.tabForms.TabPages.Cast<TabPage>().Where(x => x.Tag == this.ActiveMdiChild).FirstOrDefault();
                }

                if (this.tabForms.Visible ^ (this.ActiveMdiChild.WindowState == FormWindowState.Maximized && this.tabForms.TabCount > 1))
                {
                    this.tabForms.Visible = !this.tabForms.Visible;
                }
            }
        }

        /// <summary>
        /// Callback triggered whenever an MDI child changes size, which also happens on the
        /// maximize/un-maximize events. This is used as a helper to show or hide the tab bar.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void ActiveMdiChild_SizeChanged(object sender, EventArgs e)
        {
            if (!object.ReferenceEquals(this.ActiveMdiChild, null))
            {
                if (this.tabForms.Visible ^ ((this.ActiveMdiChild.WindowState == FormWindowState.Maximized) && (this.tabForms.TabCount > 1)))
                {
                    this.tabForms.Visible = !this.tabForms.Visible;
                }
            }
        }
        
        /// <summary>
        /// Callback triggered whenever an MDI child is closed, it closes the related tab and
        /// checks whether the tab bar shall still be visible.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void ActiveMdiChild_FormClosed(object sender, FormClosedEventArgs e)
        {
            ((sender as Form).Tag as TabPage).Dispose();
            if (this.tabForms.Visible ^ (this.tabForms.TabCount > 1))
            {
                this.tabForms.Visible = !this.tabForms.Visible;
            }

            var active = this.ActiveMdiChild;
            if ((this.tabForms.TabCount == 1 && !object.ReferenceEquals(active, null)) && (active.WindowState == FormWindowState.Maximized))
            {
                try
                {
                    LockWindowUpdate(this.Handle);
                    active.WindowState = FormWindowState.Normal;
                    active.WindowState = FormWindowState.Maximized;
                }
                finally
                {
                    LockWindowUpdate(IntPtr.Zero);
                }
            }
        }

        /// <summary>
        /// Callback triggered whenever a user chooses a tab from the bar,
        /// it raises the related MDI window.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void TabForms_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!object.ReferenceEquals(this.tabForms.SelectedTab, null) && !object.ReferenceEquals(this.tabForms.SelectedTab.Tag, null))
            {
                try
                {
                    LockWindowUpdate(this.Handle);

                    (this.tabForms.SelectedTab.Tag as Form).Select();
                }
                finally
                {
                    LockWindowUpdate(IntPtr.Zero);
                }
            }
        }

        /// <summary>
        /// Event triggered when the mouse hovers the area over particular toolbar
        /// buttons or menu entries in order to update the text in the status bar.
        /// This is used to show a help text for the entry the mouse hovers on.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void ToolStripItem_MouseEnter(object sender, EventArgs e)
        {
            if (sender is ToolStripItem)
            {
                var text = (sender as ToolStripItem).ToolTipText;
                if (!string.IsNullOrEmpty(text))
                {
                    this.StatusLabel = text;
                }
            }
        }
        
        /// <summary>
        /// Event triggered when the mouse leaves the area of particular toolbar buttons
        /// or menu entries in order to appropriately restore the text in the status bar.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void ToolStripItem_MouseLeave(object sender, EventArgs e)
        {
            if (sender is ToolStripItem)
            {
                this.StatusLabel = this.currentStatusLabel;
            }
        }
    }
}
