﻿//-----------------------------------------------------------------------
// <copyright file="PeriodLabels.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    /// <summary>
    /// A static class containing constant strings used for labeling frequency period types
    /// </summary>
    public static class PeriodLabels
    {
        /// <summary>Label for the monthly period</summary>
        public const string Months = "Months";

        /// <summary>Label for the quarterly period</summary>
        public const string Quarters = "Quarters";

        /// <summary>Label for the half-yearly period</summary>
        public const string HalfYears = "Half years";

        /// <summary>Label for the yearly period</summary>
        public const string Years = "Years";
    }
}
