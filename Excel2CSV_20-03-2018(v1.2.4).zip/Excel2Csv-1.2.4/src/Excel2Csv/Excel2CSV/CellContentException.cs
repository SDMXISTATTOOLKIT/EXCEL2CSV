﻿//-----------------------------------------------------------------------
// <copyright file="CellContentException.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using System;
    using System.Runtime.Serialization;

    /// <summary>An exception thrown in case of issues about the cell contents</summary>
    public class CellContentException : System.Exception
    {
        /// <summary>Initializes a new instance of the <see cref="CellContentException" /> class</summary>
        public CellContentException() : base()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CellContentException" /> class
        /// </summary>
        /// <param name="message">Exception message</param>
        public CellContentException(string message) : base(message)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CellContentException" /> class
        /// </summary>
        /// <param name="message">Exception message</param>
        /// <param name="innerException">Inner exception</param>
        public CellContentException(string message, Exception innerException) : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CellContentException" /> class
        /// </summary>
        /// <param name="info">Serialization information</param>
        /// <param name="context">Streaming context</param>
        public CellContentException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
