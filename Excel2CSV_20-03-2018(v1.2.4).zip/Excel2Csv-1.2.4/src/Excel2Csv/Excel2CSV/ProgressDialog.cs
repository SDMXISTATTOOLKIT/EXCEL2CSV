﻿//-----------------------------------------------------------------------
// <copyright file="ProgressDialog.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using System.Windows.Forms;

    /// <summary>
    /// The dialog appearing whenever the application writes an output file and that 
    /// shows the progress bar for the file writing.
    /// </summary>
    public partial class ProgressDialog : Form
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ProgressDialog" /> class.
        /// </summary>
        public ProgressDialog()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Sets the maximum allowed value for the progress bar of the dialog.
        /// </summary>
        /// <param name="max">The maximum allowed value for the progress bar.</param>
        public void SetProgressMax(int max)
        {
            this.progressBar.Maximum = max;
        }

        /// <summary>
        /// Updates the progress of the bar contained in the dialog.
        /// </summary>
        /// <param name="lines">The value of the progress.</param>
        public void UpdateProgressBar(int lines)
        {
            if (lines < this.progressBar.Minimum)
            {
                lines = this.progressBar.Minimum;
            }

            if (lines > this.progressBar.Maximum)
            {
                lines = this.progressBar.Maximum;
            }

            this.progressBar.Value = lines;
        }
    }
}
