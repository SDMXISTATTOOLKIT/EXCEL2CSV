﻿//-----------------------------------------------------------------------
// <copyright file="TimeEditor.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using System;
    using System.Drawing;
    using System.Windows.Forms;

    /// <summary>
    /// The class for the Time Editor window.
    /// </summary>
    public partial class TimeEditor : Form
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TimeEditor" /> class.
        /// </summary>
        /// <param name="csvColumn">the number of the CSV column we are editing</param>
        /// <param name="sample">A sample value for the given dimension</param>
        /// <param name="timeMapping">The current format of the time mapping for the given dimension</param>
        public TimeEditor(int csvColumn, string sample, TimeFormat timeMapping = null)
        {
            this.InitializeComponent();
            this.CsvColumn = csvColumn;
            this.TimeMapping = timeMapping ?? this.CreateTimeMapping();
            this.Sample = sample;
        }

        /// <summary>Gets or sets the time mapping for the current dimension.</summary>
        public TimeFormat TimeMapping { get; protected set; }

        /// <summary>Gets or sets a sample value for the current dimension.</summary>
        public string Sample { get; protected set; }

        /// <summary>Gets or sets the CSV column corresponding to the current dimension.</summary>
        public int CsvColumn { get; protected set; }

        /// <summary>
        /// Checks for the parameter completeness for the current time mapping
        /// </summary>
        /// <param name="errorMessage">message to output in case of error</param>
        /// <returns>whether the check was successful</returns>
        public bool CheckForParameterCompleteness(out string errorMessage)
        {
            if (!this.TimeMapping.IsDate)
            {
                FrequencyFormat ff;
                string label = null;

                for (int i = 0; i < 4; i++)
                {
                    switch (i)
                    {
                        case 0:
                            ff = this.TimeMapping.Monthly;
                            label = "months";
                            break;
                        case 1:
                            ff = this.TimeMapping.Quarterly;
                            label = "quarters";
                            break;
                        case 2:
                            ff = this.TimeMapping.HalfYearly;
                            label = "half years";
                            break;
                        default:
                            ff = this.TimeMapping.Yearly;
                            label = "years";
                            break;
                    }

                    if (ff.Enabled)
                    {
                        if (string.IsNullOrWhiteSpace(ff.YearInFrequencyExpression))
                        {
                            errorMessage = string.Format("Empty year in the tab for {0}.", label);
                            return false;
                        }

                        if (ff.SelectedYear.Length != 4)
                        {
                            errorMessage = string.Format("Wrong amount of selected digits for the year in the tab for {0}.", label);
                            return false;
                        }

                        if (!object.ReferenceEquals(ff, this.TimeMapping.Yearly))
                        {
                            if (string.IsNullOrWhiteSpace(ff.PeriodInFrequencyExpression))
                            {
                                errorMessage = string.Format("Empty period in the tab for {0}.", label);
                                return false;
                            }

                            if (ff.SelectedPeriod.Length < 1)
                            {
                                errorMessage = string.Format("No digits selected for {0}", label);
                                return false;
                            }
                        }
                    }
                }
            }

            errorMessage = null;
            return true;
        }

        /// <summary>
        /// Builds and initializes a newly created time mapping data structure
        /// </summary>
        /// <returns>the newly created time mapping settings</returns>
        private TimeFormat CreateTimeMapping()
        {
            return new TimeFormat()
            {
                Monthly = new FrequencyFormat()
                {
                    Enabled = false,
                    HasPeriodMapping = true,
                    PeriodMapping = new string[(int)FrequencyTypeSizes.Monthly]
                },
                Quarterly = new FrequencyFormat()
                {
                    Enabled = false,
                    HasPeriodMapping = true,
                    PeriodMapping = new string[(int)FrequencyTypeSizes.Quarterly]
                },
                HalfYearly = new FrequencyFormat()
                {
                    Enabled = false,
                    HasPeriodMapping = true,
                    PeriodMapping = new string[(int)FrequencyTypeSizes.HalfYearly]
                },
                Yearly = new FrequencyFormat()
                {
                    Enabled = false,
                    HasPeriodMapping = false
                }
            };
        }

        /// <summary>
        /// Callback that handles the buildup of the time editor window.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TimeEditor_Load(object sender, EventArgs e)
        {
            this.periodSelector.SelectionChanged -= this.PeriodSelector_SelectionChanged;

            try
            {
                // populate the date combo box
                this.comboDateCast.Items.Add(PeriodLabels.Months);
                this.comboDateCast.Items.Add(PeriodLabels.Quarters);
                this.comboDateCast.Items.Add(PeriodLabels.HalfYears);
                this.comboDateCast.Items.Add(PeriodLabels.Years);

                // select the cast type
                this.comboDateCast.SelectedIndex = (int)this.TimeMapping.DateCast;

                // guess whether the controls in the tabs shall be enabled
                bool monthlyControlsEnabled = this.TimeMapping.Monthly.Enabled && !this.TimeMapping.IsDate;
                bool quarterlyControlsEnabled = this.TimeMapping.Quarterly.Enabled && !this.TimeMapping.IsDate;
                bool halfYearlyControlsEnabled = this.TimeMapping.HalfYearly.Enabled && !this.TimeMapping.IsDate;
                bool yearlyControlsEnabled = this.TimeMapping.Yearly.Enabled && !this.TimeMapping.IsDate;

                // Populate the period selector
                this.periodSelector.Rows.Add(this.TimeMapping.Monthly.Enabled, "Monthly");
                this.periodSelector.Rows.Add(this.TimeMapping.Quarterly.Enabled, "Quarterly");
                this.periodSelector.Rows.Add(this.TimeMapping.HalfYearly.Enabled, "Half yearly");
                this.periodSelector.Rows.Add(this.TimeMapping.Yearly.Enabled, "Yearly");

                // Populate the grids in the tabs
                for (int i = 0; i < (int)FrequencyTypeSizes.Monthly; i++)
                {
                    this.dgMonthlyGrid.Rows.Add((i + 1).ToString("D2"), this.TimeMapping.Monthly.PeriodMapping[i]);
                }

                for (int i = 0; i < (int)FrequencyTypeSizes.Quarterly; i++)
                {
                    this.dgQuarterlyGrid.Rows.Add((i + 1).ToString("D2"), this.TimeMapping.Quarterly.PeriodMapping[i]);
                }

                for (int i = 0; i < (int)FrequencyTypeSizes.HalfYearly; i++)
                {
                    this.dgHalfYearlyGrid.Rows.Add((i + 1).ToString("D2"), this.TimeMapping.HalfYearly.PeriodMapping[i]);
                }

                // Populate the checkboxes in the tabs
                this.tbMonthlyYear.Text = this.TimeMapping.Monthly.YearInFrequencyExpression ?? this.Sample;
                this.tbMonthlyPeriod.Text = this.TimeMapping.Monthly.PeriodInFrequencyExpression ?? this.Sample;
                this.tbQuarterlyYear.Text = this.TimeMapping.Quarterly.YearInFrequencyExpression ?? this.Sample;
                this.tbQuarterlyPeriod.Text = this.TimeMapping.Quarterly.PeriodInFrequencyExpression ?? this.Sample;
                this.tbHalfYearlyYear.Text = this.TimeMapping.HalfYearly.YearInFrequencyExpression ?? this.Sample;
                this.tbHalfYearlyPeriod.Text = this.TimeMapping.HalfYearly.PeriodInFrequencyExpression ?? this.Sample;
                this.tbYear.Text = this.TimeMapping.Yearly.YearInFrequencyExpression ?? this.Sample;

                // force the call of the following callbacks to set the variable with initial values
                this.TbMonthlyYear_TextChanged(null, null);
                this.TbMonthlyPeriod_TextChanged(null, null);
                this.TbQuarterlyYear_TextChanged(null, null);
                this.TbQuarterlyPeriod_TextChanged(null, null);
                this.TbHalfYearlyYear_TextChanged(null, null);
                this.TbHalfYearlyPeriod_TextChanged(null, null);
                this.TbYear_TextChanged(null, null);

                // restore text selections
                this.tbMonthlyYear.SelectionStart = this.TimeMapping.Monthly.YearRange.Start;
                this.tbMonthlyYear.SelectionLength = this.TimeMapping.Monthly.YearRange.Start + this.TimeMapping.Monthly.YearRange.End + 1;
                this.tbMonthlyPeriod.SelectionStart = this.TimeMapping.Monthly.PeriodRange.Start;
                this.tbMonthlyPeriod.SelectionLength = this.TimeMapping.Monthly.PeriodRange.Start + this.TimeMapping.Monthly.PeriodRange.End + 1;
                this.tbQuarterlyYear.SelectionStart = this.TimeMapping.Quarterly.YearRange.Start;
                this.tbQuarterlyYear.SelectionLength = this.TimeMapping.Quarterly.YearRange.Start + this.TimeMapping.Quarterly.YearRange.End + 1;
                this.tbQuarterlyPeriod.SelectionStart = this.TimeMapping.Quarterly.PeriodRange.Start;
                this.tbQuarterlyPeriod.SelectionLength = this.TimeMapping.Quarterly.PeriodRange.Start + this.TimeMapping.Quarterly.PeriodRange.End + 1;
                this.tbHalfYearlyYear.SelectionStart = this.TimeMapping.HalfYearly.YearRange.Start;
                this.tbHalfYearlyYear.SelectionLength = this.TimeMapping.HalfYearly.YearRange.Start + this.TimeMapping.HalfYearly.YearRange.End + 1;
                this.tbHalfYearlyPeriod.SelectionStart = this.TimeMapping.HalfYearly.PeriodRange.Start;
                this.tbHalfYearlyPeriod.SelectionLength = this.TimeMapping.HalfYearly.PeriodRange.Start + this.TimeMapping.HalfYearly.PeriodRange.End + 1;
                this.tbYear.SelectionStart = this.TimeMapping.Yearly.YearRange.Start;
                this.tbYear.SelectionLength = this.TimeMapping.Yearly.YearRange.Start + this.TimeMapping.Yearly.YearRange.End + 1;

                // switch the date combobox
                this.cbDateCast.Checked = this.TimeMapping.IsDate;
                this.comboDateCast.Enabled = this.TimeMapping.IsDate;

                // set the look of the controls contained in the tabs
                this.SetTabControlEnabled(TimePeriod.Monthly, monthlyControlsEnabled);
                this.SetTabControlEnabled(TimePeriod.Quarterly, quarterlyControlsEnabled);
                this.SetTabControlEnabled(TimePeriod.HalfYearly, halfYearlyControlsEnabled);
                this.SetTabControlEnabled(TimePeriod.Yearly, yearlyControlsEnabled);

                this.periodSelector.ClearSelection();
            }
            finally
            {
                this.periodSelector.SelectionChanged += new System.EventHandler(this.PeriodSelector_SelectionChanged);
            }
        }

        /// <summary>
        /// This callback is called whenever you select a different frequency from the list on the left of the time editor.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the arguments of the event</param>
        private void PeriodSelector_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0 && (object.ReferenceEquals(this.periodSelector.CurrentCell, null) || e.RowIndex == this.periodSelector.CurrentCell.RowIndex) && e.RowIndex != -1 && e.RowIndex <= Enum.GetNames(typeof(TimePeriod)).Length)
            {
                // Handle checkbox state change here
                var cell = this.periodSelector.Rows[e.RowIndex].Cells[0] as DataGridViewCheckBoxCell;
                this.tcPeriod.SelectedIndex = this.periodSelector.CurrentCell.RowIndex;

                if (!object.ReferenceEquals(this.periodSelector.CurrentCell, null))
                {
                    foreach (DataGridViewRow row in this.periodSelector.Rows)
                    {
                        this.SetTabControlEnabled((TimePeriod)row.Index, (bool)row.Cells[0].Value);

                        switch ((TimePeriod)row.Index)
                        {
                            case TimePeriod.Monthly:
                                {
                                    var ff = this.TimeMapping.Monthly;
                                    row.Cells[e.ColumnIndex].Value = ff.Enabled = (row.Index == e.RowIndex) ? (bool)row.Cells[0].Value : false;
                                    this.TimeMapping.Monthly = ff;
                                }

                                break;
                            case TimePeriod.Quarterly:
                                {
                                    var ff = this.TimeMapping.Quarterly;
                                    row.Cells[e.ColumnIndex].Value = ff.Enabled = (row.Index == e.RowIndex) ? (bool)row.Cells[0].Value : false;
                                    this.TimeMapping.Quarterly = ff;
                                }

                                break;
                            case TimePeriod.HalfYearly:
                                {
                                    var ff = this.TimeMapping.HalfYearly;
                                    row.Cells[e.ColumnIndex].Value = ff.Enabled = (row.Index == e.RowIndex) ? (bool)row.Cells[0].Value : false;
                                    this.TimeMapping.HalfYearly = ff;
                                }

                                break;
                            case TimePeriod.Yearly:
                                {
                                    var ff = this.TimeMapping.Yearly;
                                    row.Cells[e.ColumnIndex].Value = ff.Enabled = (row.Index == e.RowIndex) ? (bool)row.Cells[0].Value : false;
                                    this.TimeMapping.Yearly = ff;
                                }

                                break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// checks whether the given time period was enabled in the current time mapping settings.
        /// </summary>
        /// <param name="period">the current time period</param>
        /// <returns>the check results</returns>
        private bool IsPeriodEnabled(TimePeriod period)
        {
            return (bool)((DataGridViewCheckBoxCell)this.periodSelector.Rows[(int)period].Cells[0]).Value;
        }

        /// <summary>
        /// Callback triggered whenever the user toggles the check box that decides whether
        /// table date shall be interpreted as DateTime values or should be casted in a custom way.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the arguments of the event</param>
        private void CbDateCast_CheckedChanged(object sender, EventArgs e)
        {
            bool monthlyControlsEnabled = this.IsPeriodEnabled(TimePeriod.Monthly) && !this.cbDateCast.Checked;
            bool quarterlyControlsEnabled = this.IsPeriodEnabled(TimePeriod.Quarterly) && !this.cbDateCast.Checked;
            bool halfYearlyControlsEnabled = this.IsPeriodEnabled(TimePeriod.HalfYearly) && !this.cbDateCast.Checked;
            bool yearlyControlsEnabled = this.IsPeriodEnabled(TimePeriod.Yearly) && !this.cbDateCast.Checked;

            this.comboDateCast.Enabled = this.cbDateCast.Checked;
            this.SetTabControlEnabled(TimePeriod.Monthly, monthlyControlsEnabled);
            this.SetTabControlEnabled(TimePeriod.Quarterly, quarterlyControlsEnabled);
            this.SetTabControlEnabled(TimePeriod.HalfYearly, halfYearlyControlsEnabled);
            this.SetTabControlEnabled(TimePeriod.Yearly, yearlyControlsEnabled);

            this.SetDataGridViewLook(this.periodSelector, !this.cbDateCast.Checked);

            this.TimeMapping.IsDate = this.cbDateCast.Checked;
        }

        /// <summary>
        /// Enables the toggles the contents related to a period check box
        /// and adjusts its contents look accordingly.
        /// Adjusts the contents of a tab related to the <paramref name="period"/> passed
        /// according to its <paramref name="status"/>.
        /// </summary>
        /// <param name="period">The period representation</param>
        /// <param name="status">Enabled or disabled</param>
        private void SetTabControlEnabled(TimePeriod period, bool status)
        {
            RichTextBox tbp = null, tby = null;
            Label lbp = null, lby = null;
            DataGridView dg = null;

            switch (period)
            {
                case TimePeriod.Monthly:
                    tbp = this.tbMonthlyPeriod;
                    tby = this.tbMonthlyYear;
                    lbp = this.lblMonthlyPeriod;
                    lby = this.lblMonthlyYear;
                    dg = this.dgMonthlyGrid;
                    break;
                case TimePeriod.Quarterly:
                    tbp = this.tbQuarterlyPeriod;
                    tby = this.tbQuarterlyYear;
                    lbp = this.lblQuarterlyPeriod;
                    lby = this.lblQuarterlyYear;
                    dg = this.dgQuarterlyGrid;
                    break;
                case TimePeriod.HalfYearly:
                    tbp = this.tbHalfYearlyPeriod;
                    tby = this.tbHalfYearlyYear;
                    lbp = this.lblHalfYearlyPeriod;
                    lby = this.lblHalfYearlyYear;
                    dg = this.dgHalfYearlyGrid;
                    break;
                case TimePeriod.Yearly:
                    tbp = this.tbYear;
                    lbp = this.lblYear;
                    break;
            }

            tbp.Enabled = lbp.Enabled = status;
            if (!object.ReferenceEquals(tby, null))
            {
                tby.Enabled = lby.Enabled = status;
                this.SetDataGridViewLook(dg, status);
                dg.Enabled = status;
            }
        }

        /// <summary>
        /// Makes a <see cref="DataGridView" /> look enabled or disabled.
        /// </summary>
        /// <param name="dgv">the <see cref="DataGridView" /> object</param>
        /// <param name="enabled">Whether the grid should look enabled</param>
        private void SetDataGridViewLook(DataGridView dgv, bool enabled)
        {
            if (!enabled)
            {
                dgv.DefaultCellStyle.BackColor = SystemColors.Control;
                dgv.DefaultCellStyle.ForeColor = SystemColors.GrayText;
                dgv.ColumnHeadersDefaultCellStyle.BackColor = SystemColors.Control;
                dgv.ColumnHeadersDefaultCellStyle.ForeColor = SystemColors.GrayText;
                dgv.ReadOnly = true;
                dgv.EnableHeadersVisualStyles = false;
            }
            else
            {
                dgv.DefaultCellStyle.BackColor = SystemColors.Window;
                dgv.DefaultCellStyle.ForeColor = SystemColors.ControlText;
                dgv.ColumnHeadersDefaultCellStyle.BackColor = SystemColors.Window;
                dgv.ColumnHeadersDefaultCellStyle.ForeColor = SystemColors.ControlText;
                dgv.ReadOnly = false;
                dgv.EnableHeadersVisualStyles = true;
            }
        }

        /// <summary>
        /// Callback triggered whenever a user finishes editing the grid for the monthly period.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the <see cref="DataGridView"/> event arguments</param>
        private void DgMonthlyGrid_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (!object.ReferenceEquals(this.dgMonthlyGrid[e.ColumnIndex, e.RowIndex].Value, null))
            {
                this.TimeMapping.Monthly.PeriodMapping[e.RowIndex] = this.dgMonthlyGrid[e.ColumnIndex, e.RowIndex].Value.ToString();
            }
        }

        /// <summary>
        /// Callback triggered whenever a user finishes editing the grid for the quarterly period.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the <see cref="DataGridView"/> event arguments</param>
        private void DgQuarterlyGrid_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (!object.ReferenceEquals(this.dgQuarterlyGrid[e.ColumnIndex, e.RowIndex].Value, null))
            {
                this.TimeMapping.Quarterly.PeriodMapping[e.RowIndex] = this.dgQuarterlyGrid[e.ColumnIndex, e.RowIndex].Value.ToString();
            }
        }

        /// <summary>
        /// Callback triggered whenever a user finishes editing the grid for the half-yearly period.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the <see cref="DataGridView"/> event arguments</param>
        private void DgHalfYearlyGrid_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (!object.ReferenceEquals(this.dgHalfYearlyGrid[e.ColumnIndex, e.RowIndex].Value, null))
            {
                this.TimeMapping.HalfYearly.PeriodMapping[e.RowIndex] = this.dgHalfYearlyGrid[e.ColumnIndex, e.RowIndex].Value.ToString();
            }
        }

        /// <summary>
        /// Callback triggered at every text change in the year box inside the monthly period tab.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TbMonthlyYear_TextChanged(object sender, EventArgs e)
        {
            this.tbMonthlyPeriod.TextChanged -= this.TbMonthlyPeriod_TextChanged;

            try
            {
                this.tbMonthlyPeriod.Text = this.tbMonthlyYear.Text;
            }
            finally
            {
                this.tbMonthlyPeriod.TextChanged += this.TbMonthlyPeriod_TextChanged;
                var ff = this.TimeMapping.Monthly;
                ff.YearInFrequencyExpression = this.tbMonthlyYear.Text;
                ff.PeriodInFrequencyExpression = this.tbMonthlyPeriod.Text;
                this.TimeMapping.Monthly = ff;
            }
        }

        /// <summary>
        /// Callback triggered at every text change in the period box inside the monthly period tab.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TbMonthlyPeriod_TextChanged(object sender, EventArgs e)
        {
            this.tbMonthlyYear.TextChanged -= this.TbMonthlyYear_TextChanged;

            try
            {
                this.tbMonthlyYear.Text = this.tbMonthlyPeriod.Text;
            }
            finally
            {
                this.tbMonthlyYear.TextChanged += this.TbMonthlyYear_TextChanged;
                var ff = this.TimeMapping.Monthly;
                ff.PeriodInFrequencyExpression = this.tbMonthlyPeriod.Text;
                ff.YearInFrequencyExpression = this.tbMonthlyYear.Text;
                this.TimeMapping.Monthly = ff;
            }
        }

        /// <summary>
        /// Callback triggered at every text change in the year box inside the quarterly period tab.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TbQuarterlyYear_TextChanged(object sender, EventArgs e)
        {
            this.tbQuarterlyPeriod.TextChanged -= this.TbQuarterlyPeriod_TextChanged;

            try
            {
                this.tbQuarterlyPeriod.Text = this.tbQuarterlyYear.Text;
            }
            finally
            {
                this.tbQuarterlyPeriod.TextChanged += this.TbQuarterlyPeriod_TextChanged;
                var ff = this.TimeMapping.Quarterly;
                ff.YearInFrequencyExpression = this.tbQuarterlyYear.Text;
                ff.PeriodInFrequencyExpression = this.tbQuarterlyPeriod.Text;
                this.TimeMapping.Quarterly = ff;
            }
        }

        /// <summary>
        /// Callback triggered at every text change in the period box inside the quarterly period tab.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TbQuarterlyPeriod_TextChanged(object sender, EventArgs e)
        {
            this.tbQuarterlyYear.TextChanged -= this.TbQuarterlyYear_TextChanged;

            try
            {
                this.tbQuarterlyYear.Text = this.tbQuarterlyPeriod.Text;
            }
            finally
            {
                this.tbQuarterlyYear.TextChanged += this.TbQuarterlyYear_TextChanged;
                var ff = this.TimeMapping.Quarterly;
                ff.PeriodInFrequencyExpression = this.tbQuarterlyPeriod.Text;
                ff.YearInFrequencyExpression = this.tbQuarterlyYear.Text;
                this.TimeMapping.Quarterly = ff;
            }
        }

        /// <summary>
        /// Callback triggered at every text change in the year box inside the half-yearly period tab.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TbHalfYearlyYear_TextChanged(object sender, EventArgs e)
        {
            this.tbHalfYearlyPeriod.TextChanged -= this.TbHalfYearlyPeriod_TextChanged;

            try
            {
                this.tbHalfYearlyPeriod.Text = this.tbHalfYearlyYear.Text;
            }
            finally
            {
                this.tbHalfYearlyPeriod.TextChanged += this.TbHalfYearlyPeriod_TextChanged;
                var ff = this.TimeMapping.HalfYearly;
                ff.YearInFrequencyExpression = this.tbHalfYearlyYear.Text;
                ff.PeriodInFrequencyExpression = this.tbHalfYearlyPeriod.Text;
                this.TimeMapping.HalfYearly = ff;
            }
        }

        /// <summary>
        /// Callback triggered at every text change in the period box inside the half-yearly period tab.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TbHalfYearlyPeriod_TextChanged(object sender, EventArgs e)
        {
            this.tbHalfYearlyYear.TextChanged -= this.TbHalfYearlyYear_TextChanged;

            try
            {
                this.tbHalfYearlyYear.Text = this.tbHalfYearlyPeriod.Text;
            }
            finally
            {
                this.tbHalfYearlyYear.TextChanged += this.TbHalfYearlyYear_TextChanged;
                var ff = this.TimeMapping.HalfYearly;
                ff.PeriodInFrequencyExpression = this.tbHalfYearlyPeriod.Text;
                ff.YearInFrequencyExpression = this.tbHalfYearlyYear.Text;
                this.TimeMapping.HalfYearly = ff;
            }
        }

        /// <summary>
        /// Callback triggered at every text change in the year box inside the yearly period tab.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TbYear_TextChanged(object sender, EventArgs e)
        {
            var ff = this.TimeMapping.Yearly;
            ff.YearInFrequencyExpression = this.tbYear.Text;
            this.TimeMapping.Yearly = ff;
        }

        /// <summary>
        /// Selects the time format a DateTime value should be casted to.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void ComboDateCast_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.comboDateCast.SelectedIndex != -1 && this.comboDateCast.SelectedIndex < Enum.GetNames(typeof(TimePeriod)).Length)
            {
                this.TimeMapping.DateCast = (TimePeriod)this.comboDateCast.SelectedIndex;
            }
        }

        /// <summary>
        /// Validates and accepts the current time mapping settings.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void OkayButton_Click(object sender, EventArgs e)
        {
            string msg;
            if (!this.CheckForParameterCompleteness(out msg))
            {
                MessageBox.Show(
                    this,
                    msg ?? string.Empty,
                    "Error",
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Error);
                this.DialogResult = DialogResult.None;
            }
        }

        /// <summary>
        /// Callback triggered whenever the selection in the
        /// year text box inside the monthly tab has changed.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TbMonthlyYear_SelectionChanged(object sender, EventArgs e)
        {
            var r = this.TimeMapping.Monthly.YearRange;
            r.Start = this.tbMonthlyYear.SelectionStart;
            r.End = this.tbMonthlyYear.SelectionStart + this.tbMonthlyYear.SelectionLength - 1;
            this.TimeMapping.Monthly.YearRange = r;
            this.TimeMapping.Monthly.SelectedYear = this.tbMonthlyYear.SelectedText;
        }

        /// <summary>
        /// Callback triggered whenever the selection in the
        /// period text box inside the monthly tab has changed.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TbMonthlyPeriod_SelectionChanged(object sender, EventArgs e)
        {
            var r = this.TimeMapping.Monthly.PeriodRange;
            r.Start = this.tbMonthlyPeriod.SelectionStart;
            r.End = this.tbMonthlyPeriod.SelectionStart + this.tbMonthlyPeriod.SelectionLength - 1;
            this.TimeMapping.Monthly.PeriodRange = r;
            this.TimeMapping.Monthly.SelectedPeriod = this.tbMonthlyPeriod.SelectedText;
        }

        /// <summary>
        /// Callback triggered whenever the selection in the
        /// year text box inside the quarterly tab has changed.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TbQuarterlyYear_SelectionChanged(object sender, EventArgs e)
        {
            var r = this.TimeMapping.Quarterly.YearRange;
            r.Start = this.tbQuarterlyYear.SelectionStart;
            r.End = this.tbQuarterlyYear.SelectionStart + this.tbQuarterlyYear.SelectionLength - 1;
            this.TimeMapping.Quarterly.YearRange = r;
            this.TimeMapping.Quarterly.SelectedYear = this.tbQuarterlyYear.SelectedText;
        }

        /// <summary>
        /// Callback triggered whenever the selection in the
        /// period text box inside the quarterly tab has changed.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TbQuarterlyPeriod_SelectionChanged(object sender, EventArgs e)
        {
            var r = this.TimeMapping.Quarterly.PeriodRange;
            r.Start = this.tbQuarterlyPeriod.SelectionStart;
            r.End = this.tbQuarterlyPeriod.SelectionStart + this.tbQuarterlyPeriod.SelectionLength - 1;
            this.TimeMapping.Quarterly.PeriodRange = r;
            this.TimeMapping.Quarterly.SelectedPeriod = this.tbQuarterlyPeriod.SelectedText;
        }

        /// <summary>
        /// Callback triggered whenever the selection in the
        /// year text box inside the yearly tab has changed.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TbHalfYearlyYear_SelectionChanged(object sender, EventArgs e)
        {
            var r = this.TimeMapping.HalfYearly.YearRange;
            r.Start = this.tbHalfYearlyYear.SelectionStart;
            r.End = this.tbHalfYearlyYear.SelectionStart + this.tbHalfYearlyYear.SelectionLength - 1;
            this.TimeMapping.HalfYearly.YearRange = r;
            this.TimeMapping.HalfYearly.SelectedYear = this.tbHalfYearlyYear.SelectedText;
        }

        /// <summary>
        /// Callback triggered whenever the selection in the
        /// period text box inside the yearly tab has changed.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TbHalfYearlyPeriod_SelectionChanged(object sender, EventArgs e)
        {
            var r = this.TimeMapping.HalfYearly.PeriodRange;
            r.Start = this.tbHalfYearlyPeriod.SelectionStart;
            r.End = this.tbHalfYearlyPeriod.SelectionStart + this.tbHalfYearlyPeriod.SelectionLength - 1;
            this.TimeMapping.HalfYearly.PeriodRange = r;
            this.TimeMapping.HalfYearly.SelectedPeriod = this.tbHalfYearlyPeriod.SelectedText;
        }

        /// <summary>
        /// triggered whenever the selection of the year part in the year expression changes
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void TbYear_SelectionChanged(object sender, EventArgs e)
        {
            var r = this.TimeMapping.Yearly.YearRange;
            r.Start = this.tbYear.SelectionStart;
            r.End = this.tbYear.SelectionStart + this.tbYear.SelectionLength - 1;
            this.TimeMapping.Yearly.YearRange = r;
            this.TimeMapping.Yearly.SelectedYear = this.tbYear.SelectedText;
        }

        /// <summary>
        /// Used to enforce the commit of changes on the grid on the left side of the time editor,
        /// especially the value of the inner checkboxes.
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void PeriodSelector_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (this.periodSelector.IsCurrentCellDirty)
            {
                this.periodSelector.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }
        
        /// <summary>
        /// triggered whenever a new row is selected on the left side of the time editor
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void PeriodSelector_SelectionChanged(object sender, EventArgs e)
        {
            if (!object.ReferenceEquals(this.periodSelector.CurrentCell, null))
            {
                this.tcPeriod.SelectedIndex = this.periodSelector.CurrentCell.RowIndex;

                if (this.periodSelector.CurrentCell.ColumnIndex == 0)
                {
                    this.periodSelector.CurrentCell.Value = !(bool)this.periodSelector.CurrentCell.Value;
                }
            }
        }
    }
}
