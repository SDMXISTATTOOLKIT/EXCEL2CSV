﻿//-----------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Excel2Csv")]
[assembly: AssemblyDescription("Verticalises data stored in MS Excel tables and saves them to CSV files. This program is free software: you can redistribute it and/or modify it under the terms of the European Union Public License, either version 1.1 of the License, or any later version. This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY OF ANY KIND, EXPRESSED OR IMPLIED. You should have received a copy of the European Union Public License along with this program.  If not, you can fetch the License text in any language of the Europen Union at the following URL: <https://joinup.ec.europa.eu/community/eupl/og_page/european-union-public-licence-eupl-v11>.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Istituto Nazionale di Statistica (ISTAT)")]
[assembly: AssemblyProduct("Excel2Csv")]
[assembly: AssemblyCopyright("Copyright © 2017 Andrea Santilli <andrea.santilli@istat.it>")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("3acf6cff-ca58-420b-99d1-ad88a4308974")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("1.2.4.*")]
[assembly: AssemblyFileVersion("1.2.0.0")]
