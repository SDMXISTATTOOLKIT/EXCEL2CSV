﻿//-----------------------------------------------------------------------
// <copyright file="Range.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using System;

    /// <summary>
    /// A range within two positive integer values, used to mark substrings
    /// </summary>
    public struct Range
    {
        /// <summary>internal beginning of the range</summary>
        private int? start;

        /// <summary>internal ending of the range</summary>
        private int? end;

        /// <summary>Gets the length of the substring within the character range</summary>
        public int Coverage
        {
            get
            {
                return 1 + this.End - this.Start;
            }
        }

        /// <summary>
        /// Gets or sets the beginning of the range.
        /// </summary>
        public int Start
        {
            get
            {
                if (object.ReferenceEquals(this.start, null))
                {
                    return default(int);
                }

                return (int)this.start;
            }

            set
            {
                if (object.ReferenceEquals(this.end, null))
                {
                    this.start = value;
                }
                else
                {
                    if (value > this.end)
                    {
                        this.start = this.end;
                        this.end = value;
                    }
                    else
                    {
                        this.start = value;
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets the ending of the range
        /// </summary>
        public int End
        {
            get
            {
                if (object.ReferenceEquals(this.end, null))
                {
                    return default(int);
                }

                return (int)this.end;
            }

            set
            {
                if (object.ReferenceEquals(this.start, null))
                {
                    this.end = value;
                }
                else
                {
                    if (value < this.start)
                    {
                        this.end = this.start;
                        this.start = value;
                    }
                    else
                    {
                        this.end = value;
                    }
                }
            }
        }

        /// <summary>
        /// Checks whether the index range represented by the current
        /// instance and another one overlap each other.
        /// </summary>
        /// <param name="other">The other index range object.</param>
        /// <returns>Whether the current instance overlaps the other range object</returns>
        public bool Overlaps(Range other)
        {
            // a range overlaps another when the beginning of one is
            // located between the beginning and the end of the other one.
            return (this.Start <= other.Start && other.Start < this.End) ||
                (other.Start <= this.Start && this.Start < other.End);
        }
    }
}
