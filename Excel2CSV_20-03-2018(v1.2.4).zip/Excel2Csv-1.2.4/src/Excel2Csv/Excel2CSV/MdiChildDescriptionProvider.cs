﻿//-----------------------------------------------------------------------
// <copyright file="MdiChildDescriptionProvider.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using System;
    using System.ComponentModel;
    using System.Reflection;

    /// <summary>
    /// This class is used to provide the characteristics of an object that can be impersonated by
    /// another one, like in the case when we have an abstract class inheriting from a Form that can replace
    /// the Form class itself.  In this way it becomes possible to use the Form Designer to shape those form
    /// classes that extend abstract ones.
    /// </summary>
    /// <typeparam name="TAbstract">The class replacing another one by getting its characteristics.</typeparam>
    /// <typeparam name="TBase">The replaced class.</typeparam>
    public class MdiChildDescriptionProvider<TAbstract, TBase> : TypeDescriptionProvider
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MdiChildDescriptionProvider{TAbstract,TBase}" /> class.
        /// </summary>
        public MdiChildDescriptionProvider() : base(TypeDescriptor.GetProvider(typeof(TAbstract)))
        {
        }

        /// <summary>Performs normal reflection against the given object with the given type.</summary>
        /// <param name="objectType">The type of object for which to retrieve the <see cref="IReflect"/>.</param>
        /// <param name="instance">An instance of the type. Can be null.</param>
        /// <returns>The type of reflection for this <paramref name="objectType"/>.</returns>
        public override Type GetReflectionType(Type objectType, object instance)
        {
            if (objectType == typeof(TAbstract))
            {
                return typeof(TBase);
            }

            return base.GetReflectionType(objectType, instance);
        }

        /// <summary>Creates an object that can substitute for another data type.</summary>
        /// <param name="provider">An optional service provider.</param>
        /// <param name="objectType">The type of object to create. This parameter is never null.</param>
        /// <param name="argTypes">An optional array of types that represent the parameter types to be passed to the object's constructor. This array can be null or of zero length.</param>
        /// <param name="args">An optional array of parameter values to pass to the object's constructor.</param>
        /// <returns>The substitute <see cref="Object"/>.</returns>
        public override object CreateInstance(IServiceProvider provider, Type objectType, Type[] argTypes, object[] args)
        {
            if (objectType == typeof(TAbstract))
            {
                objectType = typeof(TBase);
            }

            return base.CreateInstance(provider, objectType, argTypes, args);
        }
    }
}
