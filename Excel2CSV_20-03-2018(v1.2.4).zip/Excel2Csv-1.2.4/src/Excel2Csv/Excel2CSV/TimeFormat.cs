﻿//-----------------------------------------------------------------------
// <copyright file="TimeFormat.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    /// <summary>frequency amounts lengths</summary>
    public enum FrequencyTypeSizes
    {
        /// <summary>yearly frequency</summary>
        Yearly = 1,

        /// <summary>half-yearly frequency</summary>
        HalfYearly = 2,

        /// <summary>quarterly frequency</summary>
        Quarterly = 4,

        /// <summary>monthly frequency</summary>
        Monthly = 12
    }

    /// <summary>Contains the transcoding settings for a time series dimension</summary>
    public class TimeFormat
    {
        /// <summary>Gets or sets the transcoding settings for a time series dimension containing monthly data</summary>
        public FrequencyFormat Monthly { get; set; }

        /// <summary>Gets or sets the transcoding settings for a time series dimension containing quarterly data</summary>
        public FrequencyFormat Quarterly { get; set; }

        /// <summary>Gets or sets the transcoding settings for a time series dimension containing half-yearly data</summary>
        public FrequencyFormat HalfYearly { get; set; }

        /// <summary>Gets or sets the transcoding settings for a time series dimension containing yearly data</summary>
        public FrequencyFormat Yearly { get; set; }

        /// <summary>Gets or sets a value indicating whether the dimension codes shall be interpreted as string representing DateTime objects</summary>
        public bool IsDate { get; set; }

        /// <summary>Gets or sets a value indicating how to cast the period for dimension codes containing strings representing DateTime objects</summary>
        public TimePeriod DateCast { get; set; }
    }
}
