﻿//-----------------------------------------------------------------------
// <copyright file="FieldEditor.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Drawing;
    using System.Linq;
    using System.Windows.Forms;
    using Excel2Csv.Properties;

    /// <summary>
    /// The class for the Field Editor window.
    /// </summary>
    public partial class FieldEditor : Form
    {
        /// <summary>Style for editable cells</summary>
        private DataGridViewCellStyle activeStyle;

        /// <summary>Style for not editable cells</summary>
        private DataGridViewCellStyle inactiveStyle;

        /// <summary>The current setup state of the CSV fields.</summary>
        private List<DataField> fieldState;

        /// <summary>The current time format settings for all the time series dimensions.</summary>
        private Dictionary<int, TimeFormat> tf;

        /// <summary>
        /// Initializes a new instance of the <see cref="FieldEditor" /> class.
        /// </summary>
        /// <param name="fieldState">the existing CSV field state.</param>
        public FieldEditor(List<DataField> fieldState)
        {
            this.InitializeComponent();
            
            this.activeStyle = new DataGridViewCellStyle();
            this.inactiveStyle = new DataGridViewCellStyle();
            this.activeStyle.BackColor = Color.White;
            this.inactiveStyle.BackColor = Color.LightGray;
            this.fieldState = fieldState;
        }

        /// <summary>Gets the current field structure</summary>
        public List<DataField> Structure
        {
            get
            {
                List<DataField> ret = new List<DataField>();
                for (int i = 0; i < this.fieldGridView.Rows.Count; i++)
                {
                    DataGridViewRow row = this.fieldGridView.Rows[i];
                    int? idx = null;
                    int flagcnt = 0;

                    if (!object.ReferenceEquals(row.Cells[(int)FieldColumn.Priority].Value, null))
                    {
                        int a = 0;
                        int.TryParse(row.Cells[(int)FieldColumn.Priority].Value.ToString(), out a);
                        idx = (int?)a;
                    }

                    if (!object.ReferenceEquals(row.Cells[(int)FieldColumn.Attribute].Value, null))
                    {
                        if (!int.TryParse(row.Cells[(int)FieldColumn.Attribute].Value.ToString(), out flagcnt))
                        {
                            if (!int.TryParse(Resources.DefaultAttributeColumn, out flagcnt))
                            {
                                flagcnt = 1;
                            }
                        }
                    }

                    ret.Add(new DataField()
                    {
                        Priority = idx,
                        Type = row.Cells[(int)FieldColumn.Type].Value.ToString(),
                        Label = !object.ReferenceEquals(row.Cells[(int)FieldColumn.Label].Value, null) ? row.Cells[(int)FieldColumn.Label].Value.ToString() : null,
                        Dimension = !object.ReferenceEquals(row.Cells[(int)FieldColumn.Dimension].Value, null) ? row.Cells[(int)FieldColumn.Dimension].Value.ToString() : null,
                        Value = !object.ReferenceEquals(row.Cells[(int)FieldColumn.Value].Value, null) ? row.Cells[(int)FieldColumn.Value].Value.ToString() : null,
                        IsTimeSeries = !object.ReferenceEquals(row.Cells[(int)FieldColumn.IsTimeSeries].Value, null) ? (bool)row.Cells[(int)FieldColumn.IsTimeSeries].Value : false,
                        Hidden = !object.ReferenceEquals(row.Cells[(int)FieldColumn.Hidden].Value, null) ? (bool)row.Cells[(int)FieldColumn.Hidden].Value : false,
                        Sample = !object.ReferenceEquals(row.Cells[(int)FieldColumn.Sample].Value, null) ? row.Cells[(int)FieldColumn.Sample].Value.ToString() : null,
                        AttributeColumn = flagcnt,
                        TimeMapping = this.tf.ContainsKey(i) ? this.tf[i] : null
                    });
                }

                return ret;
            }
        }

        /// <summary>Initializes the window grid by adding the initial rows.</summary>
        private void FillEditorGrid()
        {
            this.tf = new Dictionary<int, TimeFormat>();

            for (int i = 0; i < this.fieldState.Count; i++)
            {
                Field row = this.fieldState[i];

                if (row.Type.Equals(FieldType.Column))
                {
                    this.AddColumn(row.Priority, row.Label, row.Dimension, row.IsTimeSeries, row.Hidden, row.Sample);
                    this.tf[i] = row.TimeMapping;
                }
                else if (row.Type.Equals(FieldType.Row))
                {
                    this.AddRow(row.Priority, row.Label, row.Dimension, row.IsTimeSeries, row.Hidden, row.Sample);
                    this.tf[i] = row.TimeMapping;
                }
                else if (row.Type.Equals(FieldType.Constant))
                {
                    this.AddConstant(row.Dimension, ((DataField)row).Value);
                }
                else if (row.Type.Equals(FieldType.Value))
                {
                    this.AddValue(row.Priority, row.Dimension);
                }
                else if (row.Type.Equals(FieldType.Attribute))
                {
                    this.AddAttribute(row.Dimension, ((DataField)row).AttributeColumn);
                }
            }
        }

        /// <summary>
        /// Adds a field to the editor data representing a dimension put along a column
        /// </summary>
        /// <param name="priority">The position initially shown by the field editor</param>
        /// <param name="onSheetLabel">The column label</param>
        /// <param name="dimName">The dimension label related to the field.</param>
        /// <param name="isTimeSeries">Specifies whether the dimension is a time series</param>
        /// <param name="hidden">Whether the column shall not be shown in the output file</param>
        /// <param name="sample">A sample value for a dimension code, used by the TimeEditor</param>
        private void AddColumn(int? priority, string onSheetLabel, string dimName, bool isTimeSeries = false, bool hidden = false, string sample = null)
        {
            this.fieldGridView.Rows.Add(new object[] { priority, FieldType.Column, onSheetLabel, dimName, isTimeSeries, hidden, null, null, sample });
        }

        /// <summary>
        /// Adds a field to the editor data representing a dimension put along a row.
        /// </summary>
        /// <param name="priority">The position initially shown by the field editor</param>
        /// <param name="onSheetLabel">The row label</param>
        /// <param name="dimName">The name of the dimension</param>
        /// <param name="isTimeSeries">Specifies whether the dimension is a time series</param>
        /// <param name="hidden">Whether the row shall be shown in the output</param>
        /// <param name="sample">A sample value for a dimension code, used by the TimeEditor</param>
        private void AddRow(int? priority, string onSheetLabel, string dimName, bool isTimeSeries = false, bool hidden = false, string sample = null)
        {
            this.fieldGridView.Rows.Add(new object[] { priority, FieldType.Row, onSheetLabel, dimName, isTimeSeries, hidden, null, null, sample });
        }

        /// <summary>
        /// Adds a field to the editor data representing a constant dimension.
        /// </summary>
        /// <param name="dimName">The dimension label related to the field.</param>
        /// <param name="value">The constant value assigned to the dimension.</param>
        private void AddConstant(string dimName, string value)
        {
            this.fieldGridView.Rows.Add(new object[] { null, FieldType.Constant, null, dimName, false, false, null, value });
        }

        /// <summary>
        /// Adds a field to the editor data representing an attribute.
        /// </summary>
        /// <param name="dimName">The dimension label related to the field.</param>
        /// <param name="colNum">The amount of columns reserved for the attribute.</param>
        private void AddAttribute(string dimName, int colNum)
        {
            this.fieldGridView.Rows.Add(new object[] { null, FieldType.Attribute, null, dimName, false, false, colNum, null });
        }

        /// <summary>
        /// Remove a field with a constant value.
        /// </summary>
        /// <param name="index">The field index.</param>
        private void RemoveConstant(int index)
        {
            Debug.Assert(this.fieldGridView.Rows[index].Cells[(int)FieldColumn.Type].Value.Equals(FieldType.Constant), "Only constants can be removed");
            this.fieldGridView.Rows.RemoveAt(index);
        }

        /// <summary>
        /// Adds a field to the editor data representing the numeric value of the output records.
        /// </summary>
        /// <param name="priority">The position initially shown by the field editor</param>
        /// <param name="name">The label of the numeric value field.</param>
        private void AddValue(int? priority, string name = "Value")
        {
            this.fieldGridView.Rows.Add(new object[] { priority, FieldType.Value, null, name, false, false, null, null });
        }

        /// <summary>Setup a grid row style and settings according to its contents.</summary>
        /// <param name="row">The row that has to be set up.</param>
        private void SetupEditorGridRow(DataGridViewRow row)
        {
            row.Cells.Cast<DataGridViewCell>().ToList().ForEach(x => { x.ReadOnly = true; x.Style = this.inactiveStyle; });
            
            row.Cells[(int)FieldColumn.Dimension].ReadOnly = false;
            row.Cells[(int)FieldColumn.Dimension].Style = this.activeStyle;

            if (row.Cells[(int)FieldColumn.Type].Value.Equals(FieldType.Constant))
            {
                row.Cells[(int)FieldColumn.Value].ReadOnly = false;
                row.Cells[(int)FieldColumn.Value].Style = this.activeStyle;
                row.Cells[(int)FieldColumn.Hidden].ReadOnly = true;
                row.Cells[(int)FieldColumn.Hidden].Style = this.inactiveStyle;
            }
            else if (row.Cells[(int)FieldColumn.Type].Value.Equals(FieldType.Attribute))
            {
                row.Cells[(int)FieldColumn.Attribute].ReadOnly = false;
                row.Cells[(int)FieldColumn.Attribute].Style = this.activeStyle;
                row.Cells[(int)FieldColumn.Hidden].ReadOnly = false;
                row.Cells[(int)FieldColumn.Hidden].Style = this.activeStyle;
            }
            else if (!row.Cells[(int)FieldColumn.Type].Value.Equals(FieldType.Value))
            {
                row.Cells[(int)FieldColumn.IsTimeSeries].ReadOnly = false;
                row.Cells[(int)FieldColumn.IsTimeSeries].Style = this.activeStyle;
                row.Cells[(int)FieldColumn.Hidden].ReadOnly = false;
                row.Cells[(int)FieldColumn.Hidden].Style = this.activeStyle;
            }
        }

        /// <summary>
        /// Run whenever the field editor is loaded. Fills the rows with initial values,
        /// sets their look up and adjusts the button behavior accordingly.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        private void FieldEditor_Load(object sender, EventArgs e)
        {
            this.FillEditorGrid();

            this.fieldGridView.Rows.Cast<DataGridViewRow>().ToList().ForEach(x => this.SetupEditorGridRow(x));

            this.AdjustButtonSensitivity();
        }

        /// <summary>
        /// Triggered whenever the state of a row changes. Only the selection state
        /// change is considered here, other reasons are ignored.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        private void FieldGridView_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e)
        {
            // do something only if the row state change is about a row selection.
            if (e.StateChanged == DataGridViewElementStates.Selected)
            {
                this.AdjustButtonSensitivity();
            }
        }

        /// <summary>
        /// Adjusts the sensitivity of the buttons depending on what row is currently selected.
        /// </summary>
        private void AdjustButtonSensitivity()
        {
            if (!object.ReferenceEquals(this.fieldGridView.CurrentCell, null))
            {
                this.moveUpButton.Enabled = this.fieldGridView.CurrentCell.RowIndex > 0;
                this.moveDownButton.Enabled = this.fieldGridView.CurrentCell.RowIndex < this.fieldGridView.Rows.Count - 1;
            }

            if (!object.ReferenceEquals(this.fieldGridView.CurrentRow, null))
            {
                this.delConstButton.Enabled = this.fieldGridView.CurrentRow.Cells[(int)FieldColumn.Type].Value.Equals(FieldType.Constant);
                this.editTime.Enabled = (bool)this.fieldGridView.CurrentRow.Cells[(int)FieldColumn.IsTimeSeries].Value;
                this.removeAttributeButton.Enabled = (bool)this.fieldGridView.CurrentRow.Cells[(int)FieldColumn.Type].Value.Equals(FieldType.Attribute);
            }
        }

        /// <summary>
        /// Shows a short help guide to the field editor functionalities.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        private void HelpButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show(this, "text", "Field Editor Help", MessageBoxButtons.OK);
        }

        /// <summary>
        /// Triggered whenever a cell is newly selected, the body triggers a row selection in its turn.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        private void FieldGridView_SelectionChanged(object sender, EventArgs e)
        {
            this.editButton.Enabled = (this.fieldGridView.SelectedCells.Count > 0) && !object.ReferenceEquals(this.fieldGridView.CurrentCell, null) && (this.fieldGridView.CurrentCell.Style == this.activeStyle);
            this.editTime.Enabled = !object.ReferenceEquals(this.fieldGridView.CurrentRow, null) && (bool)this.fieldGridView.CurrentRow.Cells[(int)FieldColumn.IsTimeSeries].Value;

            // trigger a selection event for the whole row
            this.fieldGridView.Rows[this.fieldGridView.SelectedCells[0].RowIndex].Selected = true;
            this.AdjustButtonSensitivity();
        }

        /// <summary>
        /// Force the editing of the currently selected cell.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        private void EditButton_Click(object sender, EventArgs e)
        {
            Debug.Assert(this.fieldGridView.Rows.Count > 0, "No rows to edit");
            var cell = this.fieldGridView.CurrentCell;

            if (cell.ColumnIndex == (int)FieldColumn.IsTimeSeries || cell.ColumnIndex == (int)FieldColumn.Hidden)
            {
                cell.Value = !(bool)cell.Value;
            }
            else
            {
                this.fieldGridView.BeginEdit(true);
            }
        }

        /// <summary>
        /// Adds a constant field to the current field setup.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        private void AddConstButton_Click(object sender, EventArgs e)
        {
            var start = this.fieldGridView.CurrentCell.RowIndex;

            this.fieldGridView.Rows.Insert(start, null, FieldType.Constant, null, string.Empty, false, false, string.Empty);
            this.fieldGridView.Rows[start].Cells.Cast<DataGridViewCell>().ToList().ForEach(x => { x.ReadOnly = true; x.Style = this.inactiveStyle; });
            foreach (var c in this.tf.Where(c => c.Key >= start).OrderByDescending(c => c.Key))
            {
                var tmp = c.Value;
                this.tf.Remove(c.Key);
                this.tf.Add(c.Key + 1, tmp);
            }

            this.fieldGridView.Rows[start].Cells[(int)FieldColumn.Dimension].ReadOnly = false;
            this.fieldGridView.Rows[start].Cells[(int)FieldColumn.Dimension].Style = this.activeStyle;
            this.fieldGridView.Rows[start].Cells[(int)FieldColumn.Value].ReadOnly = false;
            this.fieldGridView.Rows[start].Cells[(int)FieldColumn.Value].Style = this.activeStyle;
            this.fieldGridView.Rows[start].Cells[(int)FieldColumn.Hidden].ReadOnly = true;
            this.fieldGridView.Rows[start].Cells[(int)FieldColumn.Hidden].Style = this.inactiveStyle;
            this.fieldGridView.CurrentCell = this.fieldGridView.Rows[start].Cells[(int)FieldColumn.Dimension];
            this.fieldGridView.BeginEdit(true);

            this.AdjustButtonSensitivity();
        }

        /// <summary>
        /// Removes a constant field from the current setup.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        private void DelConstButton_Click(object sender, EventArgs e)
        {
            Debug.Assert(this.fieldGridView.SelectedRows[0].Cells[(int)FieldColumn.Type].Value.Equals(FieldType.Constant), "It is allowed to delete only the rows related to constant dimensions");

            var idx = this.fieldGridView.CurrentCell.RowIndex;
            foreach (var c in this.tf.Where(c => c.Key > idx).OrderBy(c => c.Key))
            {
                var tmp = c.Value;
                this.tf.Remove(c.Key);
                this.tf.Add(c.Key - 1, tmp);
            }

            this.fieldGridView.Rows.RemoveAt(this.fieldGridView.CurrentCell.RowIndex);

            this.AdjustButtonSensitivity();
        }

        /// <summary>
        /// Moves the currently selected row (or the row of the currently selected cell) by one place upwards.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        private void MoveUpButton_Click(object sender, EventArgs e)
        {
            Debug.Assert(this.fieldGridView.CurrentCell.RowIndex > 0, "Row is already the first one");

            var colidx = this.fieldGridView.CurrentCell.ColumnIndex;
            var rowidx = this.fieldGridView.CurrentCell.RowIndex;
            var previous = this.fieldGridView.Rows[rowidx - 1];
            var current = this.fieldGridView.Rows[rowidx];

            // swap time formats
            TimeFormat cmd1 = this.tf.ContainsKey(rowidx) ? this.tf[rowidx] : null;
            TimeFormat cmd2 = this.tf.ContainsKey(rowidx - 1) ? this.tf[rowidx - 1] : null;
            this.tf.Remove(rowidx);
            this.tf.Remove(rowidx - 1);
            if (!object.ReferenceEquals(cmd1, null))
            {
                this.tf.Add(rowidx - 1, cmd1);
            }

            if (!object.ReferenceEquals(cmd2, null))
            {
                this.tf.Add(rowidx, cmd2);
            }

            // swap rows
            this.fieldGridView.Rows.Remove(previous);
            this.fieldGridView.Rows.Remove(current);
            this.fieldGridView.Rows.Insert(rowidx - 1, current);
            this.fieldGridView.Rows.Insert(rowidx, previous);

            // restore selection
            this.fieldGridView.CurrentCell = this.fieldGridView.Rows[rowidx - 1].Cells[colidx];

            // fix for signal hiccups, unfortunately callbacks aren't atomic
            this.AdjustButtonSensitivity();
        }

        /// <summary>
        /// Moves the currently selected row (or the row of the currently selected cell) by one place downwards.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        private void MoveDownButton_Click(object sender, EventArgs e)
        {
            Debug.Assert(this.fieldGridView.CurrentCell.RowIndex < this.fieldGridView.Rows.Count, "Row is already the last one");

            var colidx = this.fieldGridView.CurrentCell.ColumnIndex;
            var rowidx = this.fieldGridView.CurrentCell.RowIndex;
            var current = this.fieldGridView.Rows[rowidx];
            var next = this.fieldGridView.Rows[rowidx + 1];

            // swap time formats
            TimeFormat cmd1 = this.tf.ContainsKey(rowidx) ? this.tf[rowidx] : null;
            TimeFormat cmd2 = this.tf.ContainsKey(rowidx + 1) ? this.tf[rowidx + 1] : null;
            this.tf.Remove(rowidx);
            this.tf.Remove(rowidx + 1);
            if (!object.ReferenceEquals(cmd1, null))
            {
                this.tf.Add(rowidx + 1, cmd1);
            }

            if (!object.ReferenceEquals(cmd2, null))
            {
                this.tf.Add(rowidx, cmd2);
            }

            this.fieldGridView.Rows.Remove(current);
            this.fieldGridView.Rows.Remove(next);
            this.fieldGridView.Rows.Insert(rowidx, next);
            this.fieldGridView.Rows.Insert(rowidx + 1, current);
            this.fieldGridView.CurrentCell = this.fieldGridView.Rows[rowidx + 1].Cells[colidx];

            this.AdjustButtonSensitivity();
        }
        
        /// <summary>
        /// Enable event triggering on cell value change. Used to make changes immediate in case of events
        /// such as the value change in a checkbox.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The arguments related to the event within the cell</param>
        private void FieldGridView_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == (int)FieldColumn.IsTimeSeries && e.RowIndex != -1)
            {
                this.editTime.Enabled = (bool)this.fieldGridView.CurrentRow.Cells[(int)FieldColumn.IsTimeSeries].Value;
            }
        }

        /// <summary>
        /// Specific workaround for value changes in checkboxes inside a grid view
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The parameters related to the event</param>
        private void FieldGridView_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            // End of editing on each click on column of checkbox
            if (e.ColumnIndex == (int)FieldColumn.IsTimeSeries && e.RowIndex != -1)
            {
                this.fieldGridView.EndEdit();
            }
        }

        /// <summary>
        /// What happens when the user clicks on the "edit time" button
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void EditTime_Click(object sender, EventArgs e)
        {
            Debug.Assert((bool)this.fieldGridView.CurrentRow.Cells[(int)FieldColumn.IsTimeSeries].Value, "Time editor button should have been greyed out for this dimension.");

            var t = this.tf.ContainsKey(this.fieldGridView.CurrentRow.Index) ? this.tf[this.fieldGridView.CurrentRow.Index] : null;
            var timeEditor = new TimeEditor(this.fieldGridView.CurrentRow.Index, (string)this.fieldGridView.CurrentRow.Cells[(int)FieldColumn.Sample].Value, t);
            if (!object.ReferenceEquals(t, null) && !this.tf.ContainsKey(this.fieldGridView.CurrentRow.Index))
            {
                this.tf.Add(this.fieldGridView.CurrentRow.Index, t);
            }

            switch (timeEditor.ShowDialog())
            {
                case DialogResult.Cancel:
                    if (!object.ReferenceEquals(timeEditor, null))
                    {
                        timeEditor.Dispose();
                        timeEditor = null;
                    }

                    break;
                case DialogResult.OK:
                    if (!object.ReferenceEquals(timeEditor, null))
                    {
                        if (this.tf.ContainsKey(this.fieldGridView.CurrentRow.Index))
                        {
                            this.tf[this.fieldGridView.CurrentRow.Index] = timeEditor.TimeMapping;
                        }
                        else
                        {
                            this.tf.Add(this.fieldGridView.CurrentRow.Index, timeEditor.TimeMapping);
                        }

                        timeEditor.Dispose();
                        timeEditor = null;
                    }

                    break;
                default:
                    // do nothing
                    break;
            }
        }

        /// <summary>
        /// Callback for the event triggered when the user releases the keyboard key while editing the field table
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the argument of the event</param>
        private void FieldGridView_KeyUp(object sender, KeyEventArgs e)
        {
            if (this.fieldGridView.CurrentCell.ColumnIndex == (int)FieldColumn.IsTimeSeries && !this.fieldGridView.CurrentCell.ReadOnly && e.KeyCode == Keys.Space)
            {
                this.fieldGridView.CurrentCell.Value = !(bool)this.fieldGridView.CurrentCell.Value;
                this.fieldGridView.EndEdit();
            }
        }

        /// <summary>
        /// Adds a new field containing a table attribute.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void AddAttributeButton_Click(object sender, EventArgs e)
        {
            var start = this.fieldGridView.CurrentCell.RowIndex;
            int newoffset;
            if (!int.TryParse(Resources.DefaultAttributeColumn, out newoffset))
            {
                newoffset = 1;
            }

            var src = this.fieldGridView.Rows.Cast<DataGridViewRow>().Where(x => x.Cells[(int)FieldColumn.Type].Value.ToString().Equals(FieldType.Attribute));
            if (src.Any())
            {
                object val = src.Max(x => x.Cells[(int)FieldColumn.Attribute].Value);
                if (!object.ReferenceEquals(val, null))
                {
                    int.TryParse(val.ToString(), out newoffset);
                    newoffset++;
                }
            }

            this.fieldGridView.Rows.Insert(start, null, FieldType.Attribute, null, string.Empty, false, false, newoffset, null, null);
            this.fieldGridView.Rows[start].Cells.Cast<DataGridViewCell>().ToList().ForEach(x => { x.ReadOnly = true; x.Style = this.inactiveStyle; });
            foreach (var c in this.tf.Where(c => c.Key >= start).OrderByDescending(c => c.Key))
            {
                var tmp = c.Value;
                this.tf.Remove(c.Key);
                this.tf.Add(c.Key + 1, tmp);
            }

            this.fieldGridView.Rows[start].Cells[(int)FieldColumn.Dimension].ReadOnly = false;
            this.fieldGridView.Rows[start].Cells[(int)FieldColumn.Dimension].Style = this.activeStyle;
            this.fieldGridView.Rows[start].Cells[(int)FieldColumn.Attribute].ReadOnly = false;
            this.fieldGridView.Rows[start].Cells[(int)FieldColumn.Attribute].Style = this.activeStyle;
            this.fieldGridView.Rows[start].Cells[(int)FieldColumn.Hidden].ReadOnly = false;
            this.fieldGridView.Rows[start].Cells[(int)FieldColumn.Hidden].Style = this.activeStyle;

            this.fieldGridView.CurrentCell = this.fieldGridView.Rows[start].Cells[(int)FieldColumn.Dimension];
            this.fieldGridView.BeginEdit(true);

            this.AdjustButtonSensitivity();
        }

        /// <summary>
        /// Removes the current attribute field from the field list.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void RemoveAttributeButton_Click(object sender, EventArgs e)
        {
            if (!this.fieldGridView.SelectedRows[0].Cells[(int)FieldColumn.Type].Value.Equals(FieldType.Attribute))
            {
                return;
            }

            var idx = this.fieldGridView.CurrentCell.RowIndex;
            foreach (var c in this.tf.Where(c => c.Key > idx).OrderBy(c => c.Key))
            {
                var tmp = c.Value;
                this.tf.Remove(c.Key);
                this.tf.Add(c.Key - 1, tmp);
            }

            this.fieldGridView.Rows.RemoveAt(this.fieldGridView.CurrentCell.RowIndex);

            this.AdjustButtonSensitivity();
        }

        /// <summary>
        /// Callback called during the validation phase of the cell contents.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event parameters</param>
        private void FieldGridView_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            var row = this.fieldGridView.Rows[e.RowIndex];

            if (row.Cells[(int)FieldColumn.Type].Value.Equals(FieldType.Attribute) && e.ColumnIndex == this.fieldGridView.Columns[(int)FieldColumn.Attribute].Index)
            {
                row.ErrorText = string.Empty;
                int val;
                int min, max;

                if (!int.TryParse(Resources.DefaultAttributeColumn, out min))
                {
                    min = 1;
                }

                max = this.fieldGridView.Rows.Cast<DataGridViewRow>().Where(x => x.Cells[(int)FieldColumn.Type].Value.Equals(FieldType.Attribute)).Count();

                if (!int.TryParse(e.FormattedValue.ToString(), out val) || val < min || val > max)
                {
                    e.Cancel = true;
                    row.ErrorText = "the value must be a Positive integer";
                }
            }
        }
    }
}
