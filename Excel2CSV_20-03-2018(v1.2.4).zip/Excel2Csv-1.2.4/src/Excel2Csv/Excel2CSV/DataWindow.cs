﻿//-----------------------------------------------------------------------
// <copyright file="DataWindow.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Windows.Forms;
    using System.Xml;
    using System.Xml.Linq;
    using Excel2Csv.Properties;

    /// <summary>
    /// Class for the main window of the application.
    /// </summary>
    public partial class DataWindow : MdiChild
    {
        /// <summary>The reader of the sheet.</summary>
        private TableReader<DataField> reader = null;

        /// <summary>Last configuration for table boundaries.</summary>
        private BoundaryFieldConfig lastConfig = null;

        /// <summary>Old index for the currently selected expression number</summary>
        private int? oldExpNum;

        /// <summary>Index for the currently selected expression number</summary>
        private int currentExpNum;

        /// <summary>
        /// Initializes a new instance of the <see cref="DataWindow" /> class.
        /// </summary>
        /// <param name="statusMessage">Base status message to be shown in the status bar</param>
        public DataWindow(string statusMessage = null) : base(statusMessage)
        {
            this.InitializeComponent();

            this.encodingBox.ValueMember = "EncodingName";
            this.txtFieldSep.Text = Resources.DefaultSeparator;

            // populate encoding box
            foreach (var encoding in Encoding.GetEncodings()) 
            {
                this.encodingBox.Items.Add(encoding.GetEncoding());
            }
            
            // set utf8 as the default encoding
            this.encodingBox.SelectedItem = Encoding.GetEncodings()
                .Where(x => (x.GetEncoding() == Encoding.UTF8)).FirstOrDefault().GetEncoding();

            this.cbExpression.Enabled = this.codeDescDim.Checked;

            this.ResetCodeDescExpressions();
            this.cbExpression.DataSource = this.CodeDescExpressions;
        }

        /// <summary>Gets a newly created configuration by fetching the current table boundaries.</summary>
        public override BoundaryFieldConfig CurrentConfig
        {
            get
            {
                return new BoundaryFieldConfig()
                {
                    Source = this.txtSourcePath.Text,
                    FirstColumn = this.firstColumnSelector.Text,
                    FirstRow = this.firstRowSelector.Text,
                    LastColumn = this.lastColumnSelector.Text,
                    LastRow = this.lastRowSelector.Text,
                    SideWidth = (int)this.sideWidthSelector.Value,
                    TopHeight = (int)this.topHeightSelector.Value,
                    DataColumn = this.dataColumnSelector.Text,
                    DataRow = this.dataRowSelector.Text,
                    Workbook = (int)this.workbookUpDown.Value
                };
            }
        }

        /// <summary>
        /// Checks whether all the mandatory fields of the window have been filled.
        /// </summary>
        /// <returns>True when all the mandatory fields are filled, false otherwise.</returns>
        protected override bool AreMandatoryFieldsFilled()
        {
            return !string.IsNullOrEmpty(this.txtSourcePath.Text) && !string.IsNullOrEmpty(this.txtDestinationPath.Text);
        }

        /// <summary>
        /// The callback for the "Source" button.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        private void BtnFileChooser_Click(object sender, EventArgs e)
        {
            DialogResult result = this.selectFileDialog.ShowDialog();
            if (result == DialogResult.OK) 
            {
                this.txtSourcePath.Text = this.selectFileDialog.FileName;
            }
        }

        /// <summary>
        /// The callback for the "Destination" button.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        private void BtnDestinationChooser_Click(object sender, EventArgs e)
        {
            DialogResult result = this.saveFileDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                this.txtDestinationPath.Text = this.saveFileDialog.FileName;
            }
        }

        /// <summary>
        /// The callback for the "Ok" button.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        private void BtnOk_Click(object sender, EventArgs e)
        {
            string csvFile = this.txtDestinationPath.Text;
            int decimals = (int)this.decimalUpDown.Value;
            bool showHeader = this.showHeader.Checked;
            string decSeparator = this.txtDecSep.Text;
            string fieldSeparator = this.txtFieldSep.Text;
            bool allowNonNumericData = this.cbAllowEverything.Checked;

            if (!this.AreMandatoryFieldsFilled()) 
            {
                MessageBox.Show(Resources.MandatoryFieldsNotFilled, Resources.IncompleteParameters, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                if (object.ReferenceEquals(this.reader, null))
                {
                    this.reader = new TableReader<DataField>(this.CurrentConfig);
                }
                else if (!object.ReferenceEquals(this.lastConfig, null))
                {
                    var cc = this.CurrentConfig;
                    if (!this.lastColumnSelector.Text.Equals(this.lastConfig.LastCell.ColumnLabel) || 
                        !this.lastRowSelector.Text.Equals(this.lastConfig.LastCell.RowLabel) ||
                        !this.dataColumnSelector.Text.Equals(this.lastConfig.DataStartCell.ColumnLabel) ||
                        !this.dataRowSelector.Text.Equals(this.lastConfig.DataStartCell.RowLabel))
                    {
                        var fs = this.reader.GetOrCreateFields;
                        this.reader = new TableReader<DataField>(cc);
                        this.reader.Fields = fs;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

#if DEBUG
            this.reader.WriteRecords(csvFile, (Encoding)this.encodingBox.SelectedItem, decimals, decSeparator, fieldSeparator, this.codeDescDim.Checked, this.cbExpression.SelectedItem as CodeDescExp, allowNonNumericData, showHeader);
#else
            try
            {
                this.reader.WriteRecords(csvFile, (Encoding)this.encodingBox.SelectedItem, decimals, decSeparator, fieldSeparator, this.codeDescDim.Checked, this.cbExpression.SelectedItem as CodeDescExp, allowNonNumericData, showHeader);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
#endif

            MessageBox.Show(
                string.Format(
                    "{0}\n{1} {2}",
                    Resources.Done,
                    Resources.RecordsWritten,
                    object.ReferenceEquals(this.reader, null) ? 0 : this.reader.LastWrittenRecords),
                Resources.DoneTitle,
                MessageBoxButtons.OK, 
                MessageBoxIcon.Information);
        }

        /// <summary>
        /// The callback for the field editor button.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        private void FieldEditorButton_Click(object sender, EventArgs e)
        {
            var newconfig = this.CurrentConfig;
            if (object.ReferenceEquals(this.reader, null) || newconfig != this.lastConfig)
            {
                try
                {
                    this.reader = new TableReader<DataField>(this.CurrentConfig);
                    this.lastConfig = newconfig;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            FieldEditor fieldEditor = null;
            List<DataField> oldstruct = null;
            try
            {
                var fields = this.reader.GetOrCreateFields;
                fieldEditor = new FieldEditor(fields);
                oldstruct = fields.ToList();
            }
            catch
            {
                return;
            }

            if (!object.ReferenceEquals(fieldEditor, null))
            {
                switch (fieldEditor.ShowDialog())
                {
                    case DialogResult.Cancel:
                        if (!object.ReferenceEquals(fieldEditor, null))
                        {
                            fieldEditor.Dispose();
                            fieldEditor = null;
                        }

                        break;
                    case DialogResult.OK:
                        if (!object.ReferenceEquals(fieldEditor, null))
                        {
                            this.reader.Fields = fieldEditor.Structure;
                            try
                            {
                                this.reader.UpdateTime();

                                fieldEditor.Dispose();
                                fieldEditor = null;
                            }
                            catch (CellContentException ex)
                            {
                                MessageBox.Show(fieldEditor, ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                this.reader.Fields.Clear();
                                this.reader.Fields = oldstruct;
                            }
                        }

                        break;
                    default:
                        // do nothing
                        break;
                }
            }
        }

        /// <summary>
        /// Triggered whenever the Load button is pressed
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void BtnLoad_Click(object sender, EventArgs e)
        {
            DialogResult result = this.loadConfigDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                this.LoadXml(this.loadConfigDialog.FileName);
            }
        }

        /// <summary>
        /// Triggered whenever the Save button is pressed
        /// </summary>
        /// <param name="sender">the sender object</param>
        /// <param name="e">the event arguments</param>
        private void BtnSave_Click(object sender, EventArgs e)
        {
            DialogResult result = this.saveConfigDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                this.WriteXml(this.saveConfigDialog.FileName);
            }
        }

        /// <summary>
        /// Opens and parses an xml parameter file.
        /// </summary>
        /// <param name="fullPath">The file that shall be opened.</param>
        private void LoadXml(string fullPath)
        {
            XDocument xdoc = null;

            try
            {
                xdoc = XDocument.Load(fullPath);
            }
            catch
            {
                MessageBox.Show(this, string.Format("Contents of file {0} are not valid.", fullPath), Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            this.ResetCodeDescExpressions();

            XElement main = xdoc.Descendants(Resources.XmlRoot).FirstOrDefault().Descendants(Resources.XmlSettings).FirstOrDefault();

            if (object.ReferenceEquals(main, null))
            {
                MessageBox.Show(this, Resources.InvalidXmlDataFile, Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            this.txtSourcePath.Text = this.SafelyGetXElementValue(main.Element(Resources.XmlSource)) ?? string.Empty;
            this.txtDestinationPath.Text = this.SafelyGetXElementValue(main.Element(Resources.XmlDestination)) ?? string.Empty;
            this.AssignValueToNUD(this.dataColumnSelector, this.SafelyGetXElementValue(main.Element(Resources.XmlDataStartColumn)));
            this.AssignValueToNUD(this.dataRowSelector, this.SafelyGetXElementValue(main.Element(Resources.XmlDataStartRow)));
            this.AssignValueToNUD(this.firstColumnSelector, this.SafelyGetXElementValue(main.Element(Resources.XmlFirstColumn)));
            this.AssignValueToNUD(this.firstRowSelector, this.SafelyGetXElementValue(main.Element(Resources.XmlFirstRow)));
            this.AssignValueToNUD(this.topHeightSelector, this.SafelyGetXElementValue(main.Element(Resources.XmlHeaderHeight)));
            this.AssignValueToNUD(this.sideWidthSelector, this.SafelyGetXElementValue(main.Element(Resources.XmlSideWidth)));
            this.AssignValueToNUD(this.lastColumnSelector, this.SafelyGetXElementValue(main.Element(Resources.XmlLastColumn)));
            this.AssignValueToNUD(this.lastRowSelector, this.SafelyGetXElementValue(main.Element(Resources.XmlLastRow)));
            this.AssignValueToNUD(this.workbookUpDown, this.SafelyGetXElementValue(main.Element(Resources.XmlSheetNumber)));
            this.showHeader.Checked = this.CastValueToBool(this.SafelyGetXElementValue(main.Element(Resources.XmlWriteHeader)));
            this.cbAllowEverything.Checked = this.CastValueToBool(this.SafelyGetXElementValue(main.Element(Resources.XmlAllowNonNumericValues)));
            this.AssignValueToNUD(this.decimalUpDown, this.SafelyGetXElementValue(main.Element(Resources.XmlMaxDecimals)));
            this.txtDecSep.Text = this.SafelyGetXElementValue(main.Element(Resources.XmlDecimalSeparator)) ?? string.Empty;
            this.txtFieldSep.Text = this.SafelyGetXElementValue(main.Element(Resources.XmlFieldSeparator)) ?? Resources.DefaultSeparator;
            this.codeDescDim.Checked = this.CastValueToBool(this.SafelyGetXElementValue(main.Element(Resources.XmlDimensionsAsCodeDesc)));

            string encstr = this.SafelyGetXElementValue(main.Element(Resources.XmlOutputEncoding));
            var encoding = Encoding.GetEncodings().Where(x => (x.GetEncoding().EncodingName == encstr)).FirstOrDefault();
            this.encodingBox.SelectedItem = object.ReferenceEquals(encoding, null) ? Encoding.UTF8 : encoding.GetEncoding();

            if (object.ReferenceEquals(this.reader, null))
            {
                try
                {
                    this.reader = new TableReader<DataField>(this.CurrentConfig);
                }
                catch (Exception e)
                {
                    MessageBox.Show(this, string.Format("Could not open the source file to set the fields up.\nReason: {0}", e.Message), Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            if (!object.ReferenceEquals(this.reader.Fields, null))
            {
                foreach (var field in this.reader.Fields)
                {
                    field.TimeMapping = null;
                }

                this.reader.Fields = null;
            }

            this.reader.Fields = new List<DataField>();
            foreach (var xmlfield in main.Descendants(Resources.XmlField))
            {
                int cmd;
                int? priority;
                int attrcol;
                TimeFormat tf = null;

                if (!int.TryParse(this.SafelyGetXElementValue(xmlfield.Element(Resources.XmlFieldPriority)), out cmd))
                {
                    priority = null;
                }
                else
                {
                    priority = cmd;
                }

                if (!int.TryParse(this.SafelyGetXElementValue(xmlfield.Element(Resources.XmlFieldAttribute)), out attrcol))
                {
                    if (!int.TryParse(Resources.DefaultAttributeColumn, out attrcol))
                    {
                        attrcol = 1;
                    }
                }

                if (!object.ReferenceEquals(xmlfield.Element(Resources.XmlFieldTimeFormat), null))
                {
                    int v;

                    tf = new TimeFormat();
                    int.TryParse(this.SafelyGetXElementValue(xmlfield.Element(Resources.XmlFieldTimeFormat).Element(Resources.XmlFieldTimeIsDate)), out v);
                    if (v < 0 || v >= Enum.GetValues(typeof(TimePeriod)).Length)
                    {
                        v = 0;
                    }

                    tf.DateCast = (TimePeriod)v;
                    tf.IsDate = true.ToString().Equals(this.SafelyGetXElementValue(xmlfield.Element(Resources.XmlFieldTimeFormat).Element(Resources.XmlFieldTimeIsDate)));

                    foreach (TimePeriod tp in Enum.GetValues(typeof(TimePeriod)))
                    {
                        var period = xmlfield.Descendants(Resources.XmlFieldTimeFormat).Elements()
                            .FirstOrDefault(x => this.SafelyGetXElementValue(x.Attribute(Resources.XmlFieldTimePeriodAttribute)).Equals(tp.ToString()));

                        if (object.ReferenceEquals(period, null))
                        {
                            continue;
                        }

                        FrequencyFormat ff = new FrequencyFormat();
                        ff.Enabled = true.ToString().Equals(period.Element(Resources.XmlFieldTimePeriodEnabled).Value);

                        var year = period.Element(Resources.XmlFieldTimePeriodYear);
                        if (!object.ReferenceEquals(year, null))
                        {
                            ff.YearInFrequencyExpression = this.SafelyGetXElementValue(year.Element(Resources.XmlFieldTimePeriodExpression));
                            ff.YearRange = new Range()
                            {
                                Start = this.SafelyGetXElementInt(year.Element(Resources.XmlFieldTimePeriodStart)),
                                End = this.SafelyGetXElementInt(year.Element(Resources.XmlFieldTimePeriodEnd))
                            };
                        }

                        var freq = period.Element(Resources.XmlFieldTimePeriodFrequency);
                        if (!object.ReferenceEquals(freq, null))
                        {
                            ff.PeriodInFrequencyExpression = this.SafelyGetXElementValue(freq.Element(Resources.XmlFieldTimePeriodExpression));
                            ff.PeriodRange = new Range()
                            {
                                Start = this.SafelyGetXElementInt(freq.Element(Resources.XmlFieldTimePeriodStart)),
                                End = this.SafelyGetXElementInt(freq.Element(Resources.XmlFieldTimePeriodEnd))
                            };
                        }

                        int size = 0;
                        switch (tp)
                        {
                            case TimePeriod.Quarterly:
                                size = (int)FrequencyTypeSizes.Quarterly;
                                tf.Quarterly = ff;
                                break;
                            case TimePeriod.HalfYearly:
                                size = (int)FrequencyTypeSizes.HalfYearly;
                                tf.HalfYearly = ff;
                                break;
                            case TimePeriod.Yearly:
                                tf.Yearly = ff;
                                break;
                            default:
                                size = (int)FrequencyTypeSizes.Monthly;
                                tf.Monthly = ff;
                                break;
                        }

                        if (size <= 0)
                        {
                            continue;
                        }

                        ff.PeriodMapping = new string[size];
                        var mapping = period.Element(Resources.XmlFieldTimeMapping);
                        if (!object.ReferenceEquals(mapping, null))
                        {
                            var descs = mapping.Descendants(Resources.XmlFieldTimeMappingElement);
                            for (int i = 0; i < descs.Count() && i < size; i++)
                            {
                                ff.PeriodMapping[i] = this.SafelyGetXElementValue(descs.ElementAt(i));
                            }
                        }
                    }
                }

                var isTimeSeries = xmlfield.Element(Resources.XmlFieldIsTimeSeries);
                var hidden = xmlfield.Element(Resources.XmlFieldHidden);

                this.reader.Fields.Add(new DataField()
                {
                    Priority = priority,
                    Type = xmlfield.Element(Resources.XmlFieldType).Value,
                    Label = xmlfield.Element(Resources.XmlFieldLabel).Value,
                    Dimension = xmlfield.Element(Resources.XmlFieldDimension).Value,
                    Value = xmlfield.Element(Resources.XmlFieldValue).Value,
                    IsTimeSeries = !object.ReferenceEquals(isTimeSeries, null) ? this.CastValueToBool(isTimeSeries.Value) : false,
                    Hidden = !object.ReferenceEquals(hidden, null) ? this.CastValueToBool(hidden.Value) : false,
                    Sample = xmlfield.Element(Resources.XmlFieldSample).Value,
                    AttributeColumn = attrcol,
                    TimeMapping = tf
                });
            }

            var expset = main.Descendants(Resources.XmlDimExpressions).FirstOrDefault();
            if (!object.ReferenceEquals(expset, null))
            {
                foreach (var xmlexp in expset.Descendants(Resources.XmlDimExpression))
                {
                    string pattern = this.SafelyGetXElementValue(xmlexp.Element(Resources.XmlDimExprString)) ?? string.Empty;
                    var code = xmlexp.Descendants(Resources.XmlDimExprCode).FirstOrDefault();
                    var desc = xmlexp.Descendants(Resources.XmlDimExprDesc).FirstOrDefault();

                    if (!object.ReferenceEquals(code, null) && !object.ReferenceEquals(desc, null))
                    {
                        CodeDescExp exp = new CodeDescExp(
                            CodeDescExpType.Custom,
                            pattern,
                            pattern,
                            new Range()
                            {
                                Start = this.SafelyGetXElementInt(code.Element(Resources.XmlDimExprStart)),
                                End = this.SafelyGetXElementInt(code.Element(Resources.XmlDimExprEnd))
                            },
                            new Range()
                            {
                                Start = this.SafelyGetXElementInt(desc.Element(Resources.XmlDimExprStart)),
                                End = this.SafelyGetXElementInt(desc.Element(Resources.XmlDimExprEnd))
                            });

                        exp.Trim = this.CastValueToBool(xmlexp.Element(Resources.XmlDimTrimParts).Value);
                        this.CodeDescExpressions.Insert(this.CodeDescExpressions.Count - 1, exp);
                    }
                }
            }

            this.cbExpression.SelectedIndexChanged -= this.CbExpression_SelectedIndexChanged;

            try
            {
                this.cbExpression.DataSource = null;
                this.cbExpression.DataSource = this.CodeDescExpressions;
            }
            finally
            {
                this.cbExpression.SelectedIndexChanged += this.CbExpression_SelectedIndexChanged;
            }

            int idx = this.SafelyGetXElementInt(main.Element(Resources.XmlDimExprIndex));
            this.cbExpression.SelectedIndex = (idx < this.cbExpression.Items.Count) ? idx : default(int);

            // workaround to make the application accept the new settings when the user newly sets the fields up.
            this.lastConfig = this.CurrentConfig;
        }

        /// <summary>
        /// Writes a new xml file and fills it with the current parameters and settings.
        /// </summary>
        /// <param name="fullPath">The full pathname of the new xml file.</param>
        private void WriteXml(string fullPath)
        {
            XmlWriterSettings ws = new XmlWriterSettings();

            ws.ConformanceLevel = ConformanceLevel.Fragment;
            ws.OmitXmlDeclaration = true;
            ws.Encoding = System.Text.Encoding.UTF8;
            ws.Indent = true;
            ws.IndentChars = Resources.XmlIndentChars;
            
            using (XmlWriter writer = XmlWriter.Create(fullPath, ws))
            {
                writer.WriteStartElement(Resources.XmlRoot);
                writer.WriteAttributeString(Resources.XmlNs, Resources.XmlInstance, null, Resources.XmlXsi);
                writer.WriteAttributeString(Resources.XmlNs, Resources.XmlDefinition, null, Resources.XmlXsd);
                writer.WriteAttributeString(Resources.XmlVersionAttribute, Resources.XmlVersion);

                writer.WriteStartElement(Resources.XmlSettings);

                this.WriteSimpleCDataWithXmlTag(writer, Resources.XmlSource, this.txtSourcePath.Text);
                this.WriteSimpleCDataWithXmlTag(writer, Resources.XmlDestination, this.txtDestinationPath.Text);
                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlDataStartColumn, this.dataColumnSelector.Text);
                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlDataStartRow, this.dataRowSelector.Text);
                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFirstColumn, this.firstColumnSelector.Text);
                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFirstRow, this.firstRowSelector.Text);
                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlHeaderHeight, this.topHeightSelector.Text);
                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlSideWidth, this.sideWidthSelector.Text);
                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlLastColumn, this.lastColumnSelector.Text);
                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlLastRow, this.lastRowSelector.Text);
                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlSheetNumber, this.workbookUpDown.Text);
                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlOutputEncoding, ((Encoding)this.encodingBox.SelectedItem).EncodingName);
                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlWriteHeader, this.showHeader.Checked.ToString());
                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlAllowNonNumericValues, this.cbAllowEverything.Checked.ToString());
                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlMaxDecimals, this.decimalUpDown.Text);
                this.WriteSimpleCDataWithXmlTag(writer, Resources.XmlDecimalSeparator, this.txtDecSep.Text);
                this.WriteSimpleCDataWithXmlTag(writer, Resources.XmlFieldSeparator, this.txtFieldSep.Text);
                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlDimensionsAsCodeDesc, this.codeDescDim.Checked.ToString());

                this.WriteSimpleStringWithXmlTag(writer, Resources.XmlDimExprIndex, this.cbExpression.SelectedIndex.ToString());
                writer.WriteStartElement(Resources.XmlDimExpressions);
                
                foreach (var expr in this.CodeDescExpressions.Where(i => i.CodeType == CodeDescExpType.Custom))
                {
                    writer.WriteStartElement(Resources.XmlDimExpression);

                    this.WriteSimpleCDataWithXmlTag(writer, Resources.XmlDimExprString, expr.Expression);

                    writer.WriteStartElement(Resources.XmlDimExprCode);
                    this.WriteSimpleStringWithXmlTag(writer, Resources.XmlDimExprStart, expr.CodeRange.Start.ToString());
                    this.WriteSimpleStringWithXmlTag(writer, Resources.XmlDimExprEnd, expr.CodeRange.End.ToString());
                    writer.WriteEndElement();
                    
                    writer.WriteStartElement(Resources.XmlDimExprDesc);
                    this.WriteSimpleStringWithXmlTag(writer, Resources.XmlDimExprStart, expr.DescriptionRange.Start.ToString());
                    this.WriteSimpleStringWithXmlTag(writer, Resources.XmlDimExprEnd, expr.DescriptionRange.End.ToString());
                    writer.WriteEndElement();
                    
                    this.WriteSimpleStringWithXmlTag(writer, Resources.XmlDimTrimParts, expr.Trim.ToString());

                    writer.WriteEndElement();
                }

                writer.WriteEndElement();

                if (!object.ReferenceEquals(this.reader, null))
                {
                    foreach (var field in this.reader.Fields)
                    {
                        writer.WriteStartElement(Resources.XmlField);

                        this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldPriority, !object.ReferenceEquals(field.Priority, null) ? field.Priority.ToString() : string.Empty);
                        this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldType, field.Type);
                        this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldLabel, field.Label);
                        this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldDimension, field.Dimension);
                        this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldValue, ((DataField)field).Value);
                        this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldSample, field.Sample);
                        this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldIsTimeSeries, field.IsTimeSeries.ToString());
                        this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldHidden, field.Hidden.ToString());
                        this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldAttribute, field.AttributeColumn.ToString());

                        if (!object.ReferenceEquals(field.TimeMapping, null))
                        {
                            writer.WriteStartElement(Resources.XmlFieldTimeFormat);

                            this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldTimeIsDate, field.TimeMapping.IsDate.ToString());
                            this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldTimeCastType, ((int)field.TimeMapping.DateCast).ToString());
                            int ti = 0;

                            foreach (FrequencyFormat ff in new FrequencyFormat[] { field.TimeMapping.Monthly, field.TimeMapping.Quarterly, field.TimeMapping.HalfYearly, field.TimeMapping.Yearly })
                            {
                                if (!object.ReferenceEquals(ff, null))
                                {
                                    writer.WriteStartElement(Resources.XmlFieldTimePeriod);
                                    writer.WriteStartAttribute(Resources.XmlFieldTimePeriodAttribute);
                                    writer.WriteString(((TimePeriod)ti).ToString());
                                    writer.WriteEndAttribute();
                                    this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldTimePeriodEnabled, ff.Enabled.ToString());

                                    writer.WriteStartElement(Resources.XmlFieldTimePeriodYear);
                                    this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldTimePeriodExpression, ff.YearInFrequencyExpression);
                                    this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldTimePeriodStart, ff.YearRange.Start.ToString());
                                    this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldTimePeriodEnd, ff.YearRange.End.ToString());
                                    writer.WriteEndElement(); // XmlFieldTimePeriodYear

                                    this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldTimeHasPeriodMapping, ff.HasPeriodMapping.ToString());

                                    writer.WriteStartElement(Resources.XmlFieldTimePeriodFrequency);
                                    this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldTimePeriodExpression, ff.PeriodInFrequencyExpression);
                                    this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldTimePeriodStart, ff.PeriodRange.Start.ToString());
                                    this.WriteSimpleStringWithXmlTag(writer, Resources.XmlFieldTimePeriodEnd, ff.PeriodRange.End.ToString());
                                    writer.WriteEndElement(); // XmlFieldTimePeriodFrequency

                                    if (!object.ReferenceEquals(ff.PeriodMapping, null) && ff.PeriodMapping.Length > 0)
                                    {
                                        writer.WriteStartElement(Resources.XmlFieldTimeMapping);
                                        for (int i = 0; i < ff.PeriodMapping.Length; i++)
                                        {
                                            this.WriteSimpleCDataWithXmlTag(writer, Resources.XmlFieldTimeMappingElement, ff.PeriodMapping[i]);
                                        }

                                        writer.WriteEndElement(); // XmlFieldTimeMapping
                                    }

                                    writer.WriteEndElement(); // XmlFieldTimeMonthly
                                }

                                ti++;
                            }

                            writer.WriteEndElement(); // XmlFieldTimeFormat
                        }

                        writer.WriteEndElement(); // XmlField
                    }
                }

                writer.WriteEndElement(); // Settings
                writer.WriteEndElement(); // XmlRoot
            }
        }

        /// <summary>
        /// Callback used to enable the expression parsing.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void CodeDescDim_CheckedChanged(object sender, EventArgs e)
        {
            this.cbExpression.Enabled = this.codeDescDim.Checked;
        }

        /// <summary>
        /// Callback called whenever a user changes the selected expression in the combo box.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void CbExpression_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.cbExpression.Items.Count == 0)
            {
                return;
            }

            this.oldExpNum = this.currentExpNum;
            this.currentExpNum = this.cbExpression.SelectedIndex;

            if (CodeDescExpType.InputRequest == (this.cbExpression.SelectedValue as CodeDescExp).CodeType)
            {
                var exprEditor = new ExpressionEditor();

                switch (exprEditor.ShowDialog())
                {
                    case DialogResult.OK:
                        this.cbExpression.SelectedIndexChanged -= this.CbExpression_SelectedIndexChanged;
                        try
                        {
                            int idx = this.CodeDescExpressions.Count - 1;
                            var newExp = new CodeDescExp(CodeDescExpType.Custom, exprEditor.Expression, exprEditor.Expression, exprEditor.CodeRange, exprEditor.DescRange);
                            newExp.Trim = exprEditor.Trim;
                            this.CodeDescExpressions.Insert(idx, newExp);

                            // just refreshing the combobox won't do
                            this.cbExpression.DataSource = null;
                            this.cbExpression.DataSource = this.CodeDescExpressions;

                            this.cbExpression.SelectedIndex = idx;
                        }
                        finally
                        {
                            exprEditor.Dispose();
                            exprEditor = null;
                            this.cbExpression.SelectedIndexChanged += this.CbExpression_SelectedIndexChanged;
                        }

                        break;
                    case DialogResult.Cancel:
                    default:
                        exprEditor.Dispose();
                        exprEditor = null;
                        this.currentExpNum = this.oldExpNum ?? default(int);
                        this.oldExpNum = null;
                        this.cbExpression.SelectedIndex = this.currentExpNum;
                        break;
                }
            }
        }
    }
}
