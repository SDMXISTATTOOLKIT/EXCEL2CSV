﻿//-----------------------------------------------------------------------
// <copyright file="CellPosition.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using System;
    using Excel2Csv.Properties;

    /// <summary>Represents the location of a cell inside a sheet.</summary>
    public class CellPosition
    {
        /// <summary>Internal row representation</summary>
        private int innerRow;

        /// <summary>Internal column representation</summary>
        private int innerCol;

        /// <summary>
        /// Initializes a new instance of the <see cref="CellPosition" /> class,
        /// using its row and column label representations as they appear in Excel.
        /// </summary>
        /// <param name="rowLabel">The row label.</param>
        /// <param name="columnLabel">The column label.</param>
        public CellPosition(int rowLabel, string columnLabel)
        {
            this.RowLabel = rowLabel;
            this.ColumnLabel = columnLabel;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CellPosition" /> class,
        /// using its row and column numbers as assigned by the NPOI library.
        /// </summary>
        /// <param name="rowNumber">The row number.</param>
        /// <param name="columnNumber">The column number.</param>
        public CellPosition(int rowNumber, int columnNumber)
        {
            this.RowNumber = rowNumber;
            this.ColumnNumber = columnNumber;
        }

        /// <summary>
        /// Gets or sets the label of the row as it appears in Excel.
        /// </summary>
        public int RowLabel
        {
            get
            {
                return this.innerRow + 1;
            }

            set
            {
                if (value < 1)
                { 
                    throw new InvalidOperationException(string.Format(Resources.InvalidRowLabel, value)); 
                }

                this.innerRow = value - 1;
            }
        }

        /// <summary>
        /// Gets or sets the label of the column as it appears in Excel.
        /// </summary>
        public string ColumnLabel
        {
            get
            {
                return TableColumnLabeling.ColumnForNumber(this.innerCol + 1);
            }

            set
            {
                if (!TableColumnLabeling.IsColumn(value))
                {
                    throw new InvalidOperationException(string.Format(Resources.InvalidColumnLabel, value));
                }

                this.innerCol = TableColumnLabeling.NumberForColumn(value) - 1;
            }
        }

        /// <summary>
        /// Gets or sets the number of the row as referred to by the NPOI library.
        /// </summary>
        public int RowNumber
        {
            get
            {
                return this.innerRow;
            }

            set
            {
                if (value < 0) 
                {
                    throw new InvalidOperationException(string.Format(Resources.InvalidRowNumber, value));
                }

                this.innerRow = value;
            }
        }

        /// <summary>
        /// Gets or sets the number of the column as referred to by the NPOI library.
        /// </summary>
        public int ColumnNumber
        {
            get
            {
                return this.innerCol;
            }

            set
            {
                if (value < 0) 
                {
                    throw new InvalidOperationException(string.Format(Resources.InvalidColumnNumber, value));
                }

                this.innerCol = value;
            }
        }

        /// <summary>
        /// Gives a literal representation of the object.
        /// </summary>
        /// <returns>The literal representation of the object.</returns>
        public override string ToString()
        {
            return string.Format("{0}: {1}{2}", this.GetType().ToString(), this.ColumnLabel, this.RowLabel);
        }
    }
}
