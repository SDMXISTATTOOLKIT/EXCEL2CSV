﻿//-----------------------------------------------------------------------
// <copyright file="DimensionField.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    /// <summary>The export structure of a single row in the field editor.</summary>
    public class DimensionField : Field
    {
        /// <summary>Gets or sets a value indicating whether a row or column contains a code list</summary>
        public bool IsCodeList { get; set; }
    }
}
