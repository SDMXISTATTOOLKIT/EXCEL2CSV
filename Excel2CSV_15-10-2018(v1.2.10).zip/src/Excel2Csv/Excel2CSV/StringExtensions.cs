﻿//-----------------------------------------------------------------------
// <copyright file="StringExtensions.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace StringExtensions
{
    using System.Text.RegularExpressions;

    /// <summary>
    /// Extension for the <see cref="System.String"/> class.
    /// </summary>
    public static class StringExtensions
    {
        /// <summary>
        /// Enforces the left-to-right (LTR) reading direction in strings written in right-to-left (RTL) format.
        /// Useful for concatenating LTR and RTL strings together.
        /// This does not really change the string contents.
        /// </summary>
        /// <param name="inputStr">input string</param>
        /// <returns>the string with an enforced LTR reading direction.</returns>
        public static string ForceLTR(this string inputStr)
        {
            string ret = (inputStr ?? string.Empty).Trim();
            Regex detectArabicOrHebrew = new Regex(@"[\p{IsArabic}\p{IsHebrew}]");

            if (detectArabicOrHebrew.IsMatch(ret))
            {
                return string.Format("{0}{1}{2}", '\u202A', ret, '\u202C');
            }

            return ret;
        }

        /// <summary>
        /// Replaces all the occurrences of the new line characters with a given replacement.
        /// </summary>
        /// <param name="inputStr">The input string</param>
        /// <param name="replacement">The replacement for new line characters</param>
        /// <returns>A single-line string</returns>
        public static string ReplaceNewLines(this string inputStr, string replacement)
        {
            return inputStr.Replace(@"\r\n", replacement).Replace(@"\r", replacement).Replace(@"\n", replacement);
        }

        /// <summary>
        /// Removes all the occurrences of the new line characters.
        /// </summary>
        /// <param name="inputStr">The input string</param>
        /// <returns>A single-line string</returns>
        public static string RemoveNewLines(this string inputStr)
        {
            return inputStr.ReplaceNewLines(string.Empty);
        }

        /// <summary>
        /// Replaces all the occurrences of the new line characters with a white space from the trimmed input string
        /// and then removes all multiple whitespaces.
        /// </summary>
        /// <param name="inputStr">The input string</param>
        /// <returns>A single-line string</returns>
        public static string MergeLines(this string inputStr)
        {
            const string Ws = " ";

            return Regex.Replace(inputStr.Trim().ReplaceNewLines(Ws), @"\s+", Ws);
        }

        /// <summary>
        /// Parses a plain string and modifies it so that all the characters that are
        /// considered special in regular expressions become "normal".
        /// </summary>
        /// <param name="instr">The input string</param>
        /// <returns>The modified string</returns>
        public static string DeRegex(this string instr)
        {
            // \, *, +, ?, |, {, [, (,), ^, $,., #
            return instr
                .Replace("\\", "\\\\")
                .Replace(".", "\\.")
                .Replace("|", "\\|")
                .Replace("+", "\\+")
                .Replace("?", "\\?")
                .Replace("#", "\\#")
                .Replace("*", "\\*")
                .Replace("$", "\\$")
                .Replace("^", "\\^")
                .Replace("(", "\\(")
                .Replace(")", "\\)")
                .Replace("[", "\\[")
                .Replace("]", "\\]")
                .Replace("{", "\\{")
                .Replace("}", "\\}");
        }
    }
}
