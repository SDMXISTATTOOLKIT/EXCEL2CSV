﻿//-----------------------------------------------------------------------
// <copyright file="Field.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    /// <summary>Field columns</summary>
    public enum FieldColumn
    {
        /// <summary>Enumerates the rows</summary>
        Priority = 0,

        /// <summary>Specifies the type of CSV field the current row refers to</summary>
        Type,

        /// <summary>Specifies the row or column label on the spreadsheet the current row refers to.</summary>
        Label,

        /// <summary>Labels the current row with a dimension name. Used to add a header to the output CSV.</summary>
        Dimension,

        /// <summary>Shows whether a dimension is a time series.</summary>
        IsTimeSeries,

        /// <summary>Shows whether a dimension shall be hidden</summary>
        Hidden,

        /// <summary>Amount of columns assigned to flags after each data column</summary>
        Attribute,

        /// <summary>Used only for constant dimensions, specifies the value of the constant.</summary>
        Value,

        /// <summary>Used only for dimensions on the sheet, shows a sample value for the dimension.</summary>
        Sample,

        /// <summary>A dummy editor column used to keep a TimeMapping for the current dimension.</summary>
        TimeMapping
    }

    /// <summary>Field columns</summary>
    public enum DimensionColumn
    {
        /// <summary>Enumerates the rows</summary>
        Priority = 0,

        /// <summary>Specifies the type of CSV field the current row refers to</summary>
        Type,

        /// <summary>Specifies the row or column label on the spreadsheet the current row refers to.</summary>
        Label,

        /// <summary>Labels the current row with a dimension name. Used to add a header to the output CSV.</summary>
        Dimension,

        /// <summary>Shows whether a row/column contains a code list</summary>
        IsCodeList,

        /// <summary>Shows whether a dimension is a time series.</summary>
        IsTimeSeries,

        /// <summary>Shows whether a dimension shall be hidden</summary>
        Hidden,

        /// <summary>Used only for dimensions on the sheet, shows a sample value for the dimension.</summary>
        Sample,

        /// <summary>A dummy editor column used to keep a TimeMapping for the current dimension.</summary>
        TimeMapping
    }

    /// <summary>The export structure of a single row in the field editor.</summary>
    public abstract class Field
    {
        /// <summary>Gets or sets the current row</summary>
        public int? Priority { get; set; }

        /// <summary>Gets or sets the type of CSV field the current row refers to</summary>
        public string Type { get; set; }

        /// <summary>Gets or sets the row or column label on the spreadsheet the current row refers to.</summary>
        public string Label { get; set; }

        /// <summary>Gets or sets the current row with a dimension name. Used to add a header to the output CSV.</summary>
        public string Dimension { get; set; }

        /// <summary>Gets or sets a value indicating whether a dimension is a time series</summary>
        public bool IsTimeSeries { get; set; }

        /// <summary>Gets or sets a value indicating whether a dimension shall be kept hidden</summary>
        public bool Hidden { get; set; }

        /// <summary>Gets or sets the time editing status</summary>
        public TimeFormat TimeMapping { get; set; }

        /// <summary>Gets or sets a sample item code (used by the TimeEditor)</summary>
        public string Sample { get; set; }
    }
}
