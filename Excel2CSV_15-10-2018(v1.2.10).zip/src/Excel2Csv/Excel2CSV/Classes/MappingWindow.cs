﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using Excel2Csv.Properties;
using Org.Sdmxsource.Sdmx.Api.Constants;
using Org.Sdmxsource.Sdmx.Api.Constants.InterfaceConstant;
using Org.Sdmxsource.Sdmx.Api.Engine;
using Org.Sdmxsource.Sdmx.Api.Factory;
using Org.Sdmxsource.Sdmx.Api.Manager.Retrieval.Data;
using Org.Sdmxsource.Sdmx.Api.Model;
using Org.Sdmxsource.Sdmx.Api.Model.Objects;
using Org.Sdmxsource.Sdmx.Api.Model.Objects.Codelist;
using Org.Sdmxsource.Sdmx.Api.Model.Objects.Reference;
using Org.Sdmxsource.Sdmx.Api.Util;
using Org.Sdmxsource.Sdmx.DataParser.Engine.Csv;
using Org.Sdmxsource.Sdmx.DataParser.Manager;
using Org.Sdmxsource.Sdmx.SdmxObjects.Model.Data;
using Org.Sdmxsource.Sdmx.SdmxObjects.Model.Mutable.MetadataStructure;
using Org.Sdmxsource.Sdmx.SdmxObjects.Model.Objects.DataStructure;
using Org.Sdmxsource.Sdmx.Structureparser.Manager.Parsing;
using Org.Sdmxsource.Sdmx.StructureRetrieval.Manager;
using Org.Sdmxsource.Sdmx.Util.Objects.Reference;
using Org.Sdmxsource.Util.Io;
using Org.Sdmxsource.Sdmx.Api.Model.Data;
using Org.Sdmxsource.Sdmx.Api.Model.Header;
using Org.Sdmxsource.Sdmx.Api.Model.Mutable.Base;
using Org.Sdmxsource.Sdmx.Api.Model.Objects.Base;
using Org.Sdmxsource.Sdmx.Api.Model.Objects.DataStructure;
using Org.Sdmxsource.Sdmx.DataParser.Engine;
using Org.Sdmxsource.Sdmx.DataParser.Engine.Reader;
using Org.Sdmxsource.Sdmx.SdmxObjects.Model.Header;
using Org.Sdmxsource.Sdmx.SdmxObjects.Model.Mutable.Base;
using Org.Sdmxsource.Sdmx.SdmxObjects.Model.Objects.Base;
using Org.Sdmxsource.Util;

#pragma warning disable 1591

// Mi spiace ma non rispetterò lo stile di coding usato nel progetto (assurdo e rende il codice difficile da leggere, il codice deve essere semplice e leggibile, sempre)
// è una modifica extra (non fa parte dello sviluppo del software) quindi mi permetto di prendermi tutte le libertà nello sviluppo del software tra cui niente file di risorse 
// e niente refactoring delle altre classi se non è indispensabile
namespace Excel2Csv.Classes
{
    public partial class MappingWindow : MdiChild
    {
        private CsvDto2 csvDto;

        private IList<string> dimensionsAtObservation;

        public MappingWindow()
        {
            InitializeComponent();

            cmbSdmxFormats.ValueMember = "Name";

            cmbSdmxFormats.Items.Add(SdmxDataTypeService.Instance.GetDataType(DataEnumType.Generic20));
            //  cmbSdmxFormats.Items.Add(SdmxDataTypeService.Instance.GetDataType(DataEnumType.Compact10));
            cmbSdmxFormats.Items.Add(SdmxDataTypeService.Instance.GetDataType(DataEnumType.Compact20));
            cmbSdmxFormats.Items.Add(SdmxDataTypeService.Instance.GetDataType(DataEnumType.Compact21));
            //      cmbSdmxFormats.Items.Add(SdmxDataTypeService.Instance.GetDataType(DataEnumType.Generic10));
            cmbSdmxFormats.Items.Add(SdmxDataTypeService.Instance.GetDataType(DataEnumType.Generic21));
            //      cmbSdmxFormats.Items.Add(SdmxDataTypeService.Instance.GetDataType(DataEnumType.MessageGroup10Compact));
            //       cmbSdmxFormats.Items.Add(SdmxDataTypeService.Instance.GetDataType(DataEnumType.MessageGroup20Compact));
            //       cmbSdmxFormats.Items.Add(SdmxDataTypeService.Instance.GetDataType(DataEnumType.MessageGroup10Generic));
            //        cmbSdmxFormats.Items.Add(SdmxDataTypeService.Instance.GetDataType(DataEnumType.MessageGroup20Generic));

            cmbSdmxFormats.SelectedIndex = 0;
        }

        // Io questo obbrobrio non lo uso
        public override BoundaryFieldConfig CurrentConfig => null;

        protected override bool AreMandatoryFieldsFilled()
        {
            return true;
        }

        private void btnSourceChooser_Click(object sender, EventArgs e)
        {
            var result = selectFileDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                txtSourcePath.Text = selectFileDialog.FileName;

                loadCsv();
            }
        }

        private void loadCsv()
        {
            using (var progressDialog = new ProgressDialog())
            {
                progressDialog.Text = "Caricamento Csv";
                progressDialog.SetWaiting();
                progressDialog.Show();

                try
                {
                    csvDto = new CsvImport2(txtSourcePath.Text, filedSeparatorTextBox.Text[0], string.IsNullOrEmpty(FieldDelimiterTextBox.Text) ? null : (char?)FieldDelimiterTextBox.Text[0], hasHeaderCheckBox.Checked).LoadHeaders();
                }
                catch (FileNotFoundException)
                {
                    MessageBox.Show(this, "File not Found", Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, ex.Message, Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                csvDataGridView.Rows.Clear();
                csvSelectedListBox.Items.Clear();
                mappingDataGridView.Rows.Clear();

                foreach (var row in dsdDataGridView.Rows.Cast<DataGridViewRow>())
                {
                    row.Cells[3].Value = false;
                }

                foreach (var header in csvDto.Headers)
                {
                    csvDataGridView.Rows.Add(header.Value, false); // false cause is not mapped
                }
            }
            updateDsdButton();
            updateMapButton();
            updateAutoMapButton();
            updateCsvButton();
        }

        private void btnDsdChooser_Click(object sender, EventArgs e)
        {
            DialogResult result = selectDsdFileDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                try
                {
                    txtDestinationPath.Text = selectDsdFileDialog.FileName;
                    if (loadDsd()) return;
                }
                catch (FileNotFoundException)
                {
                    MessageBox.Show(this, "File not Found", Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, ex.Message, Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
        }

        private bool loadDsd()
        {
            using (var progressDialog = new ProgressDialog())
            {
                progressDialog.Text = "Caricamento Dsd";
                progressDialog.SetWaiting();
                progressDialog.Show();

                XmlDocument xDocStructure = new XmlDocument();

                xDocStructure.Load(txtDestinationPath.Text);

                Org.Sdmxsource.Sdmx.Api.Util.IReadableDataLocation rdl = new Org.Sdmxsource.Util.Io.XmlDocReadableDataLocation(xDocStructure);
                StructureParsingManager spm = new StructureParsingManager();
                IStructureWorkspace workspace = spm.ParseStructures(rdl);
                ISdmxObjects sdmxObjects = workspace.GetStructureObjects(false);

                if (!sdmxObjects.DataStructures.Any())
                {
                    MessageBox.Show(this, "No datastructure found", Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return true;
                }

                dsdDataGridView.Rows.Clear();
                dsdSelectedListBox.Items.Clear();
                mappingDataGridView.Rows.Clear();

                foreach (var row in csvDataGridView.Rows.Cast<DataGridViewRow>())
                {
                    row.Cells[1].Value = false;
                }

                foreach (var component in sdmxObjects.DataStructures.First().Components)
                {
                    var name = "";
                    var conceptScheme = component.ConceptRef?.MaintainableReference;
                    if (conceptScheme != null)
                    {
                        var cs = sdmxObjects.ConceptSchemes.FirstOrDefault(x => x.Id == conceptScheme.MaintainableId && x.AgencyId == conceptScheme.AgencyId && x.Version == conceptScheme.Version);
                        if (cs != null)
                        {
                            name = cs.Items.FirstOrDefault(x => x.Id == component.Id)?.Name ?? "";
                        }
                    }

                    dsdDataGridView.Rows.Add(component.Id, name, component.StructureType, false, component is DimensionCore); // false cause is not mapped
                }

                dimensionsAtObservation = sdmxObjects.DataStructures.First().GetDimensions().Select(x => x.Id).ToList();
                dimensionsAtObservation.Insert(0, "");

                comboBoxDimensionAtObservation.DataSource = dimensionsAtObservation;

                updateDsdButton();
                updateMapButton();
                updateAutoMapButton();
                updateCsvButton();
            }

            return false;
        }

        private void csvDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            updateCsvButton();
            updateMapButton();
        }

        private void csvSelectedListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            updateCsvButton();
            updateMapButton();
        }

        private void dsdSelectedListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            updateDsdButton();
            updateMapButton();
        }

        private void dsdDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            updateDsdButton();
            updateMapButton();
        }

        private void addCsvItem_Click(object sender, EventArgs e)
        {
            addCsvItemToListbox();
        }

        private void addDsdItem_Click(object sender, EventArgs e)
        {
            addDsdItemToListbox();
        }

        private void removeCsvItem_Click(object sender, EventArgs e)
        {
            csvSelectedListBox.Items.Remove(csvSelectedListBox.Items[0]);
            updateCsvButton();
            updateMapButton();
            updateAutoMapButton();
        }

        private void removeDsdItem_Click(object sender, EventArgs e)
        {
            dsdSelectedListBox.Items.Remove(dsdSelectedListBox.Items[0]);
            updateDsdButton();
            updateMapButton();
            updateAutoMapButton();
        }

        private void updateCsvButton()
        {
            addCsvItem.Enabled = csvDataGridView.SelectedRows.Count == 1 && csvDataGridView.SelectedRows[0] != null && !(bool)csvDataGridView.SelectedRows[0].Cells[1].Value && csvSelectedListBox.Items.Count == 0;
            removeCsvItem.Enabled = !addCsvItem.Enabled && csvSelectedListBox.Items.Count == 1;
        }

        private void updateAutoMapButton()
        {
            if (csvDataGridView.RowCount >= dsdDataGridView.RowCount)
            {
                autoMapButton.Enabled = dsdDataGridView.Rows.Cast<DataGridViewRow>().Any(x => !(bool)x.Cells[3].Value);
            }
            else
            {
                autoMapButton.Enabled = csvDataGridView.Rows.Cast<DataGridViewRow>().Any(x => !(bool)x.Cells[1].Value);
            }
        }

        private void updateDsdButton()
        {
            addDsdItem.Enabled = dsdDataGridView.SelectedRows.Count == 1 && dsdDataGridView.SelectedRows[0] != null && !(bool)dsdDataGridView.SelectedRows[0].Cells[3].Value && dsdSelectedListBox.Items.Count == 0;
            removeDsdItem.Enabled = !addDsdItem.Enabled && dsdSelectedListBox.Items.Count == 1;
        }

        private void updateMapButton()
        {
            mapButton.Enabled = csvSelectedListBox.Items.Count > 0 && dsdSelectedListBox.Items.Count > 0;
        }

        private void updateRemoveMappingButton()
        {
            removeMappingButton.Enabled = mappingDataGridView.SelectedRows.Count > 0;
        }

        private void mapButton_Click(object sender, EventArgs e)
        {
            var csvRow = csvDataGridView.Rows.Cast<DataGridViewRow>().FirstOrDefault(x => x.Cells[0].Value == csvSelectedListBox.Items[0]);
            if (csvRow != null)
                csvRow.Cells[1].Value = true;

            var dsdRow = dsdDataGridView.Rows.Cast<DataGridViewRow>().FirstOrDefault(x => x.Cells[0].Value == dsdSelectedListBox.Items[0]);
            if (dsdRow != null)
                dsdRow.Cells[3].Value = true;

            mappingDataGridView.Rows.Add(csvSelectedListBox.Items[0], dsdSelectedListBox.Items[0]);
            csvSelectedListBox.Items.Clear();
            dsdSelectedListBox.Items.Clear();
            updateDsdButton();
            updateCsvButton();
            updateMapButton();
            updateAutoMapButton();
        }

        private void mappingDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            updateRemoveMappingButton();
        }

        private void removeMappingButton_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in mappingDataGridView.SelectedRows)
            {
                mappingDataGridView.Rows.Remove(row);

                var csvRow = csvDataGridView.Rows.Cast<DataGridViewRow>().FirstOrDefault(x => x.Cells[0].Value.ToString() == row.Cells[0].Value.ToString());
                if (csvRow != null)
                    csvRow.Cells[1].Value = false;

                var dsdRow = dsdDataGridView.Rows.Cast<DataGridViewRow>().FirstOrDefault(x => x.Cells[0].Value.ToString() == row.Cells[1].Value.ToString());
                if (dsdRow != null)
                    dsdRow.Cells[3].Value = false;
            }

            updateDsdButton();
            updateCsvButton();
            updateMapButton();
            updateAutoMapButton();
        }

        private void csvDataGridView_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            var datagridview = sender as DataGridView;
            if (datagridview != null && e.RowIndex > -1 && e.ColumnIndex == datagridview.Columns["csvMappedColumn"]?.Index)
            {
                if ((bool)datagridview.Rows[e.RowIndex].Cells[e.ColumnIndex].Value)
                {
                    datagridview.Rows[e.RowIndex].DefaultCellStyle.ForeColor = Color.LightGray;
                    datagridview.Rows[e.RowIndex].DefaultCellStyle.SelectionForeColor = Color.LightGray;
                }
                else
                {
                    datagridview.Rows[e.RowIndex].DefaultCellStyle.ForeColor = Color.Black;
                    datagridview.Rows[e.RowIndex].DefaultCellStyle.SelectionForeColor = Color.Black;
                }
            }
        }

        private void dsdDataGridView_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            var datagridview = sender as DataGridView;
            if (datagridview != null && e.RowIndex > -1 && e.ColumnIndex == datagridview.Columns["dsdMappedColumn"]?.Index)
            {
                if ((bool)datagridview.Rows[e.RowIndex].Cells[e.ColumnIndex].Value)
                {
                    datagridview.Rows[e.RowIndex].DefaultCellStyle.ForeColor = Color.LightGray;
                    datagridview.Rows[e.RowIndex].DefaultCellStyle.SelectionForeColor = Color.LightGray;
                }
                else
                {
                    datagridview.Rows[e.RowIndex].DefaultCellStyle.ForeColor = Color.Black;
                    datagridview.Rows[e.RowIndex].DefaultCellStyle.SelectionForeColor = Color.Black;
                }
            }
        }

        private void filedSeparatorTextBox_TextChanged(object sender, EventArgs e)
        {
            updateCsvImportButton();
        }

        private void updateCsvImportButton()
        {
            btnSourceChooser.Enabled = !string.IsNullOrEmpty(filedSeparatorTextBox.Text);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DialogResult result = this.saveConfigDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                prefs = headerIfno.GetMappingDialogPreferences();

                prefs.FieldSeparator = filedSeparatorTextBox.Text[0];
                prefs.FieldDelimiter = string.IsNullOrEmpty(FieldDelimiterTextBox.Text) ? null : (char?)FieldDelimiterTextBox.Text[0];
                prefs.DecimalSeparator = decimalSeparatorTextBox.Text[0];
                prefs.HasHeader = hasHeaderCheckBox.Checked;
                prefs.CsvFilename = txtSourcePath.Text;
                prefs.DsdFilename = txtDestinationPath.Text;
                prefs.SdmxFilename = txtXmlPath.Text;
                prefs.DataEnumType = (cmbSdmxFormats.SelectedItem as SdmxDataType).DataEnumType;
                prefs.Mapping.Clear();

                foreach (DataGridViewRow row in mappingDataGridView.Rows)
                {
                    prefs.Mapping.Add(new[] { (string)row.Cells[0].Value, (string)row.Cells[1].Value });
                }

                try
                {
                    MappingDialogPreferences.Save(this.saveConfigDialog.FileName, prefs);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error on save preferences\n" + ex.Message, Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private MappingDialogPreferences prefs;

        private void btnLoad_Click(object sender, EventArgs e)
        {
            DialogResult result = this.loadConfigDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                try
                {
                    prefs = MappingDialogPreferences.Load(loadConfigDialog.FileName);
                }
                catch (InvalidOperationException)
                {
                    MessageBox.Show(this, "Invalid preferences file", Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Error on load preferences\n" + ex.Message, Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                headerIfno.Init(prefs);

                filedSeparatorTextBox.Text = prefs.FieldSeparator.ToString();
                decimalSeparatorTextBox.Text = prefs.DecimalSeparator.ToString();
                FieldDelimiterTextBox.Text = prefs.FieldDelimiter == null ? "" : prefs.FieldDelimiter.ToString();
                hasHeaderCheckBox.Checked = prefs.HasHeader;
                txtSourcePath.Text = prefs.CsvFilename;
                txtDestinationPath.Text = prefs.DsdFilename;
                txtXmlPath.Text = prefs.SdmxFilename;
                cmbSdmxFormats.SelectedItem = cmbSdmxFormats.Items.Cast<SdmxDataType>().FirstOrDefault(x => x.DataEnumType == prefs.DataEnumType) ?? cmbSdmxFormats.Items[0];

                loadCsv();
                loadDsd();

                foreach (var row in prefs.Mapping)
                {
                    var csvRow = csvDataGridView.Rows.Cast<DataGridViewRow>().FirstOrDefault(x => (string)x.Cells[0].Value == row[0]);
                    var dsdRow = dsdDataGridView.Rows.Cast<DataGridViewRow>().FirstOrDefault(x => (string)x.Cells[0].Value == row[1]);
                    if (csvRow != null && dsdRow != null)
                    {
                        csvRow.Cells[1].Value = true;
                        dsdRow.Cells[3].Value = true;

                        mappingDataGridView.Rows.Add(row[0], row[1]);
                    }
                }

                updateDsdButton();
                updateCsvButton();
                updateMapButton();
                updateAutoMapButton();
            }
        }

        private void cancelWork()
        {
            if (cts != null && !cts.IsCancellationRequested)
            {
                cts.Cancel();
                cts.Dispose();
                cts = null;
            }
        }

        private CancellationTokenSource cts;
        private ProgressDialog progressDialog;

        private void button1_Click(object sender, EventArgs e)
        {
            if (!dsdDataGridView.Rows.Cast<DataGridViewRow>().Any())
            {
                MessageBox.Show(this, "There are no mapping", Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtXmlPath.Text))
            {
                MessageBox.Show(this, "Please insert sdmx output file", Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            progressDialog = new ProgressDialog();
            progressDialog.ControlBox = false;
            progressDialog.Owner = this;
            progressDialog.StartPosition = FormStartPosition.CenterParent;
            progressDialog.ShowCancelButton();
            progressDialog.OnCancel += cancelWork;
            try
            {
                string dAtObservation = comboBoxDimensionAtObservation.Enabled ? (string)comboBoxDimensionAtObservation.SelectedItem : null;

                cts = new CancellationTokenSource();
                tableLayoutPanel1.Enabled = false;
                progressDialog.SetWaiting();
                progressDialog.Show();
                var dataFormat = new SdmxDataFormatCore(DataType.GetFromEnum((cmbSdmxFormats.SelectedItem as SdmxDataType).DataEnumType));

                var task = Task.Factory.StartNew(() => doWork(this, dataFormat, cts.Token, dAtObservation), cts.Token);
            }
            catch
            {
                tableLayoutPanel1.Enabled = true;
                progressDialog.Dispose();
                progressDialog = null;
            }
        }

        private delegate void daThreadCallbackDelegate(bool success, string message = "");

        private void daThreadCallback(bool success, string message = "")
        {
            tableLayoutPanel1.Enabled = true;

            if (progressDialog != null && !progressDialog.IsDisposed)
            {
                progressDialog.Close();
                progressDialog.Dispose();
                progressDialog = null;
            }

            if (success)
            {
                MessageBox.Show(this, "Export successfully", Resources.DoneTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show(this, message, Resources.ErrorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void doWork(MappingWindow mw, IDataFormat dataFormat, CancellationToken ct, string dao)
        {
            daThreadCallbackDelegate callback = daThreadCallback;
            try
            {
                IDataWriterManager dwm = new DataWriterManager();

                XmlDocument xDocStructure = new XmlDocument();

                xDocStructure.Load(txtDestinationPath.Text);
                ISdmxObjects sdmxObjects;

                using (var rdl = new XmlDocReadableDataLocation(xDocStructure))
                {
                    StructureParsingManager spm = new StructureParsingManager();
                    IStructureWorkspace workspace = spm.ParseStructures(rdl);
                    sdmxObjects = workspace.GetStructureObjects(false);
                }

                var dsd = sdmxObjects.DataStructures.First();

                var dataflow = new DataflowMutableCore(dsd);

                var dataFlowRef = new MaintainableRefObjectImpl(dataflow.AgencyId, dataflow.Id, dataflow.Version);

                var separator = filedSeparatorTextBox.Text[0];
                var delimiter = string.IsNullOrEmpty(FieldDelimiterTextBox.Text) ? null : (char?)FieldDelimiterTextBox.Text[0];

                var hasDataflowColumn = csvDto.Headers.Any(x => x.Value == "DATAFLOW");
                var csvDtoWithDataflow = new CsvImport2(txtSourcePath.Text, separator, delimiter, hasHeaderCheckBox.Checked, dataFlowRef).LoadCsv(hasDataflowColumn);

                var dsdMapping = new List<string>();
                var csvMapping = new List<CsvHeader>();

                csvMapping.Add(csvDtoWithDataflow.Headers.First(x => x.Value == "DATAFLOW"));

                Dictionary<int, ConceptInfo> mapping = new Dictionary<int, ConceptInfo>();

                foreach (var row in mappingDataGridView.Rows.Cast<DataGridViewRow>())
                {
                    if (ct.IsCancellationRequested)
                        throw new Exception("Cancelled");

                    dsdMapping.Add((string)row.Cells[1].Value);
                    var csvHeader = csvDto.Headers.FirstOrDefault(x => x.Value == (string)row.Cells[0].Value);
                    var column = hasDataflowColumn ? csvHeader.Index : csvHeader.Index + 1;
                    csvMapping.Add(new CsvHeader((string)row.Cells[1].Value, column));
                    mapping.Add(column, new ConceptInfo(column, false, null, (string)row.Cells[1].Value));
                }

                var mutableDsd = dsd.MutableInstance;

                foreach (var col in dsd.Components)
                {
                    if (ct.IsCancellationRequested)
                        throw new Exception("Cancelled");

                    if (!dsdMapping.Contains(col.Id))
                        mutableDsd.RemoveComponent(col.Id);
                }

                dsd = mutableDsd.ImmutableInstance;

                //     using (var rdl = new ReadableDataLocationTmp(csvDtoWithDataflow.GetStream(csvMapping.OrderBy(x => x.Index), separator, delimiter)))
                using (var dre = new CustomCsvDataReaderEngine(null, null, dataflow.ImmutableInstance, dsd, header, csvDtoWithDataflow, mapping, dao))
                using (var file = new StreamWriter(txtXmlPath.Text))
                {
                    using (var dwe = dwm.GetDataWriterEngine(dataFormat, file.BaseStream))
                    {
                        dre.MoveNextDataset();

                        var datasetHeader = dre.CurrentDatasetHeader;

                        string dimensionAtObservation;
                        if (dwe is CrossSectionalWriterEngine &&
                            dre.DataStructure.GetDimensions(SdmxStructureEnumType.MeasureDimension) != null &&
                            dre.DataStructure.GetDimensions(SdmxStructureEnumType.MeasureDimension).Count > 0)
                        {

                            var measure = ((CrossSectionalDataStructureObjectCore)dre.DataStructure).GetDimensions(SdmxStructureEnumType.MeasureDimension).First();
                            dimensionAtObservation = measure.Id;
                        }
                        else if (datasetHeader.DataStructureReference.DimensionAtObservation != null &&
                                 ("TIME".Equals(datasetHeader.DataStructureReference.DimensionAtObservation, StringComparison.InvariantCultureIgnoreCase) ||
                                  "TIME_PERIOD".Equals(datasetHeader.DataStructureReference.DimensionAtObservation, StringComparison.InvariantCultureIgnoreCase)))
                        {
                            //TIME replaced with TIME_PERIOD 
                            dimensionAtObservation = DimensionObject.TimeDimensionFixedId;
                            var datasetStructureReference = new DatasetStructureReferenceCore(datasetHeader.DataStructureReference.Id,
                                datasetHeader.DataStructureReference.StructureReference,
                                null,
                                null,
                                dimensionAtObservation);
                            datasetHeader = datasetHeader.ModifyDataStructureReference(datasetStructureReference);

                        }
                        else
                        {
                            //CrossSectionalDataReader case is implemented separately with cache, this is for Structure Specific and Generic 2.1
                            dimensionAtObservation = datasetHeader.DataStructureReference.DimensionAtObservation;
                        }

                        do
                        {
                            dwe.WriteHeader(dre.Header);
                            dwe.StartDataset(dataflow.ImmutableInstance, dsd, datasetHeader);

                            foreach (var kv in dre.DatasetAttributes)
                            {
                                if (!string.IsNullOrEmpty(kv.Code))
                                {
                                    dwe.WriteAttributeValue(kv.Concept, kv.Code);
                                }
                            }

                            while (dre.MoveNextKeyable() && !ct.IsCancellationRequested)
                            {
                                dwe.StartSeries();

                                var currentKey = dre.CurrentKey;

                                foreach (var keyValue in currentKey.Key)
                                {
                                    dwe.WriteSeriesKeyValue(keyValue.Concept, keyValue.Code);
                                }

                                // If it is not TimeSeries and there is a time dimension we need to write the time dimension as a series key value
                                if (!currentKey.TimeSeries && currentKey.DataStructure.TimeDimension != null)
                                {
                                    dwe.WriteSeriesKeyValue(DimensionObject.TimeDimensionFixedId, currentKey.ObsTime);
                                }

                                foreach (var keyValue in currentKey.Attributes)
                                {
                                    dwe.WriteAttributeValue(keyValue.Concept, keyValue.Code);
                                }

                                if (currentKey.TimeSeries && currentKey.GroupName == null)
                                {
                                    //a time series
                                    writeTimeseriesKeyables(dre, dwe, currentKey, dimensionAtObservation, datasetHeader);
                                }

                                if (datasetHeader.Timeseries && !currentKey.TimeSeries && !DimensionObject.TimeDimensionFixedId.Equals(dimensionAtObservation))
                                {
                                    //this is a cross sectional output, dsd has time dimension but it is not the dimension at observation
                                    writeCrossSectionalKeyables(dre, dwe, currentKey, dimensionAtObservation, datasetHeader);
                                }

                                if (!datasetHeader.Timeseries && currentKey.GroupName == null)
                                {
                                    //this is for an output structure specific 2.1 or generic 2.1 with no time dimension
                                    write21NonTimeseriesKeyables(dre, dwe, currentKey, dimensionAtObservation, datasetHeader);
                                }

                                if (!currentKey.Series || currentKey.GroupName != null)
                                {
                                    dwe.StartGroup(currentKey.GroupName);
                                    foreach (var keyValue in currentKey.Key)
                                    {
                                        dwe.WriteGroupKeyValue(keyValue.Concept, keyValue.Code);
                                    }

                                    foreach (var keyValue in currentKey.Attributes)
                                    {
                                        dwe.WriteAttributeValue(keyValue.Concept, keyValue.Code);
                                    }
                                }
                            }
                        } while (dre.MoveNextDataset() && !ct.IsCancellationRequested);

                        if (ct.IsCancellationRequested)
                            throw new Exception("Cancelled");

                        dre.ClearInternalData();
                    }
                }

                mw.BeginInvoke(callback, new object[] { true, "" });
            }
            catch (FileNotFoundException)
            {
                mw.BeginInvoke(callback, new object[] { false, "File not found" });
                return;
            }
            catch (Exception ex)
            {
                mw.BeginInvoke(callback, new object[] { false, ex.Message });
                return;
            }
        }

        private void writeTimeseriesKeyables(AbstractDataReaderEngine dataReaderEngine, IDataWriterEngine dwe, IKeyable currentKey, String dimensionAtObs, IDatasetHeader datasetHeader)
        {
            while (dataReaderEngine.MoveNextObservation())
            {
                var observation = dataReaderEngine.CurrentObservation;

                // Is the datasetHeader here output -or- input ? Can we check if dimensionAtObs is TIME_PERIOD ?
                if (datasetHeader.Timeseries && !(dwe is CrossSectionalWriterEngine))
                {
                    dwe.WriteObservation(DimensionObject.TimeDimensionFixedId, observation.ObsTime, observation.ObservationValue);
                }
                else
                { // we either have non-Cross Sectional writer or non-time series (is this possible here ?)
                    String crossSectionalValue = currentKey.GetKeyValue(dimensionAtObs);

                    dwe.WriteObservation(dimensionAtObs, crossSectionalValue, observation.ObservationValue);

                    // we need to also write the TIME_PERIOD - HACK for CrossSectionDataWriterEngine write after the WriteObservation FIXME  
                    if (!observation.CrossSection && ObjectUtil.ValidString(observation.ObsTime))
                    {
                        dwe.WriteSeriesKeyValue(DimensionObject.TimeDimensionFixedId, observation.ObsTime);
                    }

                }

                foreach (var keyValue in observation.Attributes)
                {
                    dwe.WriteAttributeValue(keyValue.Concept, keyValue.Code);
                }
            }
        }

        private void writeCrossSectionalKeyables(AbstractDataReaderEngine dataReaderEngine, IDataWriterEngine dwe, IKeyable currentKey, String dimensionAtObs, IDatasetHeader datasetHeader)
        {
            while (dataReaderEngine.MoveNextObservation())
            {
                var observation = dataReaderEngine.CurrentObservation;

                dwe.WriteSeriesKeyValue(dimensionAtObs,
                                                    observation.CrossSectionalValue.Code);

                if (datasetHeader.Timeseries)
                {
                    dwe.WriteObservation(dimensionAtObs,
                                                        observation.ObsTime,
                                                        observation.ObservationValue);
                }
                else
                {
                    // FIXME what if there is no time dimension
                    dwe.WriteObservation(DimensionObject.TimeDimensionFixedId,
                                                        observation.ObsTime,
                                                        observation.ObservationValue);
                }

                foreach (var keyValue in observation.Attributes)
                {
                    dwe.WriteAttributeValue(keyValue.Concept, keyValue.Code);
                }
            }
        }

        private void write21NonTimeseriesKeyables(AbstractDataReaderEngine dataReaderEngine, IDataWriterEngine dwe, IKeyable currentKey, String dimensionAtObs, IDatasetHeader datasetHeader)
        {
            while (dataReaderEngine.MoveNextObservation())
            {
                var observation = dataReaderEngine.CurrentObservation;

                if (datasetHeader.Timeseries)
                {
                    dwe.WriteObservation(dimensionAtObs,
                                                        observation.ObsTime,
                                                        observation.ObservationValue);
                }
                else
                {
                    dwe.WriteObservation(observation.CrossSectionalValue.Code, observation.ObservationValue);
                }

                foreach (var keyValue in observation.Attributes)
                {
                    dwe.WriteAttributeValue(keyValue.Concept, keyValue.Code);
                }
            }
        }

        private void btnXmlChooser_Click(object sender, EventArgs e)
        {
            DialogResult result = this.saveFileDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                this.txtXmlPath.Text = this.saveFileDialog.FileName;
            }
        }

        private void autoMapButton_Click(object sender, EventArgs e)
        {
            if (csvDataGridView.RowCount >= dsdDataGridView.RowCount)
            {
                foreach (var row in csvDataGridView.Rows.Cast<DataGridViewRow>().Where(x => !(bool)x.Cells[1].Value))
                {
                    var sameRow = dsdDataGridView.Rows.Cast<DataGridViewRow>().FirstOrDefault(x => !(bool)x.Cells[3].Value && (string)x.Cells[0].Value == (string)row.Cells[0].Value);
                    if (sameRow != null)
                    {
                        row.Cells[1].Value = true;
                        sameRow.Cells[3].Value = true;
                        mappingDataGridView.Rows.Add(row.Cells[0].Value, sameRow.Cells[0].Value);
                    }
                }
            }
            else
            {
                foreach (var row in dsdDataGridView.Rows.Cast<DataGridViewRow>().Where(x => !(bool)x.Cells[3].Value))
                {
                    var sameRow = csvDataGridView.Rows.Cast<DataGridViewRow>().FirstOrDefault(x => !(bool)x.Cells[1].Value && (string)x.Cells[0].Value == (string)row.Cells[0].Value);
                    if (sameRow != null)
                    {
                        row.Cells[3].Value = true;
                        sameRow.Cells[1].Value = true;
                        mappingDataGridView.Rows.Add(sameRow.Cells[0].Value, row.Cells[0].Value);
                    }
                }
            }

            csvSelectedListBox.Items.Clear();
            dsdSelectedListBox.Items.Clear();

            updateDsdButton();
            updateCsvButton();
            updateMapButton();
            updateAutoMapButton();
        }

        private void csvDataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (csvDataGridView.SelectedRows.Count > 0 && csvDataGridView.SelectedRows[0] != null && !(bool)csvDataGridView.SelectedRows[0].Cells[1].Value)
            {
                addCsvItemToListbox();
            }
        }

        private void addCsvItemToListbox()
        {
            if (csvSelectedListBox.Items.Count <= 0)
            {
                csvSelectedListBox.Items.Add(csvDataGridView.SelectedRows[0].Cells[0].Value);
                updateCsvButton();
                updateMapButton();
                updateAutoMapButton();
            }
        }

        private void dsdDataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dsdDataGridView.SelectedRows.Count > 0 && dsdDataGridView.SelectedRows[0] != null && !(bool)dsdDataGridView.SelectedRows[0].Cells[3].Value)
            {
                addDsdItemToListbox();
            }
        }

        private void addDsdItemToListbox()
        {
            if (dsdSelectedListBox.Items.Count <= 0)
            {
                dsdSelectedListBox.Items.Add(dsdDataGridView.SelectedRows[0].Cells[0].Value);
                updateDsdButton();
                updateMapButton();
                updateAutoMapButton();
            }
        }

        private void MappingWindow_VisibleChanged(object sender, EventArgs e)
        {
            if (Visible)
            {
                if (progressDialog != null && !progressDialog.IsDisposed)
                    progressDialog.Visible = true;
            }
            else
            {
                if (progressDialog != null && !progressDialog.IsDisposed)
                    progressDialog.Visible = false;
            }
        }

        private void MappingWindow_Leave(object sender, EventArgs e)
        {
            if (progressDialog != null && !progressDialog.IsDisposed)
                progressDialog.Visible = false;
        }

        private void MappingWindow_Enter(object sender, EventArgs e)
        {
            if (progressDialog != null && !progressDialog.IsDisposed)
                progressDialog.Visible = true;
        }

        private void cmbSdmxFormats_SelectedValueChanged(object sender, EventArgs e)
        {
            var t = cmbSdmxFormats.SelectedItem as SdmxDataType;
            comboBoxDimensionAtObservation.Enabled = t != null && t.DataEnumType == DataEnumType.Compact21;
        }

        private IHeader header;

        private readonly HeaderInfoDialog headerIfno = new HeaderInfoDialog();

        private void button2_Click(object sender, EventArgs e)
        {
            headerIfno.Init(prefs);
            headerIfno.ShowDialog();
            prefs = headerIfno.GetMappingDialogPreferences();
            header = parseSdmxHeader();
        }


        private const string lang = null;// "en-GB";

        private IHeader parseSdmxHeader()
        {
            IList<ITextTypeWrapper> name = new List<ITextTypeWrapper>();
            name.Add(new TextTypeWrapperImpl(lang, prefs.AgencyId, null));

            IList<ITextTypeWrapper> textTypeWrapperSender = new List<ITextTypeWrapper>();
            textTypeWrapperSender.Add(new TextTypeWrapperImpl(lang, prefs.SenderOrgName, null));

            IContactMutableObject senderContact = new ContactMutableObjectCore();
            senderContact.AddName(new TextTypeWrapperMutableCore(lang, prefs.SenderName));
            senderContact.AddDepartment(new TextTypeWrapperMutableCore(lang, prefs.SenderDepartment));
            senderContact.AddRole(new TextTypeWrapperMutableCore(lang, prefs.SenderRole));

            if (!string.IsNullOrEmpty(prefs.SenderEmail))
            {
                senderContact.AddEmail(prefs.SenderEmail);
            }

            // SENDER
            IContact contactImmutableSender = new ContactCore(senderContact);
            IList<IContact> contactsSender = new List<IContact>();
            contactsSender.Add(contactImmutableSender);
            IParty sender = new PartyCore(textTypeWrapperSender, prefs.SenderOrgId, contactsSender, null);

            IList<ITextTypeWrapper> textTypeWrapperReceiver = new List<ITextTypeWrapper>();
            textTypeWrapperReceiver.Add(new TextTypeWrapperImpl(lang, prefs.ReceiverOrgName, null));

            IContactMutableObject receiverContact = new ContactMutableObjectCore();

            receiverContact.AddName(new TextTypeWrapperMutableCore(lang, prefs.ReceiverName));
            receiverContact.AddDepartment(new TextTypeWrapperMutableCore(lang, prefs.ReceiverDepartment));
            receiverContact.AddRole(new TextTypeWrapperMutableCore(lang, prefs.ReceiverRole));

            if (!string.IsNullOrEmpty(prefs.ReceiverEmail))
            {
                receiverContact.AddEmail(prefs.ReceiverEmail);
            }

            // RECEIVER
            IContact contactImmutableReceiver = new ContactCore(receiverContact);
            IList<IContact> contactsReceiver = new List<IContact>();
            contactsReceiver.Add(contactImmutableReceiver);
            IParty receiver = new PartyCore(textTypeWrapperReceiver, prefs.ReceiverOrgId, contactsReceiver, null);
            IList<IParty> receiverList = new List<IParty>();
            receiverList.Add(receiver);

            IDictionary<string, string> additionalAttributes = new Dictionary<string, string>();

            var extracted = DateTime.Now;
            var reportingBegin = DateTime.Now;
            var reportingEnd = DateTime.Now;
            var prepared = DateTime.Now;

            IList<ITextTypeWrapper> source = new List<ITextTypeWrapper>();
            if (!string.IsNullOrEmpty(prefs.Source))
            {
                source.Add(new TextTypeWrapperImpl(lang, prefs.Source, null));
            }

            return new HeaderImpl(
                additionalAttributes,
                null,
                null,
                DatasetAction.GetFromEnum(DatasetActionEnumType.Null),
                null,
                null,
                null,
                extracted,
                prepared,
                reportingBegin,
                reportingEnd,
                name,
                source,
                receiverList,
                sender,
                prefs.IsTest);
        }
    }
}
