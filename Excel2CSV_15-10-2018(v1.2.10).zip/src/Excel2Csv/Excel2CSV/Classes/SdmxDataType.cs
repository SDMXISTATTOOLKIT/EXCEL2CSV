﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Org.Sdmxsource.Sdmx.Api.Constants;

namespace Excel2Csv.Classes
{
    public sealed class SdmxDataTypeService
    {
        public static SdmxDataTypeService Instance { get; }

        static SdmxDataTypeService()
        {
            Instance = new SdmxDataTypeService();
        }

        private List<SdmxDataType> supportedDataTypes;

        private SdmxDataTypeService()
        {
            supportedDataTypes = new List<SdmxDataType>();

            // adding supported data types, avoid duplicates
            supportedDataTypes.Add(new SdmxDataType(DataEnumType.Compact10, "Compact 1.0"));
            supportedDataTypes.Add(new SdmxDataType(DataEnumType.Compact20, "Compact 2.0"));
            supportedDataTypes.Add(new SdmxDataType(DataEnumType.Compact21, "Structure Specific 2.1"));
            supportedDataTypes.Add(new SdmxDataType(DataEnumType.Generic10, "Generic 1.0"));
            supportedDataTypes.Add(new SdmxDataType(DataEnumType.Generic20, "Generic 2.0"));
            supportedDataTypes.Add(new SdmxDataType(DataEnumType.Generic21, "Generic 2.1"));
       //     supportedDataTypes.Add(new SdmxDataType(DataEnumType., "Message Group 1.0 Compact"));
            supportedDataTypes.Add(new SdmxDataType(DataEnumType.MessageGroup10Compact, "Message Group 1.0 Compact"));
            supportedDataTypes.Add(new SdmxDataType(DataEnumType.MessageGroup20Compact, "Message Group 2.0 Compact"));
            supportedDataTypes.Add(new SdmxDataType(DataEnumType.MessageGroup10Generic, "Message Group 1.0 Generic"));
            supportedDataTypes.Add(new SdmxDataType(DataEnumType.MessageGroup20Generic, "Message Group 2.0 Generic"));
        }

        public SdmxDataType GetDataType(DataEnumType enumType)
        {
            var dataType = supportedDataTypes.FirstOrDefault(x => x.DataEnumType == enumType);
            
            // remove if supported only DataEnumType on constructor
            if (dataType == null)
            {
                dataType = new SdmxDataType(enumType, Enum.GetName(typeof(DataEnumType), enumType));
                supportedDataTypes.Add(dataType);
            }

            return dataType;
        }
    }

    public class SdmxDataType
    {
        public DataEnumType DataEnumType { get; }

        public string Name { get; }

        public SdmxDataType(DataEnumType enumType, string name)
        {
            DataEnumType = enumType;
            Name = name;
        }
    }
}
