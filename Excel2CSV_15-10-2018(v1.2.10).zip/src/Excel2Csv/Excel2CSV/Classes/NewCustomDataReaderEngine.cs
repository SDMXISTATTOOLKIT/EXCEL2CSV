﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper;
using Org.Sdmx.Resources.SdmxMl.Schemas.V21.Common;
using Org.Sdmxsource.Sdmx.Api.Engine;
using Org.Sdmxsource.Sdmx.Api.Manager.Retrieval;
using Org.Sdmxsource.Sdmx.Api.Model.Data;
using Org.Sdmxsource.Sdmx.Api.Model.Header;
using Org.Sdmxsource.Sdmx.Api.Model.Objects.Base;
using Org.Sdmxsource.Sdmx.Api.Model.Objects.DataStructure;
using Org.Sdmxsource.Sdmx.Api.Util;
using Org.Sdmxsource.Sdmx.DataParser.Engine.Reader;

namespace Excel2Csv.Classes
{
    class NewCustomDataReaderEngine : AbstractDataReaderEngine
    {
        private ISdmxObjectRetrievalManager retrieval;

        private DataStructure dsd;

        private Dataflow dataflow;

        private Queue<IDisposable> closables = new Queue<IDisposable>();

        private Queue<IKeyable> listOfIKeyable = new Queue<IKeyable>();

        private Queue<IObservation> listOfObservation = new Queue<IObservation>();

        private Dictionary<String, IComponent> mapOfComponentBeans = new Dictionary<String, IComponent>();
        private Dictionary<String, String> xsMeasureIdToMeasureCode = new Dictionary<String, String>();
        private Stream inputStream;
        private List<IKeyValue> datasetAttributes;
        private IKeyable currentKeyable;
        private IObservation currentObservation;
        private bool movedToNextDataset;
        private String[] firstRowOfData;
        private IDimension dimensionAtObservation;
        private IDatasetHeader currentDatasetHeaderBean;
        private bool useXSMeasures;
        private bool isTimeSeries;
        private int rowNumber = 0;

        public NewCustomDataReaderEngine(IReadableDataLocation dataLocation, ISdmxObjectRetrievalManager objectRetrieval, IDataflowObject defaultDataflow, IDataStructureObject defaultDsd)
            : base(dataLocation, objectRetrieval, defaultDataflow, defaultDsd)
        {
        }

        public override IDataReaderEngine CreateCopy()
        {
            throw new NotImplementedException();
        }

        public override IList<IKeyValue> DatasetAttributes { get; }

        protected override IKeyable LazyLoadKey()
        {
            throw new NotImplementedException();
        }

        protected override IObservation LazyLoadObservation()
        {
            throw new NotImplementedException();
        }

        protected override bool MoveNextDatasetInternal()
        {
            throw new NotImplementedException();
        }

        protected override bool MoveNextKeyableInternal()
        {
            throw new NotImplementedException();
        }

        protected override bool MoveNextObservationInternal()
        {
            throw new NotImplementedException();
        }
    }
}
