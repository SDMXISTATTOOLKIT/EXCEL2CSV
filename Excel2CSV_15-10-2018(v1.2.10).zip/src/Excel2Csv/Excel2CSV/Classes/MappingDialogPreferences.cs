﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Org.Sdmxsource.Sdmx.Api.Constants;

#pragma warning disable 1591

namespace Excel2Csv.Classes
{
    public class MappingDialogPreferences
    {
        public char FieldSeparator { get; set; } = ';';
        public char? FieldDelimiter { get; set; } = null;
        public char DecimalSeparator { get; set; } = '.';
        public bool HasHeader { get; set; } = true;
        public string CsvFilename { get; set; } = "";
        public string DsdFilename { get; set; } = "";
        public string SdmxFilename { get; set; } = "";
        public List<string[]> Mapping { get; set; } = new List<string[]>();
        public DataEnumType DataEnumType { get; set; } = DataEnumType.Compact21;

        // Header
        public string SenderOrgId { get; set; } = "";
        public string SenderOrgName { get; set; } = CustomCsvDataReaderEngine.DEFAULT_SENDER_ID;
        public string SenderName { get; set; } = "";
        public string SenderEmail { get; set; } = "";
        public string SenderDepartment { get; set; } = "";
        public string SenderRole { get; set; } = "";
        public string ReceiverOrgId { get; set; } = "";
        public string ReceiverOrgName { get; set; } = "";
        public string ReceiverName { get; set; } = "";
        public string ReceiverEmail { get; set; } = "";
        public string ReceiverDepartment { get; set; } = "";
        public string ReceiverRole { get; set; } = "";
        public string Transmission { get; set; } = "";
        public string AgencyId { get; set; } = CustomCsvDataReaderEngine.DEFAULT_HEADER_ID;
        public string Source { get; set; } = "";
        public bool IsTest { get; set; } = false;

        public static void Save(string filename, MappingDialogPreferences prefs)
        {
            using (var file = System.IO.File.Create(filename))
            {
                var writer = new XmlSerializer(typeof(MappingDialogPreferences));

                writer.Serialize(file, prefs);
                file.Close();
            }
        }

        public static MappingDialogPreferences Load(string filename)
        {
            var xmlDocument = new XmlDocument();
            xmlDocument.Load(filename);
            string xmlString = xmlDocument.OuterXml;

            using (StringReader read = new StringReader(xmlString))
            {
                var outType = typeof(MappingDialogPreferences);

                var serializer = new XmlSerializer(outType);
                using (var reader = new XmlTextReader(read))
                {
                    return (MappingDialogPreferences)serializer.Deserialize(reader);
                }
            }
        }
    }
}
