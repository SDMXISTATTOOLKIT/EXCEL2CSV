﻿namespace Excel2Csv.Classes
{
    partial class MappingWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.buttonGrouper = new System.Windows.Forms.Panel();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnDsdChooser = new System.Windows.Forms.Button();
            this.btnSourceChooser = new System.Windows.Forms.Button();
            this.csvDataGridView = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.csvMappedColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.txtSourcePath = new System.Windows.Forms.TextBox();
            this.txtDestinationPath = new System.Windows.Forms.TextBox();
            this.dsdDataGridView = new System.Windows.Forms.DataGridView();
            this.IdDsd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NameDsd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TypeDsd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dsdMappedColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dsdColumnMandatory = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.csvSelectedListBox = new System.Windows.Forms.ListBox();
            this.dsdSelectedListBox = new System.Windows.Forms.ListBox();
            this.addCsvItem = new System.Windows.Forms.Button();
            this.addDsdItem = new System.Windows.Forms.Button();
            this.removeCsvItem = new System.Windows.Forms.Button();
            this.removeDsdItem = new System.Windows.Forms.Button();
            this.autoMapButton = new System.Windows.Forms.Button();
            this.mapButton = new System.Windows.Forms.Button();
            this.mappingDataGridView = new System.Windows.Forms.DataGridView();
            this.mappingCsvIdCoumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mappingDsdIdColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.removeMappingButton = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.decimalSeparatorTextBox = new System.Windows.Forms.TextBox();
            this.lblDecSep = new System.Windows.Forms.Label();
            this.filedSeparatorTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.hasHeaderCheckBox = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.FieldDelimiterTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnXmlChooser = new System.Windows.Forms.Button();
            this.txtXmlPath = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbSdmxFormats = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBoxDimensionAtObservation = new System.Windows.Forms.ComboBox();
            this.selectFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.selectDsdFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveConfigDialog = new System.Windows.Forms.SaveFileDialog();
            this.loadConfigDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.button2 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.buttonGrouper.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.csvDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsdDataGridView)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mappingDataGridView)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.Controls.Add(this.buttonGrouper, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.btnDsdChooser, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnSourceChooser, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.csvDataGridView, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtSourcePath, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtDestinationPath, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.dsdDataGridView, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.mappingDataGridView, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.removeMappingButton, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.button1, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.btnXmlChooser, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtXmlPath, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel4, 0, 4);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1188, 709);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // buttonGrouper
            // 
            this.buttonGrouper.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.buttonGrouper, 5);
            this.buttonGrouper.Controls.Add(this.btnLoad);
            this.buttonGrouper.Controls.Add(this.btnSave);
            this.buttonGrouper.Controls.Add(this.btnCancel);
            this.buttonGrouper.Controls.Add(this.btnOk);
            this.buttonGrouper.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttonGrouper.Location = new System.Drawing.Point(4, 664);
            this.buttonGrouper.Margin = new System.Windows.Forms.Padding(4);
            this.buttonGrouper.Name = "buttonGrouper";
            this.buttonGrouper.Size = new System.Drawing.Size(1180, 41);
            this.buttonGrouper.TabIndex = 32;
            // 
            // btnLoad
            // 
            this.btnLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLoad.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnLoad.Location = new System.Drawing.Point(688, 5);
            this.btnLoad.Margin = new System.Windows.Forms.Padding(4);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(114, 32);
            this.btnLoad.TabIndex = 1;
            this.btnLoad.Text = "&Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSave.Location = new System.Drawing.Point(810, 5);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(114, 32);
            this.btnSave.TabIndex = 2;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnCancel.Location = new System.Drawing.Point(1054, 5);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(114, 32);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Cl&ose";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOk.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnOk.Location = new System.Drawing.Point(932, 5);
            this.btnOk.Margin = new System.Windows.Forms.Padding(4);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(114, 32);
            this.btnOk.TabIndex = 3;
            this.btnOk.Text = "&Generate Sdmx";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDsdChooser
            // 
            this.btnDsdChooser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDsdChooser.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnDsdChooser.Location = new System.Drawing.Point(4, 77);
            this.btnDsdChooser.Margin = new System.Windows.Forms.Padding(4);
            this.btnDsdChooser.Name = "btnDsdChooser";
            this.btnDsdChooser.Size = new System.Drawing.Size(92, 31);
            this.btnDsdChooser.TabIndex = 26;
            this.btnDsdChooser.Text = "&Dsd";
            this.btnDsdChooser.UseVisualStyleBackColor = true;
            this.btnDsdChooser.Click += new System.EventHandler(this.btnDsdChooser_Click);
            // 
            // btnSourceChooser
            // 
            this.btnSourceChooser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSourceChooser.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnSourceChooser.Location = new System.Drawing.Point(4, 38);
            this.btnSourceChooser.Margin = new System.Windows.Forms.Padding(4);
            this.btnSourceChooser.Name = "btnSourceChooser";
            this.btnSourceChooser.Size = new System.Drawing.Size(92, 31);
            this.btnSourceChooser.TabIndex = 1;
            this.btnSourceChooser.Text = "&Csv";
            this.btnSourceChooser.UseVisualStyleBackColor = true;
            this.btnSourceChooser.Click += new System.EventHandler(this.btnSourceChooser_Click);
            // 
            // csvDataGridView
            // 
            this.csvDataGridView.AllowUserToAddRows = false;
            this.csvDataGridView.AllowUserToDeleteRows = false;
            this.csvDataGridView.AllowUserToResizeRows = false;
            this.csvDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.csvDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.csvDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.csvMappedColumn});
            this.tableLayoutPanel1.SetColumnSpan(this.csvDataGridView, 2);
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.csvDataGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.csvDataGridView.Location = new System.Drawing.Point(3, 201);
            this.csvDataGridView.MultiSelect = false;
            this.csvDataGridView.Name = "csvDataGridView";
            this.csvDataGridView.ReadOnly = true;
            this.csvDataGridView.RowHeadersVisible = false;
            this.csvDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.csvDataGridView.RowTemplate.Height = 24;
            this.csvDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.csvDataGridView.Size = new System.Drawing.Size(341, 214);
            this.csvDataGridView.TabIndex = 0;
            this.csvDataGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.csvDataGridView_CellDoubleClick);
            this.csvDataGridView.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.csvDataGridView_CellValueChanged);
            this.csvDataGridView.SelectionChanged += new System.EventHandler(this.csvDataGridView_SelectionChanged);
            // 
            // Id
            // 
            this.Id.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            // 
            // csvMappedColumn
            // 
            this.csvMappedColumn.HeaderText = "Mapped";
            this.csvMappedColumn.Name = "csvMappedColumn";
            this.csvMappedColumn.ReadOnly = true;
            this.csvMappedColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.csvMappedColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.csvMappedColumn.Visible = false;
            // 
            // txtSourcePath
            // 
            this.txtSourcePath.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.SetColumnSpan(this.txtSourcePath, 4);
            this.txtSourcePath.Location = new System.Drawing.Point(102, 42);
            this.txtSourcePath.Margin = new System.Windows.Forms.Padding(2);
            this.txtSourcePath.Name = "txtSourcePath";
            this.txtSourcePath.Size = new System.Drawing.Size(1084, 22);
            this.txtSourcePath.TabIndex = 25;
            // 
            // txtDestinationPath
            // 
            this.txtDestinationPath.AllowDrop = true;
            this.txtDestinationPath.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.SetColumnSpan(this.txtDestinationPath, 4);
            this.txtDestinationPath.Location = new System.Drawing.Point(104, 81);
            this.txtDestinationPath.Margin = new System.Windows.Forms.Padding(4);
            this.txtDestinationPath.Name = "txtDestinationPath";
            this.txtDestinationPath.Size = new System.Drawing.Size(1080, 22);
            this.txtDestinationPath.TabIndex = 27;
            // 
            // dsdDataGridView
            // 
            this.dsdDataGridView.AllowUserToAddRows = false;
            this.dsdDataGridView.AllowUserToDeleteRows = false;
            this.dsdDataGridView.AllowUserToResizeRows = false;
            this.dsdDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dsdDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dsdDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IdDsd,
            this.NameDsd,
            this.TypeDsd,
            this.dsdMappedColumn,
            this.dsdColumnMandatory});
            this.tableLayoutPanel1.SetColumnSpan(this.dsdDataGridView, 2);
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dsdDataGridView.DefaultCellStyle = dataGridViewCellStyle4;
            this.dsdDataGridView.Location = new System.Drawing.Point(844, 201);
            this.dsdDataGridView.MultiSelect = false;
            this.dsdDataGridView.Name = "dsdDataGridView";
            this.dsdDataGridView.ReadOnly = true;
            this.dsdDataGridView.RowHeadersVisible = false;
            this.dsdDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dsdDataGridView.RowTemplate.Height = 24;
            this.dsdDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dsdDataGridView.Size = new System.Drawing.Size(341, 214);
            this.dsdDataGridView.TabIndex = 28;
            this.dsdDataGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dsdDataGridView_CellDoubleClick);
            this.dsdDataGridView.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dsdDataGridView_CellValueChanged);
            this.dsdDataGridView.SelectionChanged += new System.EventHandler(this.dsdDataGridView_SelectionChanged);
            // 
            // IdDsd
            // 
            this.IdDsd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.IdDsd.HeaderText = "Id";
            this.IdDsd.MinimumWidth = 150;
            this.IdDsd.Name = "IdDsd";
            this.IdDsd.ReadOnly = true;
            // 
            // NameDsd
            // 
            this.NameDsd.HeaderText = "Name";
            this.NameDsd.Name = "NameDsd";
            this.NameDsd.ReadOnly = true;
            // 
            // TypeDsd
            // 
            this.TypeDsd.FillWeight = 150F;
            this.TypeDsd.HeaderText = "Type";
            this.TypeDsd.Name = "TypeDsd";
            this.TypeDsd.ReadOnly = true;
            this.TypeDsd.Width = 150;
            // 
            // dsdMappedColumn
            // 
            this.dsdMappedColumn.HeaderText = "Mapped";
            this.dsdMappedColumn.Name = "dsdMappedColumn";
            this.dsdMappedColumn.ReadOnly = true;
            this.dsdMappedColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dsdMappedColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dsdMappedColumn.Visible = false;
            // 
            // dsdColumnMandatory
            // 
            this.dsdColumnMandatory.HeaderText = "Mandatory";
            this.dsdColumnMandatory.Name = "dsdColumnMandatory";
            this.dsdColumnMandatory.ReadOnly = true;
            this.dsdColumnMandatory.Visible = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.csvSelectedListBox, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.dsdSelectedListBox, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.addCsvItem, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.addDsdItem, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.removeCsvItem, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.removeDsdItem, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.autoMapButton, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.mapButton, 2, 3);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(350, 201);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32.6572F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 67.3428F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(488, 214);
            this.tableLayoutPanel2.TabIndex = 29;
            // 
            // csvSelectedListBox
            // 
            this.csvSelectedListBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.csvSelectedListBox.FormattingEnabled = true;
            this.csvSelectedListBox.ItemHeight = 16;
            this.csvSelectedListBox.Location = new System.Drawing.Point(84, 49);
            this.csvSelectedListBox.Name = "csvSelectedListBox";
            this.tableLayoutPanel2.SetRowSpan(this.csvSelectedListBox, 2);
            this.csvSelectedListBox.Size = new System.Drawing.Size(157, 116);
            this.csvSelectedListBox.TabIndex = 0;
            this.csvSelectedListBox.SelectedIndexChanged += new System.EventHandler(this.csvSelectedListBox_SelectedIndexChanged);
            // 
            // dsdSelectedListBox
            // 
            this.dsdSelectedListBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dsdSelectedListBox.FormattingEnabled = true;
            this.dsdSelectedListBox.ItemHeight = 16;
            this.dsdSelectedListBox.Location = new System.Drawing.Point(247, 49);
            this.dsdSelectedListBox.Name = "dsdSelectedListBox";
            this.tableLayoutPanel2.SetRowSpan(this.dsdSelectedListBox, 2);
            this.dsdSelectedListBox.Size = new System.Drawing.Size(157, 116);
            this.dsdSelectedListBox.TabIndex = 1;
            this.dsdSelectedListBox.SelectedIndexChanged += new System.EventHandler(this.dsdSelectedListBox_SelectedIndexChanged);
            // 
            // addCsvItem
            // 
            this.addCsvItem.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.addCsvItem.Enabled = false;
            this.addCsvItem.Location = new System.Drawing.Point(3, 108);
            this.addCsvItem.Name = "addCsvItem";
            this.addCsvItem.Size = new System.Drawing.Size(75, 30);
            this.addCsvItem.TabIndex = 2;
            this.addCsvItem.Text = "Add";
            this.addCsvItem.UseVisualStyleBackColor = true;
            this.addCsvItem.Click += new System.EventHandler(this.addCsvItem_Click);
            // 
            // addDsdItem
            // 
            this.addDsdItem.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.addDsdItem.Enabled = false;
            this.addDsdItem.Location = new System.Drawing.Point(410, 108);
            this.addDsdItem.Name = "addDsdItem";
            this.addDsdItem.Size = new System.Drawing.Size(75, 30);
            this.addDsdItem.TabIndex = 3;
            this.addDsdItem.Text = "Add";
            this.addDsdItem.UseVisualStyleBackColor = true;
            this.addDsdItem.Click += new System.EventHandler(this.addDsdItem_Click);
            // 
            // removeCsvItem
            // 
            this.removeCsvItem.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.removeCsvItem.Enabled = false;
            this.removeCsvItem.Location = new System.Drawing.Point(3, 144);
            this.removeCsvItem.Name = "removeCsvItem";
            this.removeCsvItem.Size = new System.Drawing.Size(75, 30);
            this.removeCsvItem.TabIndex = 4;
            this.removeCsvItem.Text = "Remove";
            this.removeCsvItem.UseVisualStyleBackColor = true;
            this.removeCsvItem.Click += new System.EventHandler(this.removeCsvItem_Click);
            // 
            // removeDsdItem
            // 
            this.removeDsdItem.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.removeDsdItem.Enabled = false;
            this.removeDsdItem.Location = new System.Drawing.Point(410, 144);
            this.removeDsdItem.Name = "removeDsdItem";
            this.removeDsdItem.Size = new System.Drawing.Size(75, 30);
            this.removeDsdItem.TabIndex = 5;
            this.removeDsdItem.Text = "Remove";
            this.removeDsdItem.UseVisualStyleBackColor = true;
            this.removeDsdItem.Click += new System.EventHandler(this.removeDsdItem_Click);
            // 
            // autoMapButton
            // 
            this.autoMapButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.autoMapButton.Enabled = false;
            this.autoMapButton.Location = new System.Drawing.Point(151, 180);
            this.autoMapButton.Name = "autoMapButton";
            this.autoMapButton.Size = new System.Drawing.Size(90, 30);
            this.autoMapButton.TabIndex = 6;
            this.autoMapButton.Text = "Auto Map";
            this.autoMapButton.UseVisualStyleBackColor = true;
            this.autoMapButton.Click += new System.EventHandler(this.autoMapButton_Click);
            // 
            // mapButton
            // 
            this.mapButton.Enabled = false;
            this.mapButton.Location = new System.Drawing.Point(247, 180);
            this.mapButton.Name = "mapButton";
            this.mapButton.Size = new System.Drawing.Size(90, 30);
            this.mapButton.TabIndex = 6;
            this.mapButton.Text = "Map";
            this.mapButton.UseVisualStyleBackColor = true;
            this.mapButton.Click += new System.EventHandler(this.mapButton_Click);
            // 
            // mappingDataGridView
            // 
            this.mappingDataGridView.AllowUserToAddRows = false;
            this.mappingDataGridView.AllowUserToDeleteRows = false;
            this.mappingDataGridView.AllowUserToResizeRows = false;
            this.mappingDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mappingDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.mappingDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mappingCsvIdCoumn,
            this.mappingDsdIdColumn});
            this.mappingDataGridView.Location = new System.Drawing.Point(350, 421);
            this.mappingDataGridView.Name = "mappingDataGridView";
            this.mappingDataGridView.ReadOnly = true;
            this.mappingDataGridView.RowHeadersVisible = false;
            this.mappingDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.mappingDataGridView.RowTemplate.Height = 24;
            this.mappingDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.mappingDataGridView.Size = new System.Drawing.Size(488, 214);
            this.mappingDataGridView.TabIndex = 30;
            this.mappingDataGridView.SelectionChanged += new System.EventHandler(this.mappingDataGridView_SelectionChanged);
            // 
            // mappingCsvIdCoumn
            // 
            this.mappingCsvIdCoumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.mappingCsvIdCoumn.HeaderText = "Csv Id";
            this.mappingCsvIdCoumn.Name = "mappingCsvIdCoumn";
            this.mappingCsvIdCoumn.ReadOnly = true;
            // 
            // mappingDsdIdColumn
            // 
            this.mappingDsdIdColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.mappingDsdIdColumn.HeaderText = "Dsd Id";
            this.mappingDsdIdColumn.Name = "mappingDsdIdColumn";
            this.mappingDsdIdColumn.ReadOnly = true;
            // 
            // removeMappingButton
            // 
            this.removeMappingButton.Enabled = false;
            this.removeMappingButton.Location = new System.Drawing.Point(844, 421);
            this.removeMappingButton.Name = "removeMappingButton";
            this.removeMappingButton.Size = new System.Drawing.Size(139, 33);
            this.removeMappingButton.TabIndex = 31;
            this.removeMappingButton.Text = "Remove mapping";
            this.removeMappingButton.UseVisualStyleBackColor = true;
            this.removeMappingButton.Click += new System.EventHandler(this.removeMappingButton_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel3.ColumnCount = 8;
            this.tableLayoutPanel1.SetColumnSpan(this.tableLayoutPanel3, 5);
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.decimalSeparatorTextBox, 6, 0);
            this.tableLayoutPanel3.Controls.Add(this.lblDecSep, 5, 0);
            this.tableLayoutPanel3.Controls.Add(this.filedSeparatorTextBox, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.hasHeaderCheckBox, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.label2, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.FieldDelimiterTextBox, 3, 0);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1182, 28);
            this.tableLayoutPanel3.TabIndex = 33;
            // 
            // decimalSeparatorTextBox
            // 
            this.decimalSeparatorTextBox.AllowDrop = true;
            this.decimalSeparatorTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.decimalSeparatorTextBox.Location = new System.Drawing.Point(607, 4);
            this.decimalSeparatorTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.decimalSeparatorTextBox.MaxLength = 1;
            this.decimalSeparatorTextBox.Name = "decimalSeparatorTextBox";
            this.decimalSeparatorTextBox.Size = new System.Drawing.Size(60, 22);
            this.decimalSeparatorTextBox.TabIndex = 37;
            this.decimalSeparatorTextBox.Text = ".";
            this.decimalSeparatorTextBox.Visible = false;
            // 
            // lblDecSep
            // 
            this.lblDecSep.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblDecSep.AutoSize = true;
            this.lblDecSep.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblDecSep.Location = new System.Drawing.Point(472, 5);
            this.lblDecSep.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDecSep.Name = "lblDecSep";
            this.lblDecSep.Size = new System.Drawing.Size(127, 17);
            this.lblDecSep.TabIndex = 36;
            this.lblDecSep.Text = "Decimal separator:";
            this.lblDecSep.Visible = false;
            // 
            // filedSeparatorTextBox
            // 
            this.filedSeparatorTextBox.AllowDrop = true;
            this.filedSeparatorTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.filedSeparatorTextBox.Location = new System.Drawing.Point(119, 4);
            this.filedSeparatorTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.filedSeparatorTextBox.MaxLength = 1;
            this.filedSeparatorTextBox.Name = "filedSeparatorTextBox";
            this.filedSeparatorTextBox.Size = new System.Drawing.Size(60, 22);
            this.filedSeparatorTextBox.TabIndex = 34;
            this.filedSeparatorTextBox.Text = ";";
            this.filedSeparatorTextBox.TextChanged += new System.EventHandler(this.filedSeparatorTextBox_TextChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1.AutoSize = true;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(4, 5);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 17);
            this.label1.TabIndex = 33;
            this.label1.Text = "Field separator:";
            // 
            // hasHeaderCheckBox
            // 
            this.hasHeaderCheckBox.AutoSize = true;
            this.hasHeaderCheckBox.Checked = true;
            this.hasHeaderCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.hasHeaderCheckBox.Location = new System.Drawing.Point(361, 3);
            this.hasHeaderCheckBox.Name = "hasHeaderCheckBox";
            this.hasHeaderCheckBox.Size = new System.Drawing.Size(104, 21);
            this.hasHeaderCheckBox.TabIndex = 35;
            this.hasHeaderCheckBox.Text = "Has header";
            this.hasHeaderCheckBox.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label2.AutoSize = true;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(187, 5);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 17);
            this.label2.TabIndex = 38;
            this.label2.Text = "Field delimiter:";
            // 
            // FieldDelimiterTextBox
            // 
            this.FieldDelimiterTextBox.AllowDrop = true;
            this.FieldDelimiterTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.FieldDelimiterTextBox.Location = new System.Drawing.Point(294, 4);
            this.FieldDelimiterTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.FieldDelimiterTextBox.MaxLength = 1;
            this.FieldDelimiterTextBox.Name = "FieldDelimiterTextBox";
            this.FieldDelimiterTextBox.Size = new System.Drawing.Size(60, 22);
            this.FieldDelimiterTextBox.TabIndex = 39;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1091, 421);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 34;
            this.button1.Text = "Test";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnXmlChooser
            // 
            this.btnXmlChooser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnXmlChooser.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnXmlChooser.Location = new System.Drawing.Point(4, 116);
            this.btnXmlChooser.Margin = new System.Windows.Forms.Padding(4);
            this.btnXmlChooser.Name = "btnXmlChooser";
            this.btnXmlChooser.Size = new System.Drawing.Size(92, 31);
            this.btnXmlChooser.TabIndex = 26;
            this.btnXmlChooser.Text = "Sdm&x";
            this.btnXmlChooser.UseVisualStyleBackColor = true;
            this.btnXmlChooser.Click += new System.EventHandler(this.btnXmlChooser_Click);
            // 
            // txtXmlPath
            // 
            this.txtXmlPath.AllowDrop = true;
            this.txtXmlPath.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.SetColumnSpan(this.txtXmlPath, 4);
            this.txtXmlPath.Location = new System.Drawing.Point(104, 120);
            this.txtXmlPath.Margin = new System.Windows.Forms.Padding(4);
            this.txtXmlPath.Name = "txtXmlPath";
            this.txtXmlPath.Size = new System.Drawing.Size(1080, 22);
            this.txtXmlPath.TabIndex = 27;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel4.ColumnCount = 6;
            this.tableLayoutPanel1.SetColumnSpan(this.tableLayoutPanel4, 25);
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.cmbSdmxFormats, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label5, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.comboBoxDimensionAtObservation, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.button2, 5, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 154);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1182, 41);
            this.tableLayoutPanel4.TabIndex = 35;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(4, 12);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 17);
            this.label3.TabIndex = 33;
            this.label3.Text = "Sdmx format:";
            // 
            // cmbSdmxFormats
            // 
            this.cmbSdmxFormats.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cmbSdmxFormats.FormattingEnabled = true;
            this.cmbSdmxFormats.Location = new System.Drawing.Point(101, 8);
            this.cmbSdmxFormats.Name = "cmbSdmxFormats";
            this.cmbSdmxFormats.Size = new System.Drawing.Size(240, 24);
            this.cmbSdmxFormats.TabIndex = 34;
            this.cmbSdmxFormats.SelectedValueChanged += new System.EventHandler(this.cmbSdmxFormats_SelectedValueChanged);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label5.AutoSize = true;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(498, 12);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(171, 17);
            this.label5.TabIndex = 34;
            this.label5.Text = "Dimension at Observation";
            // 
            // comboBoxDimensionAtObservation
            // 
            this.comboBoxDimensionAtObservation.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.comboBoxDimensionAtObservation.FormattingEnabled = true;
            this.comboBoxDimensionAtObservation.Location = new System.Drawing.Point(676, 8);
            this.comboBoxDimensionAtObservation.Name = "comboBoxDimensionAtObservation";
            this.comboBoxDimensionAtObservation.Size = new System.Drawing.Size(223, 24);
            this.comboBoxDimensionAtObservation.TabIndex = 34;
            // 
            // selectFileDialog
            // 
            this.selectFileDialog.Filter = "CSV (*.csv)|*.csv|All files (*.*)|*.*";
            // 
            // selectDsdFileDialog
            // 
            this.selectDsdFileDialog.Filter = "Sdmx (*.xml)|*.xml|All files (*.*)|*.*";
            // 
            // saveConfigDialog
            // 
            this.saveConfigDialog.Filter = "Xml files (*.xml)|*.xml|All files (*.*)|*.*";
            // 
            // loadConfigDialog
            // 
            this.loadConfigDialog.Filter = "Xml files (*.xml)|*.xml|All files (*.*)|*.*";
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Filter = "Xml files (*.xml)|*.xml|All files (*.*)|*.*";
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button2.Location = new System.Drawing.Point(1073, 4);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(105, 32);
            this.button2.TabIndex = 1;
            this.button2.Text = "&Set Header";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // MappingWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1188, 709);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "MappingWindow";
            this.Text = "MappingWindow";
            this.Activated += new System.EventHandler(this.MappingWindow_Enter);
            this.Deactivate += new System.EventHandler(this.MappingWindow_Leave);
            this.VisibleChanged += new System.EventHandler(this.MappingWindow_VisibleChanged);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.buttonGrouper.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.csvDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsdDataGridView)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mappingDataGridView)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnSourceChooser;
        private System.Windows.Forms.TextBox txtSourcePath;
        private System.Windows.Forms.OpenFileDialog selectFileDialog;
        private System.Windows.Forms.Button btnDsdChooser;
        private System.Windows.Forms.TextBox txtDestinationPath;
        private System.Windows.Forms.OpenFileDialog selectDsdFileDialog;
        private System.Windows.Forms.DataGridView mappingDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn mappingCsvIdCoumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mappingDsdIdColumn;
        private System.Windows.Forms.Button removeMappingButton;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox filedSeparatorTextBox;
        private System.Windows.Forms.CheckBox hasHeaderCheckBox;
        private System.Windows.Forms.Label lblDecSep;
        private System.Windows.Forms.TextBox decimalSeparatorTextBox;
        private System.Windows.Forms.SaveFileDialog saveConfigDialog;
        private System.Windows.Forms.OpenFileDialog loadConfigDialog;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox FieldDelimiterTextBox;
        private System.Windows.Forms.Button btnXmlChooser;
        private System.Windows.Forms.TextBox txtXmlPath;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.DataGridView csvDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewCheckBoxColumn csvMappedColumn;
        private System.Windows.Forms.DataGridView dsdDataGridView;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ListBox csvSelectedListBox;
        private System.Windows.Forms.ListBox dsdSelectedListBox;
        private System.Windows.Forms.Button addCsvItem;
        private System.Windows.Forms.Button addDsdItem;
        private System.Windows.Forms.Button removeCsvItem;
        private System.Windows.Forms.Button removeDsdItem;
        private System.Windows.Forms.Button mapButton;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbSdmxFormats;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdDsd;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameDsd;
        private System.Windows.Forms.DataGridViewTextBoxColumn TypeDsd;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dsdMappedColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dsdColumnMandatory;
        private System.Windows.Forms.Button autoMapButton;
        private System.Windows.Forms.Panel buttonGrouper;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBoxDimensionAtObservation;
        private System.Windows.Forms.Button button2;
    }
}