﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Excel2Csv.Classes
{
    public class EncodingContainer
    {
        public Encoding Encoding { get; }

        public string DisplayedName { get; }

        public EncodingContainer(Encoding encoding, string displayedName)
        {
            Encoding = encoding;
            DisplayedName = displayedName;
        }
    }
}
