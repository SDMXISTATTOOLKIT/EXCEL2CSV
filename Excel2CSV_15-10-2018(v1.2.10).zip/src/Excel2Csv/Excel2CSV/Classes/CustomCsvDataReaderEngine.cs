﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper;
using Org.Sdmxsource.Sdmx.Api.Constants;
using Org.Sdmxsource.Sdmx.Api.Constants.InterfaceConstant;
using Org.Sdmxsource.Sdmx.Api.Engine;
using Org.Sdmxsource.Sdmx.Api.Manager.Retrieval;
using Org.Sdmxsource.Sdmx.Api.Model.Data;
using Org.Sdmxsource.Sdmx.Api.Model.Header;
using Org.Sdmxsource.Sdmx.Api.Model.Objects.DataStructure;
using Org.Sdmxsource.Sdmx.Api.Util;
using Org.Sdmxsource.Sdmx.DataParser.Engine.Reader;
using Org.Sdmxsource.Sdmx.SdmxObjects.Model.Data;
using Org.Sdmxsource.Sdmx.SdmxObjects.Model.Header;
using Org.Sdmxsource.Sdmx.SdmxObjects.Model.Mutable.DataStructure;
using Org.Sdmxsource.Sdmx.SdmxObjects.Model.Mutable.MetadataStructure;
using Org.Sdmxsource.Sdmx.SdmxObjects.Model.Objects.DataStructure;

namespace Excel2Csv.Classes
{
    class CustomCsvDataReaderEngine : AbstractDataReaderEngine
    {
        public static String DEFAULT_HEADER_ID = "ID1";
        public static String DEFAULT_SENDER_ID = "ZZ9";

        private CsvDto2 csvDto;
        private bool movedToNextDataset;

        private Queue<IKeyable> listOfKeyable = new Queue<IKeyable>();
        private Queue<IObservation> listOfObservation = new Queue<IObservation>();
        private Dictionary<int, ConceptInfo> mapping;
        private Dictionary<String, String> currentCsvValues = new Dictionary<string, string>();
        private IDimension dimensionAtObservation;
        private List<IKeyValue> datasetAttributes;

        public CustomCsvDataReaderEngine(IReadableDataLocation dataLocation, ISdmxObjectRetrievalManager objectRetrieval,
            IDataflowObject defaultDataflow, IDataStructureObject defaultDsd, IHeader header, CsvDto2 csvDto, Dictionary<int, ConceptInfo> mapping, string dimensionAtObservation)
            : base(dataLocation, objectRetrieval, defaultDataflow, defaultDsd)
        {
            if (objectRetrieval == null && defaultDsd == null)
                throw new ArgumentNullException("DataReaderEngine expects either a SdmxBeanRetrievalManager or a DataStructureBean to be able to interpret the structures");

            Header = header ?? new HeaderImpl(DEFAULT_HEADER_ID, DEFAULT_SENDER_ID);
            this.csvDto = csvDto;
            this.mapping = mapping;
            if (!string.IsNullOrEmpty(dimensionAtObservation))
            {
                this.dimensionAtObservation = defaultDsd.GetDimension(dimensionAtObservation);
            }
        }

        public override IList<IKeyValue> DatasetAttributes => datasetAttributes;

        public override IDataReaderEngine CreateCopy()
        {
            return new CustomCsvDataReaderEngine(DataLocation, ObjectRetrieval, DefaultDataflow, DefaultDsd, Header, csvDto, mapping, dimensionAtObservation.Id);
        }

        protected override IKeyable LazyLoadKey()
        {
            return null;
        }

        protected override IObservation LazyLoadObservation()
        {
            return null;
        }

        private void populateCurrentConceptValues()
        {
            foreach (var map in mapping)
            {
                //go through all concepts for this level and fill the values in currentCSvValue
                ConceptInfo conceptInfo = map.Value;
                string conceptName = conceptInfo.Id;
                if (conceptInfo.IsFixed)
                {
                    currentCsvValues[conceptName] = conceptInfo.FixedValue;
                }
                else
                {
                    if (conceptInfo.Column < csvRow.Length)
                    {
                        string conceptValue = csvRow[conceptInfo.Column];
                        string transcodedValue = "";
                        //if (csvInputConfig.getTranscoding() != null
                        //    && csvInputConfig.getTranscoding().containsKey(conceptName)
                        //    && csvInputConfig.getTranscoding().get(conceptName).containsKey(conceptValue))
                        //{
                        //    transcodedValue = csvInputConfig.getTranscoding().get(conceptName).get(conceptValue);
                        //}
                        //else
                        {
                            transcodedValue = conceptValue;
                        }
                        currentCsvValues[conceptName] = transcodedValue;
                    }
                    else
                    {
                        //  currentCsvValues[conceptName] = null;
                    }
                }
            }
        }

        private Dictionary<IKeyable, Dictionary<int, string[]>> internalDictionary = new Dictionary<IKeyable, Dictionary<int, string[]>>();
        private Queue<IKeyable> internalQueue = new Queue<IKeyable>();

        private int listIndex = 0;
        private IKeyable internalCurrentKeyable = null;

        private string[] next()
        {
            var list = internalDictionary[internalCurrentKeyable];
            if (listIndex < list.Count)
            {
                var temp = list[listIndex];
                listIndex++;
                return temp;
            }

            listIndex = 0;

            if (internalQueue.Count != 0)
            {
                internalCurrentKeyable = internalQueue.Dequeue();
                list = list = internalDictionary[internalCurrentKeyable];
                if (listIndex < list.Count)
                {
                    var temp = list[listIndex];
                    listIndex++;
                    return temp;
                }
            }
            return null;
        }

        protected override bool MoveNextDatasetInternal()
        {
            if (!movedToNextDataset)
            {
                setDataSetHeaderBean();
                // ciclo in tutte le rgihe del cvs per creare i dizionari interni di appoggio
                for (int i = 0; i < csvDto.RowNumber; i++)
                {
                    var line = csvDto.Dequeue();
                    var key = getKeyableFromACsvValues(populateConceptValues(line));

                    if (!internalDictionary.Keys.Contains(key))
                    {
                        var dic = new Dictionary<int, string[]>();
                        dic.Add(0, line);
                        internalDictionary.Add(key, dic);
                        internalQueue.Enqueue(key);
                    }
                    else
                    {
                        var dic = internalDictionary[key];
                        internalDictionary[key].Add(dic.Count, line);
                    }
                }

                csvDto.Clear();
                //         movedToNextDataset = true;
                internalCurrentKeyable = internalQueue.Dequeue();
            }

            if (!movedToNextDataset)
            {
                while (!movedToNextDataset)
                {
                    csvRow = getNextLineOfCsvFile();

                    populateCurrentConceptValues();

                    //a complete info exists by getting to the lowest level
                    //it is set here to prevent reading of another row after a a lowest level row was found
                    this.movedToNextDataset = true;
                }

                //set the current DatasetHeaderBean
                setDataSetHeaderBean();

                //sets the attributes for this data set from the complete list of CsvValues mapped to Concepts
                setCurrentDatasetAttributesFromCurrentCsvValues();

                //build Keyable for group
                IKeyable groupKeyable = getGroupFromCurrentCsvValues();
                if (groupKeyable != null)
                {
                    this.listOfKeyable.Enqueue(groupKeyable);
                }
                //build regular keyable, put in the list	
                IKeyable keyable = getKeyableFromCurrentCsvValues();
                this.listOfKeyable.Enqueue(keyable);

                //build observation(s)
                IObservation observation = getObservationFromCurrentCsvValues(keyable);
                this.listOfObservation.Enqueue(observation);

                return true;
            }
            return false;
        }

        private IObservation getObservationFromCurrentCsvValues(IKeyable keyable)
        {
            List<IKeyValue> attributes = new List<IKeyValue>();
            String obsValue = null;
            String obsTime = null;
            foreach (var conceptCode in currentCsvValues)
            {
                var componentBean = DefaultDsd.GetComponent(conceptCode.Key);
                if (componentBean != null && componentBean.StructureType == SdmxStructureEnumType.TimeDimension)
                {
                    obsTime = conceptCode.Value;
                }
                else
                {
                    if (componentBean is IPrimaryMeasure)
                    {
                        obsValue = conceptCode.Value;
                    }
                    else
                    {
                        if (componentBean is AttributeObjectCore core)
                        {
                            if (core.AttachmentLevel == AttributeAttachmentLevel.Observation)
                            {
                                if (!string.IsNullOrEmpty(conceptCode.Value))
                                {
                                    attributes.Add(new KeyValueImpl(conceptCode.Value, core.Id));
                                }
                            }
                        }
                    }
                }
            }

            IObservation observation;
            observation = (obsTime != null && dimensionAtObservation.TimeDimension) ? new ObservationImpl(keyable, obsTime, obsValue, attributes) : new ObservationImpl(keyable, obsTime ?? "", obsValue, attributes, new KeyValueImpl(currentCsvValues[dimensionAtObservation.Id], dimensionAtObservation.Id));
            return observation;

        }

        private IKeyable getKeyableFromCurrentCsvValues()
        {
            List<IKeyValue> dimensions = new List<IKeyValue>();
            List<IKeyValue> attributes = new List<IKeyValue>();
            String obsTime = null;
            foreach (var conceptCode in currentCsvValues)
            {
                var component = DefaultDsd.GetComponent(conceptCode.Key);
                if (component is IDimension)
                {
                    if (component.StructureType == SdmxStructureEnumType.TimeDimension)
                    {
                        obsTime = conceptCode.Value;
                        //if (dimensionAtObservation != null)
                        //    dimensions.Add(new KeyValueImpl(conceptCode.Value, component.Id));
                    }
                    else
                    {
                        if (!component.Equals(dimensionAtObservation))
                        {
                            dimensions.Add(new KeyValueImpl(conceptCode.Value, component.Id));
                        }
                    }
                }
                else
                {
                    if (!(component is AttributeObjectCore core)) continue;
                    if (core.AttachmentLevel == AttributeAttachmentLevel.DimensionGroup)
                    {
                        if (!string.IsNullOrEmpty(conceptCode.Value))
                        {
                            attributes.Add(new KeyValueImpl(conceptCode.Value, component.Id));
                        }
                    }
                }
            }
            IKeyable keyable;

            if (obsTime != null && dimensionAtObservation.TimeDimension)
            {
                Org.Sdmxsource.Sdmx.Api.Constants.TimeFormat timeFormat = Org.Sdmxsource.Sdmx.Util.Date.DateUtil.GetTimeFormatOfDate(obsTime);
                keyable = new KeyableImpl(Dataflow, DefaultDsd, dimensions, attributes, timeFormat);
            }
            else
            {
                Org.Sdmxsource.Sdmx.Api.Constants.TimeFormat timeFormat = Org.Sdmxsource.Sdmx.Util.Date.DateUtil.GetTimeFormatOfDate(obsTime ?? "");
                keyable = new KeyableImpl(Dataflow, DefaultDsd, dimensions, attributes, timeFormat, dimensionAtObservation.Id, obsTime ?? "");
            }
            return keyable;
        }

        private IKeyable getKeyableFromACsvValues(Dictionary<string, string> values)
        {
            List<IKeyValue> dimensions = new List<IKeyValue>();
            List<IKeyValue> attributes = new List<IKeyValue>();
            String obsTime = null;
            foreach (var conceptCode in values)
            {
                var component = DefaultDsd.GetComponent(conceptCode.Key);
                if (component is IDimension)
                {
                    if (component.StructureType == SdmxStructureEnumType.TimeDimension)
                    {
                        obsTime = conceptCode.Value;
                        //if (dimensionAtObservation != null)
                        //    dimensions.Add(new KeyValueImpl(conceptCode.Value, component.Id));
                    }
                    else
                    {
                        if (!component.Equals(dimensionAtObservation))
                        {
                            dimensions.Add(new KeyValueImpl(conceptCode.Value, component.Id));
                        }
                    }
                }
                else
                {
                    if (!(component is AttributeObjectCore core)) continue;
                    if (core.AttachmentLevel == AttributeAttachmentLevel.DimensionGroup)
                    {
                        if (!string.IsNullOrEmpty(conceptCode.Value))
                        {
                            attributes.Add(new KeyValueImpl(conceptCode.Value, component.Id));
                        }
                    }
                }
            }
            IKeyable keyable;

            if (obsTime != null && dimensionAtObservation.TimeDimension)
            {
                Org.Sdmxsource.Sdmx.Api.Constants.TimeFormat timeFormat = Org.Sdmxsource.Sdmx.Util.Date.DateUtil.GetTimeFormatOfDate(obsTime);
                keyable = new KeyableImpl(Dataflow, DefaultDsd, dimensions, attributes, timeFormat);
            }
            else
            {
                Org.Sdmxsource.Sdmx.Api.Constants.TimeFormat timeFormat = Org.Sdmxsource.Sdmx.Util.Date.DateUtil.GetTimeFormatOfDate(obsTime ?? "");
                keyable = new KeyableImpl(Dataflow, DefaultDsd, dimensions, attributes, timeFormat, dimensionAtObservation.Id, obsTime ?? "");
            }
            return keyable;
        }

        private Dictionary<string, string> populateConceptValues(string[] values)
        {
            var ret = new Dictionary<string, string>();
            foreach (var map in mapping)
            {
                //go through all concepts for this level and fill the values in currentCSvValue
                ConceptInfo conceptInfo = map.Value;
                string conceptName = conceptInfo.Id;
                if (conceptInfo.IsFixed)
                {
                    ret[conceptName] = conceptInfo.FixedValue;
                }
                else
                {
                    if (conceptInfo.Column < values.Length)
                    {
                        string conceptValue = values[conceptInfo.Column];
                        string transcodedValue = "";
                        //if (csvInputConfig.getTranscoding() != null
                        //    && csvInputConfig.getTranscoding().containsKey(conceptName)
                        //    && csvInputConfig.getTranscoding().get(conceptName).containsKey(conceptValue))
                        //{
                        //    transcodedValue = csvInputConfig.getTranscoding().get(conceptName).get(conceptValue);
                        //}
                        //else
                        {
                            transcodedValue = conceptValue;
                        }
                        ret[conceptName] = transcodedValue;
                    }
                    else
                    {
                        //  currentCsvValues[conceptName] = null;
                    }
                }
            }
            return ret;
        }

        private IKeyable getGroupFromCurrentCsvValues()
        {
            var listOfGroup = DefaultDsd.Groups;
            foreach (var group in listOfGroup)
            {
                List<IKeyValue> dimensions = new List<IKeyValue>();
                List<IKeyValue> attributes = new List<IKeyValue>();
                foreach (var conceptCode in currentCsvValues)
                {
                    var component = DefaultDsd.GetComponent(conceptCode.Key);
                    if (component is IDimension && group.DimensionRefs.Contains(conceptCode.Key))
                    {
                        dimensions.Add(new KeyValueImpl(conceptCode.Value, conceptCode.Key));
                    }
                    else
                    {
                        if (!(component is AttributeObjectCore core) || core.AttachmentLevel != AttributeAttachmentLevel.Group || @group.Id != core.AttachmentGroup) continue;
                        if (!string.IsNullOrEmpty(conceptCode.Value))
                        {
                            attributes.Add(new KeyValueImpl(conceptCode.Value, conceptCode.Key));
                        }
                    }
                }
                if (attributes.Any())
                {
                    IKeyable keyable = new KeyableImpl(Dataflow, DefaultDsd, dimensions, attributes, group.Id);
                    return keyable;
                }
            }

            return null;
        }

        private void setCurrentDatasetAttributesFromCurrentCsvValues()
        {
            List<IKeyValue> attributes = new List<IKeyValue>();
            foreach (var conceptCode in currentCsvValues)
            {
                var component = DefaultDsd.GetComponent(conceptCode.Key);
                if (component is AttributeObjectCore)
                {
                    if (((AttributeObjectCore)component).AttachmentLevel == AttributeAttachmentLevel.DataSet)
                    {
                        if (!string.IsNullOrEmpty(conceptCode.Value))
                        {
                            attributes.Add(new KeyValueImpl(conceptCode.Value, component.Id));
                        }
                    }
                }
            }

            datasetAttributes = attributes;
        }

        private void setDataSetHeaderBean()
        {
            dimensionAtObservation = getDimensionAtObservation();

            DatasetHeader = new DatasetHeaderCore(DefaultDsd.Id, DatasetActionEnumType.Information, new DatasetStructureReferenceCore(null, DefaultDsd.AsReference, null, null, dimensionAtObservation.Id));
        }

        private IDimension getDimensionAtObservation()
        {
            if (dimensionAtObservation != null)
                return dimensionAtObservation;

            if (DefaultDsd.TimeDimension != null)
            {
                return DefaultDsd.TimeDimension;
            }
            else
            {
                var listOfDimensionBeans = DefaultDsd.GetDimensions(SdmxStructureEnumType.MeasureDimension);
                if (listOfDimensionBeans.Any())
                {
                    return listOfDimensionBeans[0];
                }
                else
                {
                    var dimensions = DefaultDsd.GetDimensions();
                    return dimensions.Last();
                }
            }
        }

        private IKeyable previousKeyable;
        private String[] csvRow;

        private string[] getNextLineOfCsvFile()
        {
            return next();
        }

        protected override bool MoveNextKeyableInternal()
        {
            if (listOfKeyable.Any())
            {
                CurrentKeyValue = listOfKeyable.Dequeue();
                previousKeyable = CurrentKeyValue;
            }
            else
            {
                IKeyable newKeyable = null;

                while (newKeyable == null || previousKeyable.Equals(newKeyable))
                {
                    csvRow = getNextLineOfCsvFile();
                    if (csvRow == null)
                    {
                        //currentRow = 0;
                        return false;
                    }

                    emptyConceptValuesForLowerThanCurrentLevel();
                    populateCurrentConceptValues();

                    newKeyable = getKeyableFromCurrentCsvValues();
                }

                IKeyable groupKeyable = getGroupFromCurrentCsvValues();
                if (groupKeyable != null)
                {
                    this.listOfKeyable.Enqueue(groupKeyable);
                }

                //set the currentKeyable - main purpose of this interface method
                CurrentKeyValue = getKeyableFromCurrentCsvValues();

                //empty list of observations as the new keyable is not related to the old observations
                listOfObservation = new Queue<IObservation>();
                var obs = getObservationFromCurrentCsvValues(CurrentKeyValue);
                listOfObservation.Enqueue(obs);
            }

            previousKeyable = CurrentKeyValue;//currentKey will become null with the first moveNextKeyable call
            return true;
        }

        private void emptyConceptValuesForLowerThanCurrentLevel()
        {
            foreach (var entryConcept in mapping)
            {

                //go through all concepts for this level and empty the values in currentCSvValue
                String conceptName = csvDto.Headers[entryConcept.Key].Value;
                if (currentCsvValues.ContainsKey(conceptName))
                    currentCsvValues[conceptName] = null;
                else
                    currentCsvValues.Add(conceptName, null);
            }
        }

        protected override bool MoveNextObservationInternal()
        {
            if (listOfObservation.Any())
            {
                CurrentObs = listOfObservation.Dequeue();
                return true;
            }

            csvRow = getNextLineOfCsvFile();
            if (csvRow == null)
            {
                //currentRow = 0;
                return false;
            }

            emptyConceptValuesForLowerThanCurrentLevel();
            populateCurrentConceptValues();

            IKeyable newKeyable = getKeyableFromCurrentCsvValues();
            if (!CurrentKeyValue.Equals(newKeyable))
            {

                IKeyable groupKeyable = getGroupFromCurrentCsvValues();
                if (groupKeyable != null)
                    listOfKeyable.Enqueue(groupKeyable);
                listOfKeyable.Enqueue(newKeyable);

                IObservation newObservation = getObservationFromCurrentCsvValues(newKeyable);
                listOfObservation = new Queue<IObservation>(); //reset listOfObservations as Keyable has changed
                listOfObservation.Enqueue(newObservation); //this new Observation(s) is related to a new Keyable hence cannot be set as current
                return false;
            }
            else
            {
                IObservation newObservation = getObservationFromCurrentCsvValues(CurrentKeyValue);
                if (CurrentObs != null && newObservation.Equals(CurrentObs))
                {
                    return false;
                }

                CurrentObs = newObservation;
                return true;
            }
        }

        public void ClearInternalData()
        {
            if (internalQueue != null)
            {
                internalQueue.Clear();
                internalQueue = null;
            }

            if (internalDictionary != null)
            {
                internalDictionary.Clear();
                internalDictionary = null;
            }
        }
    }
}
