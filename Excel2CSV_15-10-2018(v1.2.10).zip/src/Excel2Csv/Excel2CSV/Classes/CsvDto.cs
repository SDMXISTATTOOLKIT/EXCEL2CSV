﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Org.Sdmxsource.Sdmx.Api.Model.Objects.Reference;

namespace Excel2Csv.Classes
{
    internal class CsvHeader
    {
        public string Value { get; set; }
        public int Index { get; set; }

        public CsvHeader(string header, int index)
        {
            Value = header;
            Index = index;
        }
    }

    internal class CsvDto2
    {
        private readonly Queue<string> rows;
        private readonly List<CsvHeader> headers;
        private readonly char separator;
        private readonly char? delimiter;

        public List<CsvHeader> Headers => headers;
        public int RowNumber => rows.Count;

        public CsvDto2(char separator, char? delimiter)
        {
            rows = new Queue<string>();
            headers = new List<CsvHeader>();
            this.separator = separator;
            this.delimiter = delimiter;
        }

        public void AddRow(string row, int index)
        {
            rows.Enqueue(row);
        }

        public void AddHeader(CsvHeader header)
        {
            headers.Add(header);
        }

        public void RemoveHeader(CsvHeader header)
        {
            headers.Remove(header);
        }

        public string[] Dequeue()
        {
            return splitWithDelimiter(rows.Dequeue());
        }

        public CsvHeader GetHeader(int index)
        {
            return headers.First(x => x.Index == index);
        }

        internal void Clear()
        {
            rows.Clear();
        }

        private string[] splitWithDelimiter(string str)
        {
            if (delimiter != null)
            {
                var split = str.Split(new[] { separator.ToString() + delimiter.ToString() }, StringSplitOptions.None);

                for (var index = 0; index < split.Length; index++)
                {
                    split[index] = split[index].Substring(1);
                }

                return split;
            }

            return str.Split(separator);
        }
    }
}
