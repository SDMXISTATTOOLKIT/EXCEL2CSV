﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Excel2Csv.Properties;
using Org.Sdmxsource.Sdmx.Api.Model.Objects.Reference;

namespace Excel2Csv.Classes
{
    internal class CsvImport2
    {
        private string fileName;
        private char? delimiter;
        private char separator;
        private bool hasHeaders;
        private IMaintainableRefObject refObject;

        internal CsvImport2(string fileName, char separator, char? delimiter, bool hasHeaders, IMaintainableRefObject refObject = null)
        {
            this.fileName = fileName;
            this.separator = separator;
            this.delimiter = delimiter;
            this.hasHeaders = hasHeaders;
            this.refObject = refObject;
        }

        internal CsvDto2 LoadHeaders()
        {
            var csvDto = new CsvDto2(separator, delimiter);

            using (var file = new StreamReader(fileName))
            {
                int columnCount = 0; // number of column
                string ln;

                // headers
                if ((ln = file.ReadLine()) != null)
                {
                    var data = splitWithDelimiter(ln);
                    columnCount = data.Length;

                    //data = new[] { "DATAFLOW" }.Concat(data).ToArray();

                    if (hasHeaders)
                    {
                        for (var index = 0; index < data.Length; index++)
                        {
                            var header = data[index];
                            if (string.IsNullOrEmpty(header))
                                csvDto.AddHeader(new CsvHeader(index.ToString(), index)); // set headers
                            else
                                csvDto.AddHeader(new CsvHeader(header, index)); // set headers
                        }
                    }
                    else
                    {
                        for (var index = 0; index < data.Length; index++)
                        {
                            csvDto.AddHeader(new CsvHeader(index.ToString(), index)); // set headers as position
                        }
                    }
                }
            }

            return csvDto;
        }

        private string[] splitWithDelimiter(string str)
        {
            if (delimiter != null)
            {
                var split = str.Split(new[] { separator.ToString() + delimiter.ToString() }, StringSplitOptions.None);

                for (var index = 0; index < split.Length; index++)
                {
                    split[index] = split[index].Substring(1);
                }

                return split;
            }

            return str.Split(separator);
        }

        internal CsvDto2 LoadCsv(bool hasDataFlowColumn)
        {
            var csvDto = new CsvDto2(separator, delimiter);

            using (var file = new StreamReader(fileName))
            {
                int rowIndex = 0; // row index
                string ln;
             
                // headers
                if ((ln = file.ReadLine()) != null)
                {
                    if (hasHeaders)
                    {
                        var data = splitWithDelimiter(ln);
            //            columnCount = data.Length;

                        if (!hasDataFlowColumn)
                            data = new[] { "DATAFLOW" }.Concat(data).ToArray();

                        for (var index = 0; index < data.Length; index++)
                        {
                            var header = data[index];
                            if (string.IsNullOrEmpty(header))
                                csvDto.AddHeader(new CsvHeader(index.ToString(), index)); // set headers
                            else
                                csvDto.AddHeader(new CsvHeader(header, index)); // set headers
                        }
                    }
                    else
                    {
                        if (!hasDataFlowColumn)
                        {
                            if (delimiter == null)
                                ln = "DATAFLOW" + separator + ln;
                            else
                                ln = delimiter + "DATAFLOW" + delimiter + separator + ln;
                        }

                        csvDto.AddRow(ln, rowIndex); // set data
                        rowIndex++;
                    }
                }

                while ((ln = file.ReadLine()) != null)
                {
                    if (!hasDataFlowColumn)
                    {
                        if (delimiter == null)
                            ln = "DATAFLOW" + separator + ln;
                        else
                            ln = delimiter + "DATAFLOW" + delimiter + separator + ln;
                    }

                    csvDto.AddRow(ln, rowIndex); // set data
                    rowIndex++;
                }

                file.Close();
            }

            return csvDto;
        }
    }
}