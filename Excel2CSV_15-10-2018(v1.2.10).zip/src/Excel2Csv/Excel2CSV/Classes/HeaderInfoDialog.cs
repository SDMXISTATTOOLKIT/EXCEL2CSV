﻿using System;
using System.Windows.Forms;

namespace Excel2Csv.Classes
{
    public partial class HeaderInfoDialog : Form
    {
        private MappingDialogPreferences preferences;

        public HeaderInfoDialog()
        {
            InitializeComponent();
        }

        private void setPreferences()
        {
            preferences.SenderOrgId = textBoxSenderOrgId.Text;
            preferences.SenderOrgName = textBoxSenderOrgName.Text;
            preferences.SenderName = textBoxSenderName.Text;
            preferences.SenderEmail = textBoxSenderEmail.Text;
            preferences.SenderDepartment = textBoxSenderDepartment.Text;
            preferences.SenderRole = textBoxSenderRole.Text;

            preferences.ReceiverOrgId = textBoxReceiverOrgId.Text;
            preferences.ReceiverOrgName = textBoxReceiverOrgName.Text;
            preferences.ReceiverName = textBoxReceiverName.Text;
            preferences.ReceiverEmail = textBoxReceiverEmail.Text;
            preferences.ReceiverDepartment = textBoxReceiverDepartment.Text;
            preferences.ReceiverRole = textBoxReceiverRole.Text;

            preferences.IsTest = checkBoxTestFlag.Checked;
            preferences.Transmission = textBoxTransmission.Text;
            preferences.AgencyId = textBoxAgencyId.Text;
            preferences.Source = textBoxSource.Text;
        }

        public MappingDialogPreferences GetMappingDialogPreferences()
        {
            return preferences;
        }

        public void Init(MappingDialogPreferences preferences)
        {
            this.preferences = preferences;

            textBoxSenderOrgId.Text = preferences.SenderOrgId;
            textBoxSenderOrgName.Text = preferences.SenderOrgName;
            textBoxSenderName.Text = preferences.SenderName;
            textBoxSenderEmail.Text = preferences.SenderEmail;
            textBoxSenderDepartment.Text = preferences.SenderDepartment;
            textBoxSenderRole.Text = preferences.SenderRole;

            textBoxReceiverOrgId.Text = preferences.ReceiverOrgId;
            textBoxReceiverOrgName.Text = preferences.ReceiverOrgName;
            textBoxReceiverName.Text = preferences.ReceiverName;
            textBoxReceiverEmail.Text = preferences.ReceiverEmail;
            textBoxReceiverDepartment.Text = preferences.ReceiverDepartment;
            textBoxReceiverRole.Text = preferences.ReceiverRole;

            checkBoxTestFlag.Checked = preferences.IsTest;
            textBoxTransmission.Text = preferences.Transmission;
            textBoxAgencyId.Text = preferences.AgencyId;
            textBoxSource.Text = preferences.Source;
        }

        private void buttonSaveHeader_Click(object sender, EventArgs e)
        {
            setPreferences();
            Close();
        }

        private void buttonCancelHeader_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
