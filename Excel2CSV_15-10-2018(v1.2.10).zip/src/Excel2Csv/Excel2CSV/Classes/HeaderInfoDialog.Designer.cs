﻿namespace Excel2Csv.Classes
{
    partial class HeaderInfoDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label10 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxSenderOrgId = new System.Windows.Forms.TextBox();
            this.textBoxSenderOrgName = new System.Windows.Forms.TextBox();
            this.textBoxSenderName = new System.Windows.Forms.TextBox();
            this.textBoxSenderEmail = new System.Windows.Forms.TextBox();
            this.textBoxSenderDepartment = new System.Windows.Forms.TextBox();
            this.textBoxSenderRole = new System.Windows.Forms.TextBox();
            this.textBoxAgencyId = new System.Windows.Forms.TextBox();
            this.textBoxReceiverOrgId = new System.Windows.Forms.TextBox();
            this.textBoxReceiverOrgName = new System.Windows.Forms.TextBox();
            this.textBoxReceiverName = new System.Windows.Forms.TextBox();
            this.textBoxReceiverEmail = new System.Windows.Forms.TextBox();
            this.textBoxReceiverDepartment = new System.Windows.Forms.TextBox();
            this.textBoxReceiverRole = new System.Windows.Forms.TextBox();
            this.textBoxTransmission = new System.Windows.Forms.TextBox();
            this.buttonCancelHeader = new System.Windows.Forms.Button();
            this.textBoxSource = new System.Windows.Forms.TextBox();
            this.buttonSaveHeader = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.checkBoxTestFlag = new System.Windows.Forms.CheckBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(414, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 17);
            this.label10.TabIndex = 9;
            this.label10.Text = "Receiver";
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(386, 291);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(92, 17);
            this.label17.TabIndex = 16;
            this.label17.Text = "Transmission";
            this.label17.Visible = false;
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(425, 331);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 17);
            this.label18.TabIndex = 17;
            this.label18.Text = "Source";
            // 
            // textBoxSenderOrgId
            // 
            this.textBoxSenderOrgId.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxSenderOrgId.Location = new System.Drawing.Point(91, 49);
            this.textBoxSenderOrgId.Name = "textBoxSenderOrgId";
            this.textBoxSenderOrgId.Size = new System.Drawing.Size(289, 22);
            this.textBoxSenderOrgId.TabIndex = 18;
            // 
            // textBoxSenderOrgName
            // 
            this.textBoxSenderOrgName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxSenderOrgName.Location = new System.Drawing.Point(91, 89);
            this.textBoxSenderOrgName.Name = "textBoxSenderOrgName";
            this.textBoxSenderOrgName.Size = new System.Drawing.Size(289, 22);
            this.textBoxSenderOrgName.TabIndex = 18;
            // 
            // textBoxSenderName
            // 
            this.textBoxSenderName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxSenderName.Location = new System.Drawing.Point(91, 129);
            this.textBoxSenderName.Name = "textBoxSenderName";
            this.textBoxSenderName.Size = new System.Drawing.Size(289, 22);
            this.textBoxSenderName.TabIndex = 18;
            // 
            // textBoxSenderEmail
            // 
            this.textBoxSenderEmail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxSenderEmail.Location = new System.Drawing.Point(91, 169);
            this.textBoxSenderEmail.Name = "textBoxSenderEmail";
            this.textBoxSenderEmail.Size = new System.Drawing.Size(289, 22);
            this.textBoxSenderEmail.TabIndex = 18;
            // 
            // textBoxSenderDepartment
            // 
            this.textBoxSenderDepartment.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxSenderDepartment.Location = new System.Drawing.Point(91, 209);
            this.textBoxSenderDepartment.Name = "textBoxSenderDepartment";
            this.textBoxSenderDepartment.Size = new System.Drawing.Size(289, 22);
            this.textBoxSenderDepartment.TabIndex = 18;
            // 
            // textBoxSenderRole
            // 
            this.textBoxSenderRole.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxSenderRole.Location = new System.Drawing.Point(91, 249);
            this.textBoxSenderRole.Name = "textBoxSenderRole";
            this.textBoxSenderRole.Size = new System.Drawing.Size(289, 22);
            this.textBoxSenderRole.TabIndex = 18;
            // 
            // textBoxAgencyId
            // 
            this.textBoxAgencyId.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxAgencyId.Location = new System.Drawing.Point(91, 329);
            this.textBoxAgencyId.Name = "textBoxAgencyId";
            this.textBoxAgencyId.Size = new System.Drawing.Size(289, 22);
            this.textBoxAgencyId.TabIndex = 18;
            // 
            // textBoxReceiverOrgId
            // 
            this.textBoxReceiverOrgId.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxReceiverOrgId.Location = new System.Drawing.Point(484, 49);
            this.textBoxReceiverOrgId.Name = "textBoxReceiverOrgId";
            this.textBoxReceiverOrgId.Size = new System.Drawing.Size(289, 22);
            this.textBoxReceiverOrgId.TabIndex = 18;
            // 
            // textBoxReceiverOrgName
            // 
            this.textBoxReceiverOrgName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxReceiverOrgName.Location = new System.Drawing.Point(484, 89);
            this.textBoxReceiverOrgName.Name = "textBoxReceiverOrgName";
            this.textBoxReceiverOrgName.Size = new System.Drawing.Size(289, 22);
            this.textBoxReceiverOrgName.TabIndex = 18;
            // 
            // textBoxReceiverName
            // 
            this.textBoxReceiverName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxReceiverName.Location = new System.Drawing.Point(484, 129);
            this.textBoxReceiverName.Name = "textBoxReceiverName";
            this.textBoxReceiverName.Size = new System.Drawing.Size(289, 22);
            this.textBoxReceiverName.TabIndex = 18;
            // 
            // textBoxReceiverEmail
            // 
            this.textBoxReceiverEmail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxReceiverEmail.Location = new System.Drawing.Point(484, 169);
            this.textBoxReceiverEmail.Name = "textBoxReceiverEmail";
            this.textBoxReceiverEmail.Size = new System.Drawing.Size(289, 22);
            this.textBoxReceiverEmail.TabIndex = 18;
            // 
            // textBoxReceiverDepartment
            // 
            this.textBoxReceiverDepartment.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxReceiverDepartment.Location = new System.Drawing.Point(484, 209);
            this.textBoxReceiverDepartment.Name = "textBoxReceiverDepartment";
            this.textBoxReceiverDepartment.Size = new System.Drawing.Size(289, 22);
            this.textBoxReceiverDepartment.TabIndex = 18;
            // 
            // textBoxReceiverRole
            // 
            this.textBoxReceiverRole.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxReceiverRole.Location = new System.Drawing.Point(484, 249);
            this.textBoxReceiverRole.Name = "textBoxReceiverRole";
            this.textBoxReceiverRole.Size = new System.Drawing.Size(289, 22);
            this.textBoxReceiverRole.TabIndex = 18;
            // 
            // textBoxTransmission
            // 
            this.textBoxTransmission.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxTransmission.Location = new System.Drawing.Point(484, 289);
            this.textBoxTransmission.Name = "textBoxTransmission";
            this.textBoxTransmission.Size = new System.Drawing.Size(289, 22);
            this.textBoxTransmission.TabIndex = 18;
            this.textBoxTransmission.Visible = false;
            // 
            // buttonCancelHeader
            // 
            this.buttonCancelHeader.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.buttonCancelHeader.Location = new System.Drawing.Point(211, 8);
            this.buttonCancelHeader.Name = "buttonCancelHeader";
            this.buttonCancelHeader.Size = new System.Drawing.Size(75, 30);
            this.buttonCancelHeader.TabIndex = 19;
            this.buttonCancelHeader.Text = "Cancel";
            this.buttonCancelHeader.UseVisualStyleBackColor = true;
            this.buttonCancelHeader.Click += new System.EventHandler(this.buttonCancelHeader_Click);
            // 
            // textBoxSource
            // 
            this.textBoxSource.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxSource.Location = new System.Drawing.Point(484, 329);
            this.textBoxSource.Name = "textBoxSource";
            this.textBoxSource.Size = new System.Drawing.Size(289, 22);
            this.textBoxSource.TabIndex = 18;
            // 
            // buttonSaveHeader
            // 
            this.buttonSaveHeader.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.buttonSaveHeader.Location = new System.Drawing.Point(130, 8);
            this.buttonSaveHeader.Name = "buttonSaveHeader";
            this.buttonSaveHeader.Size = new System.Drawing.Size(75, 30);
            this.buttonSaveHeader.TabIndex = 19;
            this.buttonSaveHeader.Text = "Ok";
            this.buttonSaveHeader.UseVisualStyleBackColor = true;
            this.buttonSaveHeader.Click += new System.EventHandler(this.buttonSaveHeader_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.label10, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label17, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.label18, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.textBoxSenderOrgId, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxSenderOrgName, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxSenderName, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBoxSenderEmail, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxSenderDepartment, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBoxSenderRole, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.textBoxAgencyId, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.textBoxReceiverOrgId, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBoxReceiverOrgName, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBoxReceiverName, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBoxReceiverEmail, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBoxReceiverDepartment, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBoxReceiverRole, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.textBoxTransmission, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.textBoxSource, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label11, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label12, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label13, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.label14, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.label15, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.label16, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.checkBoxTestFlag, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 3, 10);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 12);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 11;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.Size = new System.Drawing.Size(776, 426);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 331);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "Agency Id";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 291);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "Test Flag";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(48, 251);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Role";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 211);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Department";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Sen. Email";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Sen. Name";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Org.  Name";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Org.  Id";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(31, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 17);
            this.label9.TabIndex = 8;
            this.label9.Text = "Sender";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(423, 51);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 17);
            this.label11.TabIndex = 0;
            this.label11.Text = "Org.  Id";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(397, 91);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(81, 17);
            this.label12.TabIndex = 1;
            this.label12.Text = "Org.  Name";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(400, 131);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(78, 17);
            this.label13.TabIndex = 2;
            this.label13.Text = "Rec. Name";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(403, 171);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(75, 17);
            this.label14.TabIndex = 3;
            this.label14.Text = "Rec. Email";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(396, 211);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(82, 17);
            this.label15.TabIndex = 4;
            this.label15.Text = "Department";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(441, 251);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(37, 17);
            this.label16.TabIndex = 5;
            this.label16.Text = "Role";
            // 
            // checkBoxTestFlag
            // 
            this.checkBoxTestFlag.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.checkBoxTestFlag.AutoSize = true;
            this.checkBoxTestFlag.Location = new System.Drawing.Point(91, 291);
            this.checkBoxTestFlag.Name = "checkBoxTestFlag";
            this.checkBoxTestFlag.Size = new System.Drawing.Size(18, 17);
            this.checkBoxTestFlag.TabIndex = 20;
            this.checkBoxTestFlag.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.buttonSaveHeader, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.buttonCancelHeader, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(484, 376);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.Size = new System.Drawing.Size(289, 47);
            this.tableLayoutPanel2.TabIndex = 21;
            // 
            // HeaderInfoDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "HeaderInfoDialog";
            this.Text = "HeaderInfoDialog";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBoxSenderOrgId;
        private System.Windows.Forms.TextBox textBoxSenderOrgName;
        private System.Windows.Forms.TextBox textBoxSenderName;
        private System.Windows.Forms.TextBox textBoxSenderEmail;
        private System.Windows.Forms.TextBox textBoxSenderDepartment;
        private System.Windows.Forms.TextBox textBoxSenderRole;
        private System.Windows.Forms.TextBox textBoxAgencyId;
        private System.Windows.Forms.TextBox textBoxReceiverOrgId;
        private System.Windows.Forms.TextBox textBoxReceiverOrgName;
        private System.Windows.Forms.TextBox textBoxReceiverName;
        private System.Windows.Forms.TextBox textBoxReceiverEmail;
        private System.Windows.Forms.TextBox textBoxReceiverDepartment;
        private System.Windows.Forms.TextBox textBoxReceiverRole;
        private System.Windows.Forms.TextBox textBoxTransmission;
        private System.Windows.Forms.Button buttonCancelHeader;
        private System.Windows.Forms.TextBox textBoxSource;
        private System.Windows.Forms.Button buttonSaveHeader;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox checkBoxTestFlag;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
    }
}