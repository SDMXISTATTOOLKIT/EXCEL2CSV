﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excel2Csv.Classes
{
    class ConceptInfo
    {
        public ConceptInfo(int column, bool isFixed, string fixedValue, string id)
        {
            IsFixed = isFixed;
            FixedValue = fixedValue;
            Column = column;
            Id = id;
        }

        public bool IsFixed { get; set; }

        public string FixedValue { get; set; }

        public int Column { get; set; }

        public string Id { get;set;}
    }
}
