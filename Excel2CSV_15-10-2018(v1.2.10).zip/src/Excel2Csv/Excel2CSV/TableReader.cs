﻿//-----------------------------------------------------------------------
// <copyright file="TableReader.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Windows.Forms;
    using Excel2Csv.Properties;
    using NPOI.HSSF.UserModel;
    using NPOI.POIFS.FileSystem;
    using NPOI.SS.UserModel;
    using NPOI.SS.Util;
    using NPOI.XSSF.UserModel;
    using StringExtensions;

    /// <summary>
    /// Analyzes the table contained in a spreadsheet and eventually output its
    /// corresponding records in a comma-separated value form into an output file.
    /// </summary>
    /// <typeparam name="T">The type of <see cref="Field"/>, can be either a <see cref="DataField"/>
    /// or a <see cref="DimensionField"/>.</typeparam>
    public class TableReader<T> where T : Field, new()
    {
        /// <summary>The workbook of the input Excel file.</summary>
        private readonly IWorkbook wb;

        /// <summary>The selected sheet of the Excel file containing the table.</summary>
        private readonly ISheet sheet;

        /// <summary>The number of the records written in the latest operation.</summary>
        private int lastWrittenRecords = 0;

        /// <summary>The width of the side axis of the table.</summary>
        private int sideWidth;

        /// <summary>The height of the top axis of the table.</summary>
        private int topHeight;

        /// <summary>
        /// A dictionary that associates row indices to the contents
        /// of the side axis at the respective row.
        /// </summary>
        private SortedDictionary<int, List<CsvField>> sides;

        /// <summary>
        /// This can be seen a backup copy of the sides read at the very beginning.
        /// The values are kept in this structure in order to eventually restore the
        /// ones that were modified in the Field Editor.
        /// </summary>
        private SortedDictionary<int, List<CsvField>> actualSides;

        /// <summary>
        /// A dictionary that associates column indices to the contents
        /// of the top axis at the respective column.
        /// </summary>
        private SortedDictionary<int, List<CsvField>> headers;

        /// <summary>
        /// This can be seen a backup copy of the headers read at the very beginning.
        /// The values are kept in this structure in order to eventually restore the
        /// ones that were modified in the Field Editor.
        /// </summary>
        private SortedDictionary<int, List<CsvField>> actualHeaders;

        /// <summary>
        /// A list containing indices for empty rows that must be skipped.
        /// </summary>
        private List<int> emptyRows;

        /// <summary>
        /// A list containing indices for empty columns that must be skipped.
        /// </summary>
        private List<int> emptyCols;

        /// <summary>
        /// A list containing indices for the columns reserved to flags/attributes
        /// </summary>
        private List<int> flagCols;

        /// <summary>
        /// The dimensions put along the horizontal axis.
        /// </summary>
        private List<string> xAxis;

        /// <summary>
        /// The dimensions put along the vertical axis.
        /// </summary>
        private List<string> yAxis;

        /// <summary>
        /// Regular expression used for checking whether a decimal number
        /// included between 0 and 1 hides the integer zero part.
        /// </summary>
        private Regex startByComma;

        /// <summary>
        /// Initializes a new instance of the <see cref="TableReader{T}" /> class.
        /// </summary>
        /// <param name="config">The current table configuration.</param>
        public TableReader(BoundaryFieldConfig config)
        {
            this.ExcelFile = config.Source;
            this.TableStart = config.FirstCell;
            this.TableEnd = config.LastCell;
            this.DataStart = config.DataStartCell;
            this.SideWidth = config.SideWidth;
            this.topHeight = config.TopHeight;

            using (FileStream fs = new FileStream(this.ExcelFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                try
                {
                    this.wb = new HSSFWorkbook(fs);
                }
                catch (OfficeXmlFileException)
                {
                    // it looks like a FileStream gets closed after a failure in attempting to get its HSSFWorkbook
                    using (FileStream fs2 = new FileStream(this.ExcelFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        this.wb = new XSSFWorkbook(fs2);
                    }
                }
            }

            this.sheet = this.wb.GetSheetAt(config.Workbook);

            this.CheckAndFixLimits();

            if (config.LastCell.RowNumber > this.sheet.LastRowNum) 
            {
                throw new Exception(Resources.EndOutOfRange);
            }
        }

        /// <summary>
        /// Gets the number of records written in the latest operation.
        /// </summary>
        public int LastWrittenRecords
        {
            get
            {
                return this.lastWrittenRecords;
            }
        }

        /// <summary>
        /// Gets or sets the separator for the output CSV file.
        /// </summary>
        public string Separator
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the full path for the Excel input document.
        /// </summary>
        public string ExcelFile
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the upper left cell of the table.
        /// </summary>
        public CellPosition TableStart
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the lower right cell of the table.
        /// </summary>
        public CellPosition TableEnd
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the upper left cell of the data contained in the table.
        /// </summary>
        public CellPosition DataStart
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the decimal separator for raw values.
        /// </summary>
        public string DecimalSeparator
        {
            get;
            set;
        }

        /// <summary>
        /// Gets a value indicating whether the current instance processes data
        /// </summary>
        public bool IsDataMode
        {
            get
            {
                return typeof(DataField).IsAssignableFrom(typeof(T));
            }
        }

        /// <summary>
        /// Gets a value indicating whether the current instance processes code lists
        /// </summary>
        public bool IsCodeListMode
        {
            get
            {
                return typeof(DimensionField).IsAssignableFrom(typeof(T));
            }
        }

        /// <summary>
        /// Gets the current CSV field setup.
        /// </summary>
        public List<T> GetOrCreateFields
        {
            get
            {
                if (object.ReferenceEquals(this.Fields, null) || this.Fields.Count == 0)
                {
                    this.InitializeFields();
                }

                return this.Fields;
            }
        }

        /// <summary>
        /// Gets or sets the width of the side axis of the table.
        /// </summary>
        public int SideWidth
        {
            get
            {
                return this.sideWidth;
            }

            set
            {
                if (value < 0) 
                {
                    throw new InvalidOperationException(Resources.NegativeSideWidth);
                }

                if (this.TableStart.ColumnNumber + value > this.DataStart.ColumnNumber) 
                {
                    throw new InvalidOperationException(Resources.SideWidthOverlappingData);
                }

                this.sideWidth = value;
            }
        }

        /// <summary>
        /// Gets or sets the height of the top axis of the table.
        /// </summary>
        public int TopHeight
        {
            get
            {
                return this.topHeight;
            }

            set
            {
                if (value < 0) 
                {
                    throw new InvalidOperationException(Resources.NegativeTopHeight);
                }

                if (this.TableStart.RowNumber + value > this.DataStart.RowNumber)
                {
                    throw new InvalidOperationException(Resources.TopHeightOverlappingData);
                }

                this.topHeight = value;
            }
        }

        /// <summary>
        /// Gets or sets the current field setup
        /// </summary>
        internal List<T> Fields { get; set; }

        /// <summary>
        /// Writes the output file containing records of the comma-separated values representing
        /// the data of the table. Be warned that numeric values are written as they appears in
        /// their respective cells, extra decimals get rounded.
        /// </summary>
        /// <param name="outfile">The full path of the output CSV file.</param>
        /// <param name="encoding">The encoding of the file.</param>
        /// <param name="decimals">The maximum number of decimal digits allowed.</param>
        /// <param name="decSeparator">The decimal separator for numeric values.</param>
        /// <param name="separator">The field separator of the output CSV file.</param>
        /// <param name="codeDescDims">Specifies whether the codes shall be extracted from a "[Code] Description" expression.</param>
        /// <param name="expr">Specifies the currently selected from a "[Code] Description" expression.</param>
        /// <param name="allowNonNumericData">Whether non numeric values should be included in the output</param>
        /// <param name="showHeader">Whether to include a column header in the CSV.</param>
        public void WriteRecords(string outfile, Encoding encoding, int decimals, string decSeparator, string separator, bool codeDescDims, CodeDescExp expr, bool allowNonNumericData = false, bool showHeader = false)
        {
            //StreamWriter sw = null;
            this.lastWrittenRecords = 0;
            this.Separator = separator ?? Resources.DefaultSeparator;
            this.DecimalSeparator = string.IsNullOrEmpty(decSeparator) ? CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator : decSeparator;
            if (!object.ReferenceEquals(this.sides, null) || !object.ReferenceEquals(this.headers, null) || this.InitializeAxes())
            {
                this.UpdateTime();
                if (this.IsDataMode && !object.ReferenceEquals(this.GetOrCreateFields, null))
                {
                    // guess how many columns are reserved for attributes
                    var src = this.GetOrCreateFields.Cast<DataField>().Where(x => x.Type.Equals(FieldType.Attribute) && x.AttributeColumn > 0);
                    if (src.Any())
                    {
                        this.GetAttributes(src.Count());
                    }
                }

                try
                {
                    using (var progressDialog = new ProgressDialog())
                    using (var sw = new StreamWriter(outfile, false, encoding))
                    {
                        Regex rx = null, rx2 = null;
                        HashSet<string> codeHs = null;

                        if (this.IsCodeListMode)
                        {
                            codeHs = new HashSet<string>();
                        }

                        switch (expr.CodeType)
                        {
                            case CodeDescExpType.Default:
                            case CodeDescExpType.Optional:
                            case CodeDescExpType.Custom:
                                rx = this.ConvertToCodeRegex(expr);
                                rx2 = this.ConvertToDescriptionRegex(expr);
                                break;
                            default:
                                rx = null;
                                break;
                        }
                        
                        progressDialog.SetProgressMax(
                            ((this.sides.Count == 0) ? this.TableEnd.RowNumber - this.TableStart.RowNumber + 1 : this.sides.Count) *
                            ((this.headers.Count == 0) ? this.TableEnd.ColumnNumber - this.TableStart.ColumnNumber + 1 : this.headers.Count));
                        progressDialog.Show();

                        // handle the CSV header
                        if (showHeader)
                        {
                            // if no field settings have been entered, then just repeat the separator
                            if (object.ReferenceEquals(this.GetOrCreateFields, null))
                            {
                                sw.WriteLine(string.Concat(Enumerable.Repeat(this.Separator, this.sides.Count + this.headers.Count)));
                            }
                            else if (this.IsDataMode)
                            {
                                // otherwise output the field names excluding the value field in case we are extracting a code list
                                sw.WriteLine(string.Join(this.Separator, this.Fields.Where(i => !i.Hidden).Select(x => x.Dimension.ForceLTR()).ToArray()));
                            }
                            else
                            {
                                // ...or skip data values if it's a code list
                                sw.WriteLine(string.Join(this.Separator, this.Fields.Where(i => !i.Hidden && i.Type != FieldType.Value).Select(x => x.Dimension.ForceLTR()).ToArray()));
                            }
                        }

                        for (int rownum = this.DataStart.RowNumber; rownum <= this.TableEnd.RowNumber; rownum++)
                        {
                            IRow row = this.sheet.GetRow(rownum);
                            bool areRowTitlesEmpty = this.emptyRows.IndexOf(rownum) != -1;

                            // skip empty rows
                            if ((!areRowTitlesEmpty || this.IsDataMode) && !object.ReferenceEquals(row, null))
                            {
                                for (int colnum = this.DataStart.ColumnNumber; colnum <= this.TableEnd.ColumnNumber; colnum++)
                                {
                                    ICell cell = row.GetCell(colnum);
                                    bool areColTitlesPresent = this.emptyCols.IndexOf(colnum) != -1;
                                    bool isDataCell = object.ReferenceEquals(this.flagCols, null) || this.flagCols.IndexOf(colnum) == -1;

                                    if ((!areColTitlesPresent || this.IsDataMode) && (this.IsCodeListMode || (isDataCell && !object.ReferenceEquals(cell, null))))
                                    {
                                        List<string> mylist = new List<string>();
                                        bool pass = true;

                                        // add the sides to the output queue
                                        if (!object.ReferenceEquals(this.sides, null) && this.sides.Count > 0 && (!areRowTitlesEmpty || this.sides.Keys.Contains(rownum)))
                                        {
                                            mylist.AddRange(codeDescDims && !object.ReferenceEquals(rx, null) && this.IsDataMode ? this.sides[rownum].Select(x => x.IsTimeSeriesValue ? x.Value : rx.Replace(x.Value, "$1", 1)) : this.sides[rownum].Select(x => x.Value));
                                        }

                                        // add the headers to the output queue
                                        if (!object.ReferenceEquals(this.headers, null) && this.headers.Count > 0 && (!areColTitlesPresent || this.headers.Keys.Contains(colnum)))
                                        {
                                            mylist.AddRange(codeDescDims && !object.ReferenceEquals(rx, null) && this.IsDataMode ? this.headers[colnum].Select(x => x.IsTimeSeriesValue ? x.Value : rx.Replace(x.Value, "$1", 1)) : this.headers[colnum].Select(x => x.Value));
                                        }

                                        // if we are extracting data then add the value to the output queue
                                        if (this.IsDataMode)
                                        {
                                            mylist.Add(this.ReadStringifiedNumberCell(cell, decimals, allowNonNumericData).Trim().Replace(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator, this.DecimalSeparator));
                                        }

                                        // no field settings defined, just output the CSV fields as they are
                                        if (object.ReferenceEquals(this.Fields, null))
                                        {
                                            sw.WriteLine(string.Join(this.Separator, mylist.ToArray()));
                                        }
                                        else
                                        {
                                            List<string> line = new List<string>();
                                            string[] fieldArray = null;
                                            int fieldIdx = -1;
                                            int? descIdx = null;
                                            int? codeIdx = null;
                                            string blob = null;
                                            bool isCodeList = false;

                                            foreach (var field in this.Fields)
                                            {
                                                // if we are extracting data and the current field is a constant...
                                                if ((field is DataField) && field.Type.Equals(FieldType.Constant))
                                                {
                                                    // ...then enqueue constant values to the output
                                                    line.Add((field as DataField).Value);
                                                    fieldIdx++;
                                                }
                                                else if ((field is DataField) && field.Type.Equals(FieldType.Attribute))
                                                {
                                                    if (!field.Hidden)
                                                    {
                                                        // read the attribute from a cell distant from the current one by an offset
                                                        var attrcell = row.Cells[cell.ColumnIndex + (field as DataField).AttributeColumn];
                                                        line.Add(!object.ReferenceEquals(attrcell, null) ? attrcell.StringCellValue.ForceLTR().RemoveNewLines() : string.Empty);
                                                    }

                                                    fieldIdx++;
                                                }
                                                else if (field is DimensionField && field.Type.Equals(FieldType.EmbeddedDescription))
                                                {
                                                    // temporarily get the embedded description field index and slip an empty string in the queue
                                                    line.Add(string.Empty);
                                                    descIdx = ++fieldIdx;
                                                }
                                                else if (!field.Hidden && (this.IsDataMode || (this.IsCodeListMode && field.Type != FieldType.Value)))
                                                {
                                                    try
                                                    {
                                                        // if we aren't extracting data or this is not a constant and in either case the current field is not hidden
                                                        line.Add(mylist[(object.ReferenceEquals(field.Priority, null) ? 0 : (int)field.Priority) - 1]);
                                                    }
                                                    catch (ArgumentOutOfRangeException)
                                                    {
                                                        // this should happen in data mode only
                                                        pass = false;
                                                    }

                                                    fieldIdx++;
                                                }

                                                if (this.IsCodeListMode && field is DimensionField)
                                                {
                                                    DimensionField f = field as DimensionField;

                                                    if (f.IsCodeList)
                                                    {
                                                        codeIdx = fieldIdx;
                                                        isCodeList = true;

                                                        if (f.Type.Equals(FieldType.Row))
                                                        {
                                                            blob = this.headers[colnum][(int)f.Priority - 1];
                                                        }
                                                        else if (f.Type.Equals(FieldType.Column))
                                                        {
                                                            blob = this.sides[rownum][(int)f.Priority - 1];
                                                        }
                                                    }
                                                }
                                            }

                                            fieldArray = line.ToArray();
                                            if (this.IsDataMode)
                                            {
                                                string recordTest = string.Join(string.Empty, fieldArray);

                                                // additional test for data processing: write if the line isn't completely empty
                                                if (!string.IsNullOrWhiteSpace(recordTest) && pass)
                                                {
                                                    sw.WriteLine(string.Join(this.Separator, fieldArray));
                                                }
                                            }
                                            else
                                            {
                                                if (codeDescDims && !object.ReferenceEquals(rx, null))
                                                {
                                                    if (codeIdx != null)
                                                    {
                                                        string code = rx.Replace(blob, "$1", 1);

                                                        if (!codeHs.Contains(code))
                                                        {
                                                            codeHs.Add(code);
                                                            fieldArray[(int)codeIdx] = code;
                                                            if (descIdx != null)
                                                            {
                                                                fieldArray[(int)descIdx] = rx2.Replace(blob, "$1", 1).Trim();
                                                            }
                                                        }
                                                        else
                                                        {
                                                            pass = false;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    if (pass = !codeHs.Contains(blob) || !isCodeList)
                                                    {
                                                        codeHs.Add(blob);
                                                    }
                                                }

                                                if (pass)
                                                {
                                                    sw.WriteLine(string.Join(this.Separator, fieldArray));
                                                }
                                            }
                                        }

                                        if (pass)
                                        {
                                            this.lastWrittenRecords++;
                                            progressDialog.UpdateProgressBar(this.LastWrittenRecords);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                catch (IOException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                //finally
                //{
                //    if (!object.ReferenceEquals(sw, null))
                //    {
                //        sw.Dispose();
                //        sw = null;
                //    }
                //}
            }
            else
            {
                MessageBox.Show(Resources.OperationCancelled, Resources.OperationCancelledTitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// Updates the time series representation.
        /// </summary>
        public void UpdateTime()
        {
            if (object.ReferenceEquals(this.sides, null) || object.ReferenceEquals(this.headers, null))
            {
                this.InitializeAxes();
            }

            if (object.ReferenceEquals(this.Fields, null) || this.Fields.Count == 0)
            {
                this.InitializeFields();
            }

            foreach (var c in this.headers) 
            { 
                c.Value.Clear(); 
            }

            this.headers.Clear();
            this.headers = new SortedDictionary<int, List<CsvField>>(this.actualHeaders.ToDictionary(p => p.Key, p => p.Value.ToList()));

            foreach (var timerow in this.GetOrCreateFields.Where(i => i.IsTimeSeries && FieldType.Row.Equals(i.Type)))
            {

                int idx = this.yAxis.FindIndex(c => c.Equals(timerow.Label));
                if (!int.TryParse(timerow.Label, out int rownum))
                {
                    throw new FormatException();
                }

                rownum--;
                
                // do not use foreach here
                for (int hdi = 0; hdi < this.headers.Count; hdi++)
                {
                    KeyValuePair<int, List<CsvField>> col = this.headers.ElementAt(hdi);

                    int colnum = col.Key;
                    var newlist = col.Value.ToList();
                    newlist[idx] = new CsvField() { Value = this.ReadTimeCell(rownum, colnum, timerow.TimeMapping), IsTimeSeriesValue = true };
                    this.headers[colnum].Clear();
                    this.headers[colnum] = newlist;
                }
            }

            foreach (var c in this.sides)
            { 
                c.Value.Clear();
            }

            this.sides.Clear();
            this.sides = new SortedDictionary<int, List<CsvField>>(this.actualSides.ToDictionary(p => p.Key, p => p.Value.ToList()));

            foreach (var timecol in this.GetOrCreateFields.Where(i => i.IsTimeSeries && FieldType.Column.Equals(i.Type)))
            {
                int idx = this.xAxis.FindIndex(c => c.Equals(timecol.Label));
                int colnum = TableColumnLabeling.NumberForColumn(timecol.Label);

                colnum--;

                // do not use foreach here
                for (int sdi = 0; sdi < this.sides.Count; sdi++)
                {
                    KeyValuePair<int, List<CsvField>> row = this.sides.ElementAt(sdi);

                    int rownum = row.Key;
                    var newlist = row.Value.ToList();
                    newlist[idx] = new CsvField() { Value = this.ReadTimeCell(rownum, colnum, timecol.TimeMapping), IsTimeSeriesValue = true };
                    this.sides[rownum].Clear();
                    this.sides[rownum] = newlist;
                }
            }
        }

        /// <summary>
        /// Detect a list of table columns that are supposed to contain attributes
        /// </summary>
        /// <param name="num">Number of attribute columns</param>
        private void GetAttributes(int num)
        {
            System.Diagnostics.Debug.Assert(this.IsDataMode && num >= 0 && !object.ReferenceEquals(this.emptyCols, null), "Not in data mode or empty columns not yet detected.");
            this.flagCols = new List<int>();

            for (int idx = this.DataStart.ColumnNumber, cnt = 0; idx <= this.TableEnd.ColumnNumber; idx++, cnt++)
            {
                if (this.emptyCols.IndexOf(idx) == -1)
                {
                    if (cnt % (num + 1) != 0)
                    {
                        this.flagCols.Add(idx);
                    }
                }
            }
        }

        /// <summary>
        /// Analyses a string and breaks it up returning obtaining the parts of no interest in order to build a valid regular expression.
        /// Acknowledged strings can be in the form "beginning CODE middle DESCRIPTION ending" or "beginning DESCRIPTION middle CODE ending"
        /// </summary>
        /// <param name="cdexp">The input <see cref="CodeDescExp"/> object.</param>
        /// <param name="beginning">Initial part of the string</param>
        /// <param name="middle">Part between the two substrings of interest</param>
        /// <param name="ending">Ending part of the string</param>
        private void ConversionSplitter(CodeDescExp cdexp, out string beginning, out string middle, out string ending)
        {
            if (cdexp.CodeRange.Start < cdexp.DescriptionRange.Start)
            {
                beginning = cdexp.Expression.Substring(0, cdexp.CodeRange.Start).DeRegex();
                middle = cdexp.Expression.Substring(cdexp.CodeRange.End, cdexp.DescriptionRange.Start - cdexp.CodeRange.End).DeRegex();
                ending = cdexp.Expression.Substring(cdexp.DescriptionRange.End, cdexp.Expression.Length - cdexp.DescriptionRange.End).DeRegex();
            }
            else
            {
                beginning = cdexp.Expression.Substring(0, cdexp.DescriptionRange.Start).DeRegex();
                middle = cdexp.Expression.Substring(cdexp.DescriptionRange.End, cdexp.CodeRange.Start - cdexp.DescriptionRange.End).DeRegex();
                ending = cdexp.Expression.Substring(cdexp.CodeRange.End, cdexp.Expression.Length - cdexp.CodeRange.End).DeRegex();
            }

            if (cdexp.Trim)
            {
                beginning = string.Concat(@"\s*", beginning.Trim(), @"\s*");
                middle = string.Concat(@"\s*", middle.Trim(), @"\s*");
                ending = string.Concat(@"\s*", ending.Trim(), @"\s*");
            }
        }

        /// <summary>
        /// Converts a <see cref="CodeDescExp" /> object into a <see cref="Regex"/> one.
        /// </summary>
        /// <param name="cdexp">The input <see cref="CodeDescExp"/> object.</param>
        /// <returns>The input object turned into a <see cref="Regex"/> one.</returns>
        private Regex ConvertToCodeRegex(CodeDescExp cdexp)
        {
            this.ConversionSplitter(cdexp, out string beginning, out string middle, out string ending);

            string exp;
            if (cdexp.CodeRange.Start < cdexp.DescriptionRange.Start)
            {
                exp = string.Concat("^", beginning, @"(.*\S)?", middle, ".*", ending, "$");
            }
            else
            {
                exp = string.Concat("^", beginning, ".*", middle, @"(.*\S)?", ending, "$");
            }

            // it looks like making the parser work from the right to the left is the only way to make the expression non-greedy
            return new Regex(exp, RegexOptions.RightToLeft);
        }

        /// <summary>
        /// Converts a <see cref="CodeDescExp" /> object into a <see cref="Regex"/> one.
        /// </summary>
        /// <param name="cdexp">The input <see cref="CodeDescExp"/> object.</param>
        /// <returns>The input object turned into a <see cref="Regex"/> one.</returns>
        private Regex ConvertToDescriptionRegex(CodeDescExp cdexp)
        {
            this.ConversionSplitter(cdexp, out string beginning, out string middle, out string ending);

            string exp;
            if (cdexp.CodeRange.Start < cdexp.DescriptionRange.Start)
            {
                exp = string.Concat("^", beginning, ".*", middle, @"(.*\S)?", ending, "$");
            }
            else
            {
                exp = string.Concat("^", beginning, @"(.*\S)?", middle, ".*", ending, "$");
            }

            // it looks like making the parser work from the right to the left is the only way to make the expression non-greedy
            return new Regex(exp, RegexOptions.RightToLeft);
        }

        /// <summary>
        /// Given the coordinates of a supposedly merged cell, fetch the value of merged group,
        /// or null if the cell isn't merged to any other.
        /// </summary>
        /// <param name="row">Row number of the merged cell</param>
        /// <param name="col">Column number of the merged cell</param>
        /// <returns>The string value in the main menu cell or the merged area.</returns>
        private string GetMergedRegionStringValue(int row, int col)
        {
            for (int i = 0; i < this.sheet.NumMergedRegions; i++)
            {
                CellRangeAddress region = this.sheet.GetMergedRegion(i);

                if (!object.ReferenceEquals(region, null) && region.IsInRange(row, col))
                {
                    return this.GetEdgeValue(this.sheet.GetRow(region.FirstRow).GetCell(region.FirstColumn)).Trim();
                }
            }

            return null;
        }

        /// <summary>
        /// Initializes the fields to be set up in the field editor.
        /// </summary>
        private void InitializeFields()
        {
            if ((object.ReferenceEquals(this.sides, null) || object.ReferenceEquals(this.headers, null) || object.ReferenceEquals(this.Fields, null)) && this.InitializeAxes())
            {
                this.Fields = new List<T>();
                int cnt = 1;

                for (int i = 0; i < this.xAxis.Count; i++)
                {
                    var val = this.xAxis[i];
                    string sample = null;

                    try
                    {
                        sample = this.sides.ElementAt(0).Value.ElementAt(i);
                    }
                    catch
                    {
                        sample = string.Empty;
                    }

                    var elem = new T()
                    {
                        Priority = cnt++,
                        Type = FieldType.Column,
                        Label = val,
                        Dimension = null,
                        Sample = sample
                    };
                    if (this.IsDataMode)
                    {
                        (elem as DataField).Value = null;
                    }

                    this.Fields.Add(elem);
                }

                for (int i = 0; i < this.yAxis.Count; i++)
                {
                    var val = this.yAxis[i];
                    var elem = new T()
                    {
                        Priority = cnt++,
                        Type = FieldType.Row,
                        Label = val,
                        Dimension = null,
                        Sample = (!object.ReferenceEquals(this.headers, null) && this.headers.Count > 0) ? this.headers.ElementAt(0).Value.ElementAt(i).Value : null
                    };
                    if (this.IsDataMode)
                    {
                        (elem as DataField).Value = null;
                    }

                    this.Fields.Add(elem);
                }

                var elem2 = new T()
                    {
                        Priority = cnt,
                        Type = FieldType.Value,
                        Label = null,
                        Dimension = "Value",
                        Sample = null
                    };
                if (this.IsDataMode)
                {
                    (elem2 as DataField).Value = null;
                }

                this.Fields.Add(elem2);
            }
        }

        /// <summary>
        /// Reads the axes of the table and prepares the combinations of
        /// coordinates for each row and column.
        /// </summary>
        /// <returns>Whether the axis parsing went alright or not.</returns>
        private bool InitializeAxes()
        {
            HashSet<int> hs = new HashSet<int>();
            this.sides = new SortedDictionary<int, List<CsvField>>();
            this.headers = new SortedDictionary<int, List<CsvField>>();
            this.emptyRows = new List<int>();
            this.emptyCols = new List<int>();
            bool doWarn = true;
            int maxoffset = 0;

            if (!object.ReferenceEquals(this.Fields, null) && this.IsDataMode)
            {
                var src = this.Fields.Where(x => x.Type.Equals(FieldType.Attribute));
                if (src.Any())
                {
                    maxoffset = src.Max(x => (x as DataField).AttributeColumn);
                }
            }

            // get row side hedge
            if (this.SideWidth > 0) 
            {
                // for each row of the data area...
                for (var rowNum = this.DataStart.RowNumber; rowNum <= this.TableEnd.RowNumber; rowNum++) 
                {
                    IRow row = this.sheet.GetRow(rowNum);

                    // set the row as empty if it's undefined
                    if (object.ReferenceEquals(row, null))
                    {
                        this.emptyRows.Add(rowNum);
                        continue;
                    }

                    List<CsvField> mylist = new List<CsvField>();
                    bool isEmpty = true;
                    bool invalidValues = false;

                    // then move to the side: for each side cell of each row...
                    for (var colNum = this.TableStart.ColumnNumber; colNum < this.TableStart.ColumnNumber + this.SideWidth; colNum++) 
                    {
                        ICell cell = row.GetCell(colNum);
                        CsvField val = new CsvField() { Value = string.Empty };
                        if (!object.ReferenceEquals(cell, null))
                        {
                            val.Value = cell.IsMergedCell ? this.GetMergedRegionStringValue(rowNum, colNum) : this.GetEdgeValue(row.GetCell(colNum));
                        }

                        if (!string.IsNullOrWhiteSpace(val))
                        {
                            val.Value = val.Value.Trim();
                            mylist.Add(val);
                            hs.Add(colNum);
                            isEmpty = false;
                        }
                        else
                        {
                            invalidValues = doWarn;
                            mylist.Add(new CsvField() { Value = string.Empty });
                            hs.Add(colNum);
                        }
                    }

                    if (isEmpty)
                    {
                        this.emptyRows.Add(rowNum);
                    }
                    else
                    {
                        if (invalidValues && this.IsDataMode)
                        {
                            DialogResult result = MessageBox.Show(
                                string.Format(Resources.WarningInvalidRowValues, rowNum + 1),
                                Resources.ErrorTitle,
                                MessageBoxButtons.YesNoCancel,
                                MessageBoxIcon.Error);

                            switch (result)
                            {
                                case DialogResult.No:
                                    doWarn = false;
                                    break;
                                case DialogResult.Cancel:
                                    this.sides = this.headers = null;
                                    return false;
                                default:
                                    // do nothing
                                    break;
                            }
                        }

                        this.sides.Add(rowNum, mylist);
                    }
                }
            }

            this.xAxis = hs.ToList().Select(x => TableColumnLabeling.ColumnForNumber(x + 1)).ToList();

            hs = new HashSet<int>();

            // get column top edge
            if (this.TopHeight > 0)
            {
                int colcnt = -1;
                for (var colNum = this.DataStart.ColumnNumber; colNum <= this.TableEnd.ColumnNumber; colNum++)
                {
                    List<CsvField> mylist = new List<CsvField>();
                    bool isEmpty = true;
                    bool invalidValues = false;
                    bool isAttribute = false;
                    for (var rowNum = this.TableStart.RowNumber; rowNum < this.TableStart.RowNumber + this.TopHeight; rowNum++) 
                    {
                        IRow row = this.sheet.GetRow(rowNum);
                        if (object.ReferenceEquals(row, null))
                        {
                            invalidValues = doWarn;
                            mylist.Add(new CsvField() { Value = string.Empty });
                            hs.Add(rowNum);
                            continue;
                        }

                        ICell cell = row.GetCell(colNum);

                        if (object.ReferenceEquals(cell, null))
                        {
                            invalidValues = doWarn;
                            mylist.Add(new CsvField() { Value = string.Empty });
                            hs.Add(rowNum);
                            continue;
                        }

                        CsvField val = new CsvField() { Value = cell.IsMergedCell ? this.GetMergedRegionStringValue(rowNum, colNum) : this.GetEdgeValue(cell) };

                        if (!string.IsNullOrWhiteSpace(val))
                        {
                            val.Value = val.Value.Trim();
                            mylist.Add(val);
                            hs.Add(rowNum);
                            isEmpty = false;
                        }
                        else
                        {
                            if (maxoffset > 0 && (colcnt + 1) % (maxoffset + 1) > 0)
                            {
                                isAttribute = true;
                            }
                            else
                            {
                                invalidValues = doWarn;
                            }

                            mylist.Add(new CsvField() { Value = string.Empty });
                            hs.Add(rowNum);
                        }
                    }

                    if (isEmpty)
                    {
                        if (isAttribute)
                        {
                            this.flagCols.Add(colNum);
                            colcnt++;
                        }
                        else
                        {
                            this.emptyCols.Add(colNum);
                        }
                    }
                    else
                    {
                        colcnt++;
                        if (invalidValues && this.IsDataMode)
                        {
                            DialogResult result = MessageBox.Show(
                                string.Format(Resources.WarningInvalidColumnValues, TableColumnLabeling.ColumnForNumber(colNum + 1)),
                                Resources.ErrorTitle,
                                MessageBoxButtons.YesNoCancel,
                                MessageBoxIcon.Error);

                            switch (result)
                            {
                                case DialogResult.No:
                                    doWarn = false;
                                    break;
                                case DialogResult.Cancel:
                                    this.sides = this.headers = null;
                                    return false;
                                default:
                                    // do nothing
                                    break;
                            }
                        }

                        this.headers.Add(colNum, mylist);
                    }
                }
            }

            this.yAxis = hs.ToList().Select(x => (x + 1).ToString()).ToList();

            // the dictionaries we want to clone contain lists, hence we need to deep copy them
            // this is fairly easy in linq:
            if (!object.ReferenceEquals(this.actualHeaders, null))
            {
                foreach (var c in this.actualHeaders)
                { 
                    c.Value.Clear(); 
                }

                this.actualHeaders.Clear();
            }
            
            this.actualHeaders = new SortedDictionary<int, List<CsvField>>(this.headers.ToDictionary(p => p.Key, p => p.Value.ToList()));

            if (!object.ReferenceEquals(this.actualSides, null))
            {
                foreach (var c in this.actualSides)
                {
                    c.Value.Clear();
                }

                this.actualSides.Clear();
            }

            this.actualSides = new SortedDictionary<int, List<CsvField>>(this.sides.ToDictionary(p => p.Key, p => p.Value.ToList()));

            return true;
        }

        /// <summary>
        /// Fixes the boundaries of the table in case its corners were not given in the correct order.
        /// Also checks that all the parameters make sense.
        /// <example>Checks whether the side axis overlaps the table data.</example>
        /// </summary>
        private void CheckAndFixLimits()
        {
            if (this.TableStart.RowNumber > this.TableEnd.RowNumber)
            {
                int swap = this.TableEnd.RowNumber;
                this.TableEnd.RowNumber = this.TableStart.RowNumber;
                this.TableStart.RowNumber = swap;
            }

            if (this.TableStart.ColumnNumber > this.TableEnd.ColumnNumber)
            {
                int swap = this.TableEnd.ColumnNumber;
                this.TableEnd.ColumnNumber = this.TableStart.ColumnNumber;
                this.TableStart.ColumnNumber = swap;
            }

            if ((this.TableStart.RowNumber + this.TopHeight > this.DataStart.RowNumber) || (this.TableStart.ColumnNumber + this.SideWidth > this.DataStart.ColumnNumber))
            {
                throw new InvalidDataException(Resources.EdgeOverlappingData);
            }

            if ((this.DataStart.RowNumber > this.TableEnd.RowNumber) || (this.DataStart.ColumnNumber > this.TableEnd.ColumnNumber)) 
            {
                throw new InvalidDataException(Resources.DataOutOfTable);
            }
        }
        
        /// <summary>
        /// Reads the contents of the cell located in one of the axes.
        /// </summary>
        /// <param name="c">The cell to be read.</param>
        /// <returns>The contents of the cell.</returns>
        private string GetEdgeValue(ICell c)
        {
            if (object.ReferenceEquals(c, null)) 
            {
                return string.Empty;
            }

            switch (c.CellType) 
            {
                case CellType.Numeric:
                    if (DateUtil.IsCellDateFormatted(c))
                    {
                        DateTime dt = c.DateCellValue;
                        return string.Format("{0}-{1:00}", dt.Year, dt.Month);
                    }
                    else
                    {
                        if (DateTime.TryParse(c.NumericCellValue.ToString(), out DateTime res))
                        {
                            return string.Format("{0}-{1:00}", res.Year, res.Month);
                        }

                        return string.Format("{0}", c.NumericCellValue);
                    }

                case CellType.String:
                    return c.StringCellValue.ForceLTR().MergeLines();
                case CellType.Boolean:
                    return c.BooleanCellValue.ToString();
                case CellType.Formula:
                    CellValue cv = this.wb.GetCreationHelper().CreateFormulaEvaluator().Evaluate(c);
                    switch (cv.CellType)
                    {
                        case CellType.Numeric:
                            return cv.NumberValue.ToString();
                        case CellType.String:
                            return c.StringCellValue.ForceLTR().MergeLines();
                        case CellType.Boolean:
                            return c.BooleanCellValue.ToString();
                        default:
                            return string.Empty;
                    }

                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// Read the cell contents supposed to contain a time code
        /// </summary>
        /// <param name="row">The row in which the cell is located</param>
        /// <param name="col">The column in which the cell is located</param>
        /// <param name="timeMapping">The current time mapping settings</param>
        /// <returns>Returns the appropriately formatted string containing the read value</returns>
        private string ReadTimeCell(int row, int col, TimeFormat timeMapping)
        {
            var cell = this.sheet.GetRow(row).GetCell(col);

            string contents = (cell.IsMergedCell ? this.GetMergedRegionStringValue(row, col) : this.GetEdgeValue(cell)) ?? string.Empty;

            if (object.ReferenceEquals(timeMapping, null))
            {
                return contents;
            }

            if (timeMapping.IsDate)
            {
                int year;
                int month;

                if (cell.CellType == CellType.Numeric && DateUtil.IsCellDateFormatted(cell))
                {
                    DateTime dt = cell.DateCellValue;
                    year = dt.Year;
                    month = dt.Month;
                }
                else
                {
                    string strval;

                    switch (cell.CellType)
                    {
                        case CellType.Numeric:
                            strval = cell.NumericCellValue.ToString();
                            break;
                        case CellType.String:
                            strval = cell.StringCellValue.ForceLTR();
                            break;
                        case CellType.Boolean:
                            strval = cell.BooleanCellValue.ToString();
                            break;
                        case CellType.Formula:
                            var cv = this.wb.GetCreationHelper().CreateFormulaEvaluator().Evaluate(cell);
                            switch (cv.CellType)
                            {
                                case CellType.Numeric:
                                    strval = cv.NumberValue.ToString();
                                    break;
                                case CellType.String:
                                    strval = cell.StringCellValue.ForceLTR();
                                    break;
                                case CellType.Boolean:
                                    strval = cell.BooleanCellValue.ToString();
                                    break;
                                default:
                                    strval = string.Empty;
                                    break;
                            }

                            break;
                        default:
                            strval = string.Empty;
                            break;
                    }

                    if (DateTime.TryParse(strval, out DateTime res))
                    {
                        year = res.Year;
                        month = res.Month;
                    }
                    else
                    {
                        throw new CellContentException(string.Format(Resources.ErrorCancelTimeSetup, TableColumnLabeling.ColumnForNumber(col + 1), row + 1));
                    }
                }

                switch (timeMapping.DateCast)
                {
                    case TimePeriod.Monthly:
                        return string.Format("{0}-{1:00}", year, month);
                    case TimePeriod.Quarterly:
                        return string.Format("{0}-Q{1}", year, (int)((month - 1) / 3) + 1);
                    case TimePeriod.HalfYearly:
                        return string.Format("{0}-S{1}", year, (int)((month - 1) / 6) + 1);
                    default:
                        return year.ToString();
                }
            }
            else if (!string.IsNullOrWhiteSpace(contents))
            {
                try
                {
                    if (timeMapping.Monthly.Enabled)
                    {
                        string year = contents.Substring(timeMapping.Monthly.YearRange.Start, 1 + timeMapping.Monthly.YearRange.End - timeMapping.Monthly.YearRange.Start);
                        int period = Array.IndexOf(timeMapping.Monthly.PeriodMapping, contents.Substring(timeMapping.Monthly.PeriodRange.Start, 1 + timeMapping.Monthly.PeriodRange.End - timeMapping.Monthly.PeriodRange.Start));

                        if (period == -1)
                        {
                            return contents;
                        }

                        return string.Format("{0}-{1:00}", year, period + 1);
                    }
                    else if (timeMapping.Quarterly.Enabled)
                    {
                        string year = contents.Substring(timeMapping.Quarterly.YearRange.Start, 1 + timeMapping.Quarterly.YearRange.End - timeMapping.Quarterly.YearRange.Start);
                        int period = Array.IndexOf(timeMapping.Quarterly.PeriodMapping, contents.Substring(timeMapping.Quarterly.PeriodRange.Start, 1 + timeMapping.Quarterly.PeriodRange.End - timeMapping.Quarterly.PeriodRange.Start));

                        if (period == -1)
                        {
                            return contents;
                        }

                        return string.Format("{0}-Q{1}", year, period + 1);
                    }
                    else if (timeMapping.HalfYearly.Enabled)
                    {
                        string year = contents.Substring(timeMapping.HalfYearly.YearRange.Start, 1 + timeMapping.HalfYearly.YearRange.End - timeMapping.HalfYearly.YearRange.Start);
                        int period = Array.IndexOf(timeMapping.HalfYearly.PeriodMapping, contents.Substring(timeMapping.HalfYearly.PeriodRange.Start, 1 + timeMapping.HalfYearly.PeriodRange.End - timeMapping.HalfYearly.PeriodRange.Start));

                        if (period == -1)
                        {
                            return contents;
                        }

                        return string.Format("{0}-S{1}", year, period + 1);
                    }
                    else if (timeMapping.Yearly.Enabled)
                    {
                        return contents.Substring(timeMapping.Yearly.YearRange.Start, 1 + timeMapping.Yearly.YearRange.End - timeMapping.Yearly.YearRange.Start);
                    }
                    else
                    {
                        return contents;
                    }
                }
                catch (ArgumentOutOfRangeException)
                {
                    MessageBox.Show(string.Format(Resources.NoMapping, row + 1, TableColumnLabeling.ColumnForNumber(col + 1)));
                    return string.Empty;
                }
            }
            else
            {
                return contents;
            }
        }

        /// <summary>
        /// Converts the contents of cell data in a form containing rounds and stripped
        /// of the percentage sign or other signs.
        /// </summary>
        /// <param name="str">The cell data to be parsed.</param>
        /// <param name="decimals">The maximum amount of decimals allowed.</param>
        /// <returns>The resulting value representation.</returns>
        private string ParseStringNumberAsShown(string str, int decimals)
        {
            str = str.Replace(CultureInfo.CurrentCulture.NumberFormat.NumberGroupSeparator, string.Empty);
            if (str.IndexOf(Resources.Percent) != -1)
            {
                str = str.Replace(Resources.Percent, string.Empty);
            }

            // should something go wrong, the following line throws either a FormatException or an OverflowException
            decimal parsed = decimal.Parse(str);
            int pos = str.IndexOf(CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);
            if ((pos != -1) && (str.Length - pos > decimals)) 
            {
                return string.Format("{0:0." + new string('0', Convert.ToInt32(decimals)) + "}", parsed);
            }

            this.startByComma = this.startByComma ?? new Regex(string.Format(@"^(\-)*\{0}(.*)$", CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator));

            // a bit troublesome way to avoid starting zeroes
            var matches = this.startByComma.Match(str);

            if (matches.Success)
            {
                str = string.Format("{0}0,{1}", matches.Groups[1].Value, matches.Groups[2].Value);
            }

            return str;
        }
        
        /// <summary>
        /// Reads a given cell and retrieves its content by converting numeric value into
        /// strings and guessing on other data formats such as valid strings and formulas.
        /// </summary>
        /// <param name="cell">The cell to be read.</param>
        /// <param name="decimals">The maximum amount of allowed decimal digits.</param>
        /// <param name="allowNonNumericData">Whether non numeric values shall be allowed</param>
        /// <returns>The cell contents.</returns>
        private string ReadStringifiedNumberCell(ICell cell, int decimals, bool allowNonNumericData)
        {
            CellPosition pos = new CellPosition(cell.RowIndex, cell.ColumnIndex);
            string res = string.Empty;

            if (object.ReferenceEquals(cell, null))
            {
                throw new InvalidOperationException(string.Format(Resources.UndefinedCell_C_R, pos.ColumnLabel, pos.RowLabel));
            }
            
            switch (cell.CellType)
            {
                case CellType.Blank: return string.Empty;
                case CellType.Boolean:
                    if (allowNonNumericData)
                    {
                        return cell.BooleanCellValue.ToString();
                    }
                    else
                    {
                        return Convert.ToInt32(cell.BooleanCellValue).ToString();
                    }

                case CellType.Numeric:
                    try
                    {
                        return this.ParseStringNumberAsShown(new DataFormatter().FormatCellValue(cell), decimals);
                    }
                    catch
                    {
                        return this.ParseStringNumberAsShown(cell.NumericCellValue.ToString(), decimals);
                    }

                case CellType.String:
                    {
                        string repr = cell.StringCellValue.ForceLTR().RemoveNewLines();
                        if (allowNonNumericData)
                        {
                            return repr;
                        }

                        try
                        {
                            repr = cell.StringCellValue.ForceLTR().RemoveNewLines();
                            if ((!string.Empty.Equals(repr)) && (!string.Equals(repr.Trim(), Resources.Hyphen)))
                            {
                                return this.ParseStringNumberAsShown(repr, decimals);
                            }

                            return string.Empty;
                        }
                        catch
                        {
                            if (cell.StringCellValue.Trim().Equals(Resources.NotANumber))
                            {
                                return Resources.NotANumber;
                            }

                            throw new InvalidOperationException(string.Format(
                                Resources.ImpossibleString2NumberCast_C_R,
                                pos.ColumnLabel,
                                pos.RowLabel));
                        }
                    }

                case CellType.Formula:
                    CellValue cv = this.wb.GetCreationHelper().CreateFormulaEvaluator().Evaluate(cell);
                    switch (cv.CellType)
                    {
                        case CellType.Boolean:
                            if (allowNonNumericData)
                            {
                                return cv.BooleanValue.ToString();
                            }
                            else
                            {
                                return Convert.ToInt32(cv.BooleanValue).ToString();
                            }

                        case CellType.Numeric: return Math.Round(cv.NumberValue, decimals).ToString();
                        case CellType.String:
                            {
                                string repr = (cv.StringValue ?? string.Empty).RemoveNewLines();

                                if (allowNonNumericData)
                                {
                                    return repr;
                                }

                                try
                                {
                                    if (!string.Empty.Equals(repr))
                                    {
                                        return Math.Round(decimal.Parse(repr), decimals).ToString();
                                    }

                                    return string.Empty;
                                }
                                catch
                                {
                                    if (cv.StringValue.Trim().Equals(Resources.NotANumber))
                                    {
                                        return Resources.NotANumber;
                                    }

                                    throw new InvalidOperationException(
                                        string.Format(
                                            Resources.ImpossibleString2NumberCast_C_R,
                                            pos.ColumnLabel,
                                            pos.RowLabel));
                                }
                            }

                        default:
                            throw new InvalidOperationException(
                                string.Format(
                                    Resources.InvalidCellFormat_C_R,
                                    pos.ColumnLabel,
                                    pos.RowLabel));
                    }

                default:
                    throw new InvalidOperationException(string.Format(
                        Resources.InvalidCellFormat_C_R,
                        pos.ColumnLabel,
                        pos.RowLabel));
            }
        }
    }
}
