﻿//-----------------------------------------------------------------------
// <copyright file="BoundaryFieldConfig.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.
namespace Excel2Csv
{
    /// <summary>Class containing the information for the current table boundaries.</summary>
    public class BoundaryFieldConfig
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BoundaryFieldConfig" /> class.
        /// </summary>
        public BoundaryFieldConfig()
        {
            this.DataStartCell = new CellPosition(0, 0);
            this.FirstCell = new CellPosition(0, 0);
            this.LastCell = new CellPosition(0, 0);
        }

        /// <summary>Gets or sets the source file</summary>
        public string Source { get; set; }

        /// <summary>Gets or sets the position for the first cell of the table</summary>
        public CellPosition FirstCell { get; set; }

        /// <summary>Gets or sets the position for the last cell of the table</summary>
        public CellPosition LastCell { get; set; }

        /// <summary>Gets or sets the position for the first cell of the data area of the table</summary>
        public CellPosition DataStartCell { get; set; }

        /// <summary>Gets or sets the first column of the table</summary>
        public string FirstColumn
        {
            get
            {
                return this.FirstCell.ColumnLabel;
            }

            set
            {
                this.FirstCell.ColumnLabel = value;
            }
        }

        /// <summary>Gets or sets the first row of the table</summary>
        public string FirstRow
        {
            get
            {
                return this.FirstCell.RowLabel.ToString();
            }

            set
            {
                this.FirstCell.RowLabel = int.Parse(value);
            }
        }

        /// <summary>Gets or sets the last column of the table</summary>
        public string LastColumn
        {
            get
            {
                return this.LastCell.ColumnLabel;
            }

            set
            {
                this.LastCell.ColumnLabel = value;
            }
        }

        /// <summary>Gets or sets the last row of the table</summary>
        public string LastRow
        {
            get
            {
                return this.LastCell.RowLabel.ToString();
            }

            set
            {
                this.LastCell.RowLabel = int.Parse(value);
            }
        }

        /// <summary>Gets or sets the first column of the table data</summary>
        public string DataColumn
        {
            get
            {
                return this.DataStartCell.ColumnLabel;
            }

            set
            {
                this.DataStartCell.ColumnLabel = value;
            }
        }

        /// <summary>Gets or sets the first row of the table data</summary>
        public string DataRow
        {
            get
            {
                return this.DataStartCell.RowLabel.ToString();
            }
            
            set
            {
                this.DataStartCell.RowLabel = int.Parse(value);
            }
        }

        /// <summary>Gets or sets the width of the table side</summary>
        public int SideWidth
        {
            get
            {
                return this._sideWidth;
            }

            set
            {
                if (value < 0)
                {
                    throw new System.ArgumentOutOfRangeException();
                }

                this._sideWidth = value;
            }
        }

        /// <summary>Gets or sets the height of the table top</summary>
        public int TopHeight
        {
            get
            {
                return this._topHeight;
            }

            set
            {
                if (value < 0)
                {
                    throw new System.ArgumentOutOfRangeException();
                }

                this._topHeight = value;
            }
        }

        /// <summary>Gets or sets the number of the workbook containing the table</summary>
        public int Workbook
        {
            get
            {
                return this._workbook;
            }

            set
            {
                if (value < 0)
                {
                    throw new System.ArgumentOutOfRangeException();
                }

                this._workbook = value;
            }
        }

        /// <summary>Gets or sets the reading direction, used for extracting dimensions.</summary>
        public DirectionType Direction { get; set; }

        /// <summary>Gets or sets the height of the header measured in cells</summary>
        private int _topHeight { get; set; }

        /// <summary>Gets or sets the width of the side measured in cells</summary>
        private int _sideWidth { get; set; }

        /// <summary>Gets or sets the number of the workbook page, numbered by starting from zero</summary>
        private int _workbook { get; set; }

        /// <summary>Compares two BoundaryFieldConfig objects against equality.</summary>
        /// <param name="a">The first object</param>
        /// <param name="b">The second object</param>
        /// <returns>Whether the object contents are the same or not.</returns>
        public static bool operator ==(BoundaryFieldConfig a, BoundaryFieldConfig b)
        {
            if (object.ReferenceEquals(a, null))
            {
                return object.ReferenceEquals(b, null);
            }

            return a.Equals(b);
        }

        /// <summary>Compares two BoundaryFieldConfig objects against inequality.</summary>
        /// <param name="a">The first object</param>
        /// <param name="b">The second object</param>
        /// <returns>Whether the object contents are different or not.</returns>
        public static bool operator !=(BoundaryFieldConfig a, BoundaryFieldConfig b)
        {
            if (object.ReferenceEquals(a, null))
            {
                return !object.ReferenceEquals(b, null);
            }

            return !a.Equals(b);
        }

        /// <summary>
        /// Calculate the unique hash code for the current object.
        /// </summary>
        /// <returns>The hash code for the current object.</returns>
        public override int GetHashCode()
        {
            return string.Format(
                "{0}_{1}_{2}_{3}_{4}_{5}_{6}_{7}_{8}_{9}_{10}",
                this.Source,
                this.FirstColumn,
                this.FirstRow,
                this.LastColumn,
                this.LastRow,
                this.SideWidth,
                this.TopHeight,
                this.DataColumn,
                this.DataRow,
                this.Workbook,
                this.Direction).GetHashCode();
        }

        /// <summary>
        /// Tests whether the current object has got the same contents as another one.
        /// </summary>
        /// <param name="b">The second object of the comparison.</param>
        /// <returns>Whether the two objects have the same contents or not.</returns>
        public override bool Equals(object b)
        {
            if (object.ReferenceEquals(b, null) || (b.GetType() != this.GetType()))
            {
                return false;
            }

            var c = (BoundaryFieldConfig)b;

            /*
             // compare all the boundaries vs compare just the table structures
            return this.Source.Equals(c.Source) && this.Workbook.Equals(c.Workbook) &&
                this.FirstColumn.Equals(c.FirstColumn) && this.FirstRow.Equals(c.FirstRow) &&
                this.LastColumn.Equals(c.LastColumn) && this.LastRow.Equals(c.LastRow) &&
                this.SideWidth.Equals(c.SideWidth) && this.TopHeight.Equals(c.TopHeight) &&
                this.DataColumn.Equals(c.DataColumn) && this.DataRow.Equals(c.DataRow) &&
                this.Direction.Equals(c.Direction);
             */
            return this.Source.Equals(c.Source) && this.Workbook.Equals(c.Workbook) &&
                this.FirstColumn.Equals(c.FirstColumn) && this.FirstRow.Equals(c.FirstRow) &&
                this.SideWidth.Equals(c.SideWidth) && this.TopHeight.Equals(c.TopHeight) &&
                this.Direction.Equals(c.Direction);
        }
    }
}
