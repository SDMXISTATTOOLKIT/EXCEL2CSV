﻿//-----------------------------------------------------------------------
// <copyright file="FrequencyFormat.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    /// <summary>
    /// Enumerates the time frequencies
    /// </summary>
    public enum TimePeriod
    {
        /// <summary>Monthly frequency period</summary>
        Monthly = 0,

        /// <summary>Quarterly frequency period</summary>
        Quarterly = 1,

        /// <summary>HalfYearly frequency period</summary>
        HalfYearly = 2,

        /// <summary>Yearly frequency period</summary>
        Yearly = 3
    }

    /// <summary>Class containing the mapping information for a given period.</summary>
    public class FrequencyFormat
    {
        /// <summary>Gets or sets the expression containing the year</summary>
        public string YearInFrequencyExpression { get; set; }

        /// <summary>Gets or sets the expression containing the period</summary>
        public string PeriodInFrequencyExpression { get; set; }

        /// <summary>Gets or sets the range of characters defining the year in its expression</summary>
        public Range YearRange { get; set; }

        /// <summary>Gets or sets the year extracted from the expression</summary>
        public string SelectedYear { get; set; }

        /// <summary>Gets or sets the range of characters defining the period in its expression</summary>
        public Range PeriodRange { get; set; }

        /// <summary>Gets or sets the period extracted from the expression</summary>
        public string SelectedPeriod { get; set; }

        /// <summary>Gets or sets the array of frequency mappings</summary>
        public string[] PeriodMapping { get; set; }

        /// <summary>Gets or sets a value indicating whether this formatting should be enabled</summary>
        public bool Enabled { get; set; }

        /// <summary>Gets or sets a value indicating whether this format contains mappings.</summary>
        public bool HasPeriodMapping { get; set; }
    }
}
