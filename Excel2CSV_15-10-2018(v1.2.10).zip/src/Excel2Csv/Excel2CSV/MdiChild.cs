﻿//-----------------------------------------------------------------------
// <copyright file="MdiChild.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Windows.Forms;
    using System.Xml;
    using System.Xml.Linq;
    using Excel2Csv.Properties;

    /// <summary>
    /// This class implements the common operations among the MDI children.
    /// </summary>
    [TypeDescriptionProvider(typeof(MdiChildDescriptionProvider<MdiChild, Form>))]
    public abstract class MdiChild : Form
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="MdiChild" /> class.
        /// </summary>
        /// <param name="statusMessage">The message that shall appear in the status bar of the main window</param>
        public MdiChild(string statusMessage = null)
        {
            this.MdiMessage = statusMessage;
        }

        /// <summary>Gets a newly created configuration by fetching the current table boundaries.</summary>
        public abstract BoundaryFieldConfig CurrentConfig
        {
            get;
        }

        /// <summary>
        /// Gets or sets the value for the message that shall appear in the status bar of the main window.
        /// </summary>
        public string MdiMessage
        {
            get;
            protected set;
        }

        /// <summary>Gets or sets the list of selectable "Code-List" expressions.</summary>
        public List<CodeDescExp> CodeDescExpressions { get; set; }

        /// <summary>
        /// Simple commodity function that makes converting a string 
        /// into an integer require a shorter syntax.
        /// </summary>
        /// <param name="res">The string to be parsed</param>
        /// <returns>The retrieved integer value</returns>
        protected static int Res2Int(string res)
        {
            int.TryParse(res, out int op);
            return op;
        }

        /// <summary>
        /// Checks whether all the mandatory fields of the window have been filled.
        /// </summary>
        /// <returns>True when all the mandatory fields are filled, false otherwise.</returns>
        protected abstract bool AreMandatoryFieldsFilled();

        /// <summary>
        /// The callback for the "Cancel" button.
        /// </summary>
        /// <param name="sender">The sender of the event.</param>
        /// <param name="e">An EventArgs that contains the event data.</param>
        protected void Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
            //this.Dispose();
        }

        /// <summary>
        /// This is used just to extract the value contained in XElement or XAttribute objects.
        /// Useful to replace the "?." syntax, which is not implemented in C# versions prior to 6.0.
        /// </summary>
        /// <param name="elem">The XObject to read</param>
        /// <returns>The Value element contained in the XObject if not null, otherwise return an empty string.</returns>
        protected string SafelyGetXElementValue(XObject elem)
        {
            if (object.ReferenceEquals(elem, null))
            {
                return string.Empty;
            }

            if (elem is XElement)
            {
                return ((XElement)elem).Value;
            }

            if (elem is XAttribute)
            {
                return ((XAttribute)elem).Value;
            }

            return string.Empty;
        }

        /// <summary>
        /// Same as SafelyGetXElementValue(), but also tries to parse the extracted value as an integer.
        /// </summary>
        /// <param name="elem">The XObject to start the value from.</param>
        /// <returns>The extracted value parsed as an integer.</returns>
        protected int SafelyGetXElementInt(XObject elem)
        {
            string val = this.SafelyGetXElementValue(elem);

            if (int.TryParse(val, out int ret))
            {
                return ret;
            }

            return default(int);
        }

        /// <summary>
        /// This function is used just to make the syntax for opening a XML node without attributes,
        /// writing in it and closing it, much shorter.
        /// </summary>
        /// <param name="writer">The XML writer object.</param>
        /// <param name="tag">The XML node.</param>
        /// <param name="value">The contents of the newly created XML node.</param>
        protected void WriteSimpleStringWithXmlTag(XmlWriter writer, string tag, string value)
        {
            if (object.ReferenceEquals(writer, null))
            {
                return;
            }

            writer.WriteStartElement(tag);
            writer.WriteString(string.IsNullOrWhiteSpace(value) ? string.Empty : value);
            writer.WriteEndElement();
        }

        /// <summary>
        /// Same as WriteSimpleStringWithValue(), but it surrounds the value by a CDATA tag.
        /// </summary>
        /// <param name="writer">The XML writer object.</param>
        /// <param name="tag">The XML node.</param>
        /// <param name="value">The contents of the newly created XML node.</param>
        protected void WriteSimpleCDataWithXmlTag(XmlWriter writer, string tag, string value)
        {
            if (object.ReferenceEquals(writer, null))
            {
                return;
            }

            writer.WriteStartElement(tag);
            writer.WriteCData(string.IsNullOrWhiteSpace(value) ? string.Empty : value);
            writer.WriteEndElement();
        }

        /// <summary>
        /// A simple function that casts any value to boolean, used to shorted the syntax
        /// when you extract values from XML nodes.
        /// </summary>
        /// <param name="val">The input value</param>
        /// <returns>true or false in case of valid casts, false otherwise.</returns>
        protected bool CastValueToBool(string val)
        {
            try
            {
                return Convert.ToBoolean(val);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Assigns a valid value to a given NumericUpDown, by casting the input value
        /// within the possible value range for the control.
        /// </summary>
        /// <param name="ud">The control reference</param>
        /// <param name="val">the value to be set</param>
        protected void AssignValueToNUD(NumericUpDown ud, string val)
        {
            if (!int.TryParse(val, out int intval))
            {
                try
                {
                    intval = TableColumnLabeling.NumberForColumn(val);
                }
                catch
                {
                    intval = default(int);
                }
            }

            if (intval < ud.Minimum)
            {
                ud.Value = ud.Minimum;
            }
            else if (intval > ud.Maximum)
            {
                ud.Value = ud.Maximum;
            }
            else
            {
                ud.Value = intval;
            }
        }

        /// <summary>Resets the expression list to an original not-configured default state.</summary>
        protected void ResetCodeDescExpressions()
        {
            if (object.ReferenceEquals(this.CodeDescExpressions, null))
            {
                this.CodeDescExpressions = new List<CodeDescExp>();
            }

            this.CodeDescExpressions.Clear();
            this.CodeDescExpressions.Add(new CodeDescExp(CodeDescExpType.Default, Resources.DefaultCodeDescrLabel, Resources.DefaultCodeDescrExpr, new Range() { Start = Res2Int(Resources.DefaultCodeStart), End = Res2Int(Resources.DefaultCodeEnd) }, new Range() { Start = Res2Int(Resources.DefaultDescStart), End = Res2Int(Resources.DefaultDescEnd) }) { Trim = true });
            this.CodeDescExpressions.Add(new CodeDescExp(CodeDescExpType.Optional, Resources.OptionalCodeDescrLabel1, Resources.OptionalCodeDescrExpr1, new Range() { Start = Res2Int(Resources.OptionalCodeStart1), End = Res2Int(Resources.OptionalCodeEnd1) }, new Range() { Start = Res2Int(Resources.OptionalDescStart1), End = Res2Int(Resources.OptionalDescEnd1) }) { Trim = true });
            this.CodeDescExpressions.Add(new CodeDescExp(CodeDescExpType.Optional, Resources.OptionalCodeDescrLabel2, Resources.OptionalCodeDescrExpr2, new Range() { Start = Res2Int(Resources.OptionalCodeStart2), End = Res2Int(Resources.OptionalCodeEnd2) }, new Range() { Start = Res2Int(Resources.OptionalDescStart2), End = Res2Int(Resources.OptionalDescEnd2) }) { Trim = true });
            this.CodeDescExpressions.Add(new CodeDescExp(CodeDescExpType.InputRequest, Resources.InputRequestLabel, string.Empty, new Range(), new Range()));
        }
    }
}
