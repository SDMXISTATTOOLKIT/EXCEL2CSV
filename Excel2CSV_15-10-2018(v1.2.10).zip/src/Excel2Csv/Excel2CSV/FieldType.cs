﻿//-----------------------------------------------------------------------
// <copyright file="FieldType.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    /// <summary>
    /// The class containing the definitions for all the possible CSV field types.
    /// </summary>
    public static class FieldType
    {
        /// <summary>Whether a CSV field represents a table row</summary>
        public const string Row = "Row";

        /// <summary>Whether a CSV field represents a table column</summary>
        public const string Column = "Column";

        /// <summary>Whether a CSV field has a constant value not shown in the table</summary>
        public const string Constant = "Constant";

        /// <summary>Whether a CSV field has a constant value not shown in the table</summary>
        public const string Value = "Value";

        /// <summary>Whether a CSV field reports contents extracted from the same cells of the codes</summary>
        public const string EmbeddedDescription = "Embedded";

        /// <summary>Whether a CSV field contains a column attribute</summary>
        public const string Attribute = "Attribute";
    }
}
