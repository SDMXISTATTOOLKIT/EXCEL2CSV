﻿//-----------------------------------------------------------------------
// <copyright file="ExpressionEditor.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using System;
    using System.Windows.Forms;

    /// <summary>
    /// This class defines the dialog window that lets the users define
    /// a custom "Code - Description" expression
    /// </summary>
    public partial class ExpressionEditor : Form
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ExpressionEditor"/> class.
        /// </summary>
        public ExpressionEditor()
        {
            this.InitializeComponent();

            this.btnOk.Enabled = false;
        }

        /// <summary>Gets or sets the user-entered custom expression.</summary>
        public string Expression { get; protected set; }

        /// <summary>
        /// Gets or sets the index range indicating the limits of
        /// the code part inside the custom expression.
        /// </summary>
        public Range CodeRange { get; protected set; }

        /// <summary>
        /// Gets or sets the index range indicating the limits of 
        /// the description part inside the custom expression.
        /// </summary>
        public Range DescRange { get; protected set; }

        /// <summary>
        /// Gets or sets a value indicating whether extra spaces around
        /// the code and the description parts shall be ignored.
        /// </summary>
        public bool Trim { get; protected set; }

        /// <summary>
        /// Callback triggered at every code text box change, needed to update both text boxes at once.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void TbCode_TextChanged(object sender, EventArgs e)
        {
            this.tbDescription.TextChanged -= this.TbDescription_TextChanged;

            try
            {
                this.Expression = this.tbDescription.Text = this.tbCode.Text;
            }
            finally
            {
                this.tbDescription.TextChanged += this.TbDescription_TextChanged;
            }

            this.CheckOverlapping();
        }

        /// <summary>
        /// Callback triggered at every description text box change,
        /// needed to update both text boxes at once.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void TbDescription_TextChanged(object sender, EventArgs e)
        {
            this.tbCode.TextChanged -= this.TbCode_TextChanged;

            try
            {
                this.Expression = this.tbCode.Text = this.tbDescription.Text;
            }
            finally
            {
                this.tbCode.TextChanged += this.TbCode_TextChanged;
            }

            this.CheckOverlapping();
        }

        /// <summary>
        /// Checks whether the index range in the code box overlaps the one in the description box
        /// and enables or disables the ok button appropriately.
        /// </summary>
        private void CheckOverlapping()
        {
            this.CodeRange = new Range() { Start = this.tbCode.SelectionStart, End = this.tbCode.SelectionStart + this.tbCode.SelectionLength };
            this.DescRange = new Range() { Start = this.tbDescription.SelectionStart, End = this.tbDescription.SelectionStart + this.tbDescription.SelectionLength };
            this.btnOk.Enabled = this.tbCode.SelectionLength > 0 && this.tbDescription.SelectionLength > 0 && !this.CodeRange.Overlaps(this.DescRange);
        }

        /// <summary>
        /// Callback triggered at every selection change in the code text box.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void TbCode_SelectionChanged(object sender, EventArgs e)
        {
            this.CodeRange = new Range()
            {
                Start = this.tbCode.SelectionStart,
                End = this.tbCode.SelectionStart + this.tbCode.SelectionLength - 1
            };

            this.CheckOverlapping();
        }

        /// <summary>
        /// Callback triggered at every selection change in the description text box.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void TbDescription_SelectionChanged(object sender, EventArgs e)
        {
            this.DescRange = new Range()
            {
                Start = this.tbDescription.SelectionStart,
                End = this.tbDescription.SelectionStart + this.tbDescription.SelectionLength - 1
            };

            this.CheckOverlapping();
        }

        /// <summary>
        /// Sets the Trim property according to the value of the trimming check box.
        /// </summary>
        /// <param name="sender">The sender object</param>
        /// <param name="e">The event arguments</param>
        private void CbTrim_CheckStateChanged(object sender, EventArgs e)
        {
            this.Trim = this.cbTrim.Checked;
        }
    }
}
