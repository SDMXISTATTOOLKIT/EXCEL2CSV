﻿//-----------------------------------------------------------------------
// <copyright file="CsvField.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    /// <summary>
    /// This object replaces the simple strings for the single csv values by adding an information
    /// more about whether the field contains a time series value.
    /// </summary>
    public struct CsvField
    {
        /// <summary>The actual csv field value.</summary>
        public string Value { get; set; }

        /// <summary>Whether the csv field contains a time series value</summary>
        public bool IsTimeSeriesValue { get; set; }

        /// <summary>
        /// This spares the programmer to do explicit casts from <see cref="CsvField"/> to <seealso cref="string"/>.
        /// </summary>
        /// <param name="cell">The actual csv field.</param>
        static public implicit operator string(CsvField cell)
        {
            return cell.Value;
        }

        /// <summary>
        /// This spares the programmer to do explicit casts from <seealso cref="string"/> to <see cref="CsvField"/>.
        /// </summary>
        /// <param name="val">The field value.</param>
        static public implicit operator CsvField(string val)
        {
            return new CsvField() { Value = val, IsTimeSeriesValue = false };
        }
    };
}
