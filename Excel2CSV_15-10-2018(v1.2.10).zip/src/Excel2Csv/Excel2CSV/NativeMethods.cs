﻿using System;
using System.Runtime.InteropServices;

namespace Excel2Csv
{
    internal sealed class NativeMethods
    {
        private NativeMethods()
        {
        }

        /// <summary>
        /// This function just encapsulates the WinAPI call LockWindowUpdate().
        /// In C: <code>BOOL LockWindowUpdate(In_ HWND hWndLock);</code>
        /// </summary>
        /// <param name="windowHandle">
        /// The window in which drawing will be disabled. If this parameter is the not-marshaled
        /// zero pointer (<code>IntPtr.Zero</code>, same as the NULL macro), drawing in the
        /// locked window is enabled.
        /// </param>
        /// <returns>
        /// If the function succeeds, the return value is nonzero. If the function fails, the return
        /// value is zero, indicating that an error occurred or another window was already locked.
        /// </returns>
        [DllImport("user32.dll", EntryPoint = "LockWindowUpdate", SetLastError = true, ExactSpelling = true,
            CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        internal static extern long LockWindowUpdate(IntPtr windowHandle);
    }
}
