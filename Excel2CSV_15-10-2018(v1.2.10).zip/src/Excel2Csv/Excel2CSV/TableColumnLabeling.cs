﻿//-----------------------------------------------------------------------
// <copyright file="TableColumnLabeling.cs" company="ISTAT">
//     Copyright (c) 2017 Istituto Nazionale di Statistica (ISTAT). All rights reserved.
//     Copyright (c) 2017 Andrea Santilli. All rights reserved.
// </copyright>
// <author>Andrea Santilli &lt;andrea.santilli@istat.it&gt;</author>
//-----------------------------------------------------------------------
// This software is distributed under the European Union Public License
// (EUPL) version 1.1 or above.
// You may not use this work except in compliance with this License.
//
// You may obtain a copy of the Licence in any of the EU languages at:
// http://ec.europa.eu/idabc/eupl.html
// 
// This software is distributed "AS IS" WITHOUT WARRANTIES OR CONDITIONS
// OF ANY KIND, either expressed or implied.

namespace Excel2Csv
{
    using System;
    using Excel2Csv.Properties;

    /// <summary>
    /// Contains a set of static helper methods that allow the conversion of sheet 
    /// column labels into their NPOI library numbering representations and vice versa.
    /// Methods for getting the next/previous column label and for checking labels are
    /// provided as well.
    /// </summary>
    public static class TableColumnLabeling
    {
        /// <summary>The only characters allowed in a column label.</summary>
        private const string DIGITS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        /// <summary>
        /// Returns the column label next to the one that is passed as argument.
        /// </summary>
        /// <param name="current">The column label which we want the next one to.</param>
        /// <returns>The column next to the one passed as argument.</returns>
        public static string NextColumn(string current)
        {
            return ColumnForNumber(NumberForColumn(current) + 1);
        }

        /// <summary>
        /// Returns the column label previous to the one that is passed as argument.
        /// </summary>
        /// <param name="current">The column label which we want the previous one to.</param>
        /// <returns>The column previous to the one passed as argument.</returns>
        public static string PreviousColumn(string current)
        {
            return ColumnForNumber(NumberForColumn(current) - 1);
        }
        
        /// <summary>Checks whether the argument is a valid column label.</summary>
        /// <param name="current">The column label we want to check.</param>
        /// <returns>True if the argument is a valid column label, false otherwise.</returns>
        public static bool IsColumn(string current)
        {
            try
            {
                NumberForColumn(current);
            }
            catch
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Converts a column label as shown in Excel into its NPOI index.
        /// </summary>
        /// <param name="column">The column label to be converted to its NPOI index.</param>
        /// <returns>The NPOI index for the column label passed as argument.</returns>
        public static int NumberForColumn(string column)
        {
            int ret = 0;
            char[] digitarray = column.ToCharArray();
            Array.Reverse(digitarray);

            for (var i = 0; i < digitarray.Length; i++)
            {
                ret += NumberForChar(digitarray[i]) * (int)Math.Pow(DIGITS.Length, i);
            }
            
            return ret;
        }

        /// <summary>Converts a column NPOI index to its label as shown in Excel.</summary>
        /// <param name="number">The NPOI index for which we want to get the corresponding column label.</param>
        /// <returns>The column label for the NPOI index passed as argument.</returns>
        public static string ColumnForNumber(int number)
        {
            string ret = string.Empty;
            int result = number;
            int rest = 0;

            if (number < 1) 
            {
                throw new InvalidOperationException(string.Format(Resources.InvalidValue_0, number));
            }
            
            while (result >= DIGITS.Length)
            {
                rest = result % DIGITS.Length;
                result /= DIGITS.Length;
                
                if (rest == 0)
                {
                    rest = DIGITS.Length;
                    result--;
                }
                
                ret = string.Format("{0}{1}", CharForNumber(rest), ret);
            }

            if (result > 0)
            {
                ret = string.Format("{0}{1}", CharForNumber(result), ret);
            }
            
            return ret;
        }
        
        /// <summary>
        /// Gets the corresponding base 10 digit for a valid column label character.
        /// </summary>
        /// <param name="labelChar">A valid column label character.</param>
        /// <returns>The base 10 number for the column character passed as argument.</returns>
        public static int NumberForChar(char labelChar)
        {
            int ret = DIGITS.IndexOf(char.ToUpper(labelChar));
            if (ret < 0)
            {
                throw new Exception(string.Format(Resources.InvalidCharacter_0, labelChar));
            }

            return ret + 1;
        }

        /// <summary>
        /// Gets the corresponding column label character for a base 10 digit.
        /// </summary>
        /// <param name="number">A number for which there exists a valid column label sign.</param>
        /// <returns>The column number letter corresponding to the base 10 number passed as argument.</returns>
        public static char CharForNumber(int number)
        {
            if ((number < 1) || (number > DIGITS.Length))
            {
                throw new Exception(string.Format(Resources.NoSuchDigitForNumber_0, number));
            }

            return DIGITS[number - 1];
        }
    }
}
